"use client";

import { useSearchParams } from "next/navigation";
import { WelcomeScreen } from "@/components/onboarding/WelcomeScreen";
import { LandingHero } from "@/components/landing/LandingHero";
import { useAppTier } from "@/context/AppTierProvider";

export default function HomePageClient() {
  const { tier, ready } = useAppTier();
  const searchParams = useSearchParams();
  const forceWelcome = searchParams.get("welcome") === "1";

  if (!ready) {
    return (
      <div
        className="flex min-h-screen items-center justify-center"
        style={{ backgroundColor: "#050505" }}
      >
        <p className="label-caps text-white/30">Loading...</p>
      </div>
    );
  }

  if (!tier || forceWelcome) {
    return <WelcomeScreen />;
  }

  return <LandingHero />;
}

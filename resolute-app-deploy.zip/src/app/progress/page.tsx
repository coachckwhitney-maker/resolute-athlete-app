import { Suspense } from "react";
import { ProgressClient } from "@/components/progress/ProgressClient";

export default function ProgressPage() {
  return (
    <Suspense fallback={null}>
      <ProgressClient />
    </Suspense>
  );
}

import { MindsetPageClient } from "@/components/mindset/MindsetPageClient";

export default function MindsetPage() {
  return <MindsetPageClient />;
}

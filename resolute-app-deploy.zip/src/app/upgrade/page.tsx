import { UpgradeClient } from "@/components/upgrade/UpgradeClient";

export default function UpgradePage() {
  return <UpgradeClient />;
}

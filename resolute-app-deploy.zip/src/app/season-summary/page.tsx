import { SeasonSummaryClient } from "@/components/season/SeasonSummaryClient";

export default function SeasonSummaryPage() {
  return <SeasonSummaryClient />;
}

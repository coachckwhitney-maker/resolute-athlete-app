import { CoachesPageClient } from "@/components/coaches/CoachesPageClient";

export default function CoachesPage() {
  return <CoachesPageClient />;
}

import { BlueprintPageClient } from "@/components/blueprint/BlueprintPageClient";

export default function BlueprintPage() {
  return <BlueprintPageClient />;
}

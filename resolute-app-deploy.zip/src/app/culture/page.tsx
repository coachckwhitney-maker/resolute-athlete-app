import { CulturePageClient } from "@/components/culture/CulturePageClient";

export default function CulturePage() {
  return <CulturePageClient />;
}

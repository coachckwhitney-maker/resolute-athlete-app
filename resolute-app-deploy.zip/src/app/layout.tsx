import type { Metadata, Viewport } from "next";
import { Bebas_Neue, Inter, Syne } from "next/font/google";
import { AppProviders } from "@/components/providers/AppProviders";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

const bebas = Bebas_Neue({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-display",
});

const syne = Syne({
  subsets: ["latin"],
  weight: ["600", "700", "800"],
  variable: "--font-accent",
});

export const metadata: Metadata = {
  title: "Resolute Track Club — The Coach in Your Pocket",
  description:
    "Develop the whole athlete. The goal is always to win — becoming a champion takes everything.",
  icons: {
    icon: "/logos/resolute-logo-square.jpg",
    apple: "/logos/resolute-logo-square.jpg",
  },
  openGraph: {
    title: "Resolute Track Club",
    description: "The operating system for athlete development.",
    images: ["/logos/resolute-logo-primary.png"],
  },
};

export const viewport: Viewport = {
  themeColor: "#050505",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${bebas.variable} ${syne.variable}`}>
      <body
        className="font-sans bg-resolute-black text-resolute-white min-h-screen"
        style={{ backgroundColor: "#050505", color: "#FAFAFA" }}
      >
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}

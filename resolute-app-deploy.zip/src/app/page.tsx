import { Suspense } from "react";
import HomePageClient from "./HomePageClient";

export default function HomePage() {
  return (
    <Suspense
      fallback={
        <div
          className="flex min-h-screen items-center justify-center"
          style={{ backgroundColor: "#050505" }}
        >
          <p className="label-caps text-white/30">Loading...</p>
        </div>
      }
    >
      <HomePageClient />
    </Suspense>
  );
}

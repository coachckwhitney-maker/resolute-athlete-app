import { AccountabilityClient } from "@/components/accountability/AccountabilityClient";

export default function AccountabilityPage() {
  return <AccountabilityClient />;
}

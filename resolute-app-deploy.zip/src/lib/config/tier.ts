/** Free access code for current Resolute high school athletes (development portal) */
export const TEAM_ACCESS_CODE = "RESOLUTE";

/** Dev-only code to preview coached tier before subscriptions launch */
export const COACHED_PREVIEW_CODE = "COACHME";

/** Set true when RevenueCat / App Store subscriptions are wired */
export const SUBSCRIPTIONS_ENABLED = false;

export const tierLabels = {
  generic: {
    name: "Athlete Tracker",
    short: "Free",
    description: "Blank tracking app — log your own workouts, habits, PRs, and scores.",
  },
  team: {
    name: "Resolute Athlete",
    short: "For Current Resolute Track Club Athletes",
    description:
      "Culture, mindset, recovery, nutrition, blueprint, season reflection & accountability. No workouts — you train with us in person.",
  },
  coached: {
    name: "Coached Athlete",
    short: "Coach Whitney",
    description:
      "Remote coaching through the app — daily workouts, Coach Whitney's voice, and the full training program.",
  },
} as const;

export const subscriptionPricing = {
  monthly: {
    amount: 19.99,
    label: "Monthly",
    period: "/ month",
    tagline: "Cancel anytime",
  },
  yearly: {
    amount: 149,
    label: "Yearly",
    period: "/ year",
    tagline: "Save 38% — best value",
    recommended: true,
  },
} as const;

export const tierComparison = {
  generic: [
    "Blank slate — no pre-filled data",
    "Log your own workouts",
    "Track PRs & wellness",
    "Daily habits you create",
    "Meet planner, injury & progress tracking",
    "Upgrade for nutrition & Blueprint",
  ],
  team: [
    "Free for current Resolute athletes",
    "Coach Whitney's voice & standards",
    "Team culture & mindset library",
    "Recovery, wellness & accountability",
    "Daily nutrition tracker",
    "Athlete Blueprint development",
    "Season Summary end-of-year reflection",
    "No app workouts — train with us live",
  ],
  coached: [
    "Everything in Resolute Athlete, plus:",
    "Daily workouts assigned in-app",
    "Coach Whitney trains you remotely",
    "Daily nutrition tracker",
    "Athlete Blueprint development",
    "Full program — speed, strength, recovery",
    "Same philosophy as the track club",
    "For athletes not on the local team",
  ],
} as const;

export const upgradeHeadline = {
  coached: {
    title: "Get Coached by Coach Whitney",
    subtitle:
      "Daily training through the app — workouts, voice notes, and the full remote program.",
  },
  team: {
    title: "Resolute Athlete Portal",
    subtitle:
      "Free for current high school athletes. Develop the whole athlete beyond practice.",
  },
};

export const teamPortalTagline =
  "Practice is on the track. This is where you build culture, mindset, recovery, and the rest of the whole athlete.";

export const coachedTagline =
  "Not on the team locally? Get coached by Coach Whitney through the app — workouts included.";

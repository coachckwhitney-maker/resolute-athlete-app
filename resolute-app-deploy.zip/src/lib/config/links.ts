/** Coach inquiry — update with your booking link or email */
export const COACH_INQUIRY_URL =
  process.env.NEXT_PUBLIC_COACH_INQUIRY_URL ??
  "https://christinawhitney468804.typeform.com/to/VIbfWV";

export const WEBSITE_URL = "https://www.resolutetrackclub.com";

/**
 * Podcast: leave empty until your show is live, then paste your Spotify or
 * Apple Podcasts URL here — or set NEXT_PUBLIC_PODCAST_URL in .env.local
 */
export const PODCAST_URL = process.env.NEXT_PUBLIC_PODCAST_URL ?? "";

export const PODCAST_ENABLED = PODCAST_URL.length > 0;

export const PODCAST_LABEL = "Listen to Our Podcast";
export const PODCAST_COMING_SOON_LABEL = "Podcast — Coming Soon";

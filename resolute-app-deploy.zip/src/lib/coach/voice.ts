import type { AppTier } from "@/lib/types/appTier";
import { getTierFeatures } from "@/lib/types/appTier";
import type { CoachMessage, MindsetLesson } from "@/lib/types/athlete";
import { blueprintPhilosophy } from "@/lib/data/blueprint";
import {
  getDailyCoachMessage as getWhitneyDailyCoachMessage,
  marqueeItems as whitneyMarqueeItems,
  sessionCompleteLine as whitneySessionCompleteLine,
  signatureFooter,
  workoutCoachLines as whitneyWorkoutCoachLines,
} from "@/lib/data/signatureSayings";
import { getDailyCultureStatement } from "@/lib/data/cultureSayings";
import {
  accountabilityFeaturedLine,
  getDailyAccountabilityLine,
  habitCoachLines as whitneyHabitCoachLines,
  accountabilityCompleteLine,
} from "@/lib/data/accountabilitySayings";
import {
  getDailyMindsetPhilosophy,
  mindsetPhilosophyFeatured,
} from "@/lib/data/mindsetPhilosophy";
import {
  favoriteQuoteFeatured,
  getDailyFavoriteQuote,
  favoriteQuoteLessons,
} from "@/lib/data/favoriteQuotes";
import {
  signatureMindsetLessons,
  athleteMindsetLessons,
} from "@/lib/data/signatureSayings";
import { cultureMindsetLessons } from "@/lib/data/cultureSayings";
import { accountabilityMindsetLessons } from "@/lib/data/accountabilitySayings";
import {
  genericCoachName,
  genericMarqueeItems,
  getGenericDailyCoachMessage,
  genericBlueprintPhilosophy,
  genericCultureMessage,
  genericSessionCompleteLine,
  genericAccountabilityFeatured,
  genericMindsetFeatured,
  genericLandingSubtitle,
  genericCoachBentoLine,
  genericMindsetLessons,
  genericWorkoutCoachLines,
  genericHabitCoachLines,
} from "@/lib/data/generic/voice";
import { teamPortalTagline, tierLabels } from "@/lib/config/tier";

export interface CoachVoice {
  tier: AppTier;
  features: ReturnType<typeof getTierFeatures>;
  /** @deprecated use features.whitneyVoice */
  isClient: boolean;
  isTeamAthlete: boolean;
  isCoached: boolean;
  hasWorkouts: boolean;
  tierLabel: (typeof tierLabels)[AppTier];
  coachName: string;
  coachFooter: string | null;
  showWhitneyContent: boolean;
  getDailyCoachMessage: (date?: Date) => CoachMessage;
  marqueeItems: string[];
  blueprintPhilosophy: typeof blueprintPhilosophy;
  cultureCoachMessage: string;
  sessionCompleteLine: string;
  landingSubtitle: string;
  coachBentoLine: string;
  accountabilityFeatured: string;
  mindsetFeatured: string;
  getDailyMindsetQuote: (date?: Date) => { text: string; tag: string; note?: string };
  workoutCoachLines: Record<string, string>;
  habitCoachLines: Record<string, string>;
  accountabilityCompleteLine: string;
  mindsetLessons: {
    showPhilosophyWall: boolean;
    showFavoriteQuotes: boolean;
    showFoundation: boolean;
    showAthleteLines: boolean;
    showCulture: boolean;
    showAccountability: boolean;
    primaryLessons: MindsetLesson[];
    favoriteLessons: MindsetLesson[];
    foundationLessons: MindsetLesson[];
    athleteLessons: MindsetLesson[];
    cultureLessons: MindsetLesson[];
    accountabilityLessons: MindsetLesson[];
  };
}

function whitneyMindsetLessons() {
  return {
    showPhilosophyWall: true,
    showFavoriteQuotes: true,
    showFoundation: true,
    showAthleteLines: true,
    showCulture: true,
    showAccountability: true,
    primaryLessons: [] as MindsetLesson[],
    favoriteLessons: favoriteQuoteLessons,
    foundationLessons: signatureMindsetLessons,
    athleteLessons: athleteMindsetLessons,
    cultureLessons: cultureMindsetLessons,
    accountabilityLessons: accountabilityMindsetLessons,
  };
}

function whitneyVoiceCore(tier: AppTier): Omit<CoachVoice, "tier" | "features" | "isClient" | "isTeamAthlete" | "isCoached" | "hasWorkouts" | "landingSubtitle" | "coachBentoLine"> {
  return {
    tierLabel: tierLabels[tier],
    coachName: "Coach Whitney",
    coachFooter: signatureFooter,
    showWhitneyContent: true,
    getDailyCoachMessage: getWhitneyDailyCoachMessage,
    marqueeItems: whitneyMarqueeItems,
    blueprintPhilosophy,
    cultureCoachMessage: getDailyCultureStatement().text,
    sessionCompleteLine: whitneySessionCompleteLine,
    accountabilityFeatured: accountabilityFeaturedLine.text,
    mindsetFeatured: mindsetPhilosophyFeatured.text,
    getDailyMindsetQuote: (date) => {
      const q = getDailyMindsetPhilosophy(date);
      return { text: q.text, tag: q.tag, note: q.lessonNote };
    },
    workoutCoachLines: whitneyWorkoutCoachLines,
    habitCoachLines: whitneyHabitCoachLines,
    accountabilityCompleteLine,
    mindsetLessons: whitneyMindsetLessons(),
  };
}

export function resolveCoachVoice(tier: AppTier): CoachVoice {
  const features = getTierFeatures(tier);

  if (tier === "coached") {
    return {
      tier,
      features,
      isClient: true,
      isTeamAthlete: false,
      isCoached: true,
      hasWorkouts: true,
      ...whitneyVoiceCore(tier),
      landingSubtitle: favoriteQuoteFeatured.text,
      coachBentoLine: mindsetPhilosophyFeatured.text,
    };
  }

  if (tier === "team") {
    return {
      tier,
      features,
      isClient: true,
      isTeamAthlete: true,
      isCoached: false,
      hasWorkouts: false,
      ...whitneyVoiceCore(tier),
      landingSubtitle: teamPortalTagline,
      coachBentoLine: "Develop the whole athlete — beyond the track.",
    };
  }

  return {
    tier,
    features,
    isClient: false,
    isTeamAthlete: false,
    isCoached: false,
    hasWorkouts: true,
    tierLabel: tierLabels.generic,
    coachName: genericCoachName,
    coachFooter: null,
    showWhitneyContent: false,
    getDailyCoachMessage: getGenericDailyCoachMessage,
    marqueeItems: genericMarqueeItems,
    blueprintPhilosophy: genericBlueprintPhilosophy,
    cultureCoachMessage: genericCultureMessage,
    sessionCompleteLine: genericSessionCompleteLine,
    landingSubtitle: genericLandingSubtitle,
    coachBentoLine: genericCoachBentoLine,
    accountabilityFeatured: genericAccountabilityFeatured,
    mindsetFeatured: genericMindsetFeatured,
    getDailyMindsetQuote: (date) => {
      const q = getGenericDailyCoachMessage(date);
      return { text: q.message, tag: q.focus };
    },
    workoutCoachLines: genericWorkoutCoachLines,
    habitCoachLines: genericHabitCoachLines,
    accountabilityCompleteLine: genericSessionCompleteLine,
    mindsetLessons: {
      showPhilosophyWall: false,
      showFavoriteQuotes: false,
      showFoundation: false,
      showAthleteLines: false,
      showCulture: false,
      showAccountability: false,
      primaryLessons: genericMindsetLessons,
      favoriteLessons: [],
      foundationLessons: [],
      athleteLessons: [],
      cultureLessons: [],
      accountabilityLessons: [],
    },
  };
}

export function getClientFavoriteQuote(date?: Date) {
  const q = getDailyFavoriteQuote(date);
  return { text: q.text, tag: q.tag };
}

export function getClientAccountabilityLine(date?: Date) {
  const line = getDailyAccountabilityLine(date);
  return { text: line.text, tag: line.tag, note: line.lessonNote };
}

import {
  createEmptyGenericData,
  GENERIC_ATHLETE_STORAGE_KEY,
  type GenericAthleteData,
} from "@/lib/data/emptyDefaults";
import { safeGetItem, safeParseJson, safeRemoveItem, safeSetItem } from "@/lib/storage/safeStorage";

export function loadGenericAthleteData(): GenericAthleteData {
  if (typeof window === "undefined") {
    return createEmptyGenericData();
  }

  try {
    const raw = safeGetItem(GENERIC_ATHLETE_STORAGE_KEY);
    if (!raw) return createEmptyGenericData();
    const parsed = safeParseJson<GenericAthleteData>(raw, createEmptyGenericData());
    return {
      ...createEmptyGenericData(),
      ...parsed,
      athlete: { ...createEmptyGenericData().athlete, ...parsed.athlete },
      meetPlans: parsed.meetPlans ?? [],
      injuries: parsed.injuries ?? [],
      trainingLogs: parsed.trainingLogs ?? [],
      competitionResults: parsed.competitionResults ?? [],
      attendance: parsed.attendance ?? [],
      keepsakes: parsed.keepsakes ?? [],
      seasonSummaries: parsed.seasonSummaries ?? [],
      nutritionLogs: parsed.nutritionLogs ?? [],
    };
  } catch {
    return createEmptyGenericData();
  }
}

export function saveGenericAthleteData(data: GenericAthleteData): void {
  if (typeof window === "undefined") return;
  safeSetItem(GENERIC_ATHLETE_STORAGE_KEY, JSON.stringify(data));
}

export function clearGenericAthleteData(): void {
  if (typeof window === "undefined") return;
  safeRemoveItem(GENERIC_ATHLETE_STORAGE_KEY);
}

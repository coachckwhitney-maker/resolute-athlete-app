import {
  createEmptyGenericData,
  COACHED_ATHLETE_STORAGE_KEY,
  GENERIC_ATHLETE_STORAGE_KEY,
  TEAM_ATHLETE_STORAGE_KEY,
  type GenericAthleteData,
} from "@/lib/data/emptyDefaults";
import type { AppTier } from "@/lib/types/appTier";
import { safeGetItem, safeParseJson, safeSetItem } from "@/lib/storage/safeStorage";

const TIER_KEYS: Record<AppTier, string> = {
  generic: GENERIC_ATHLETE_STORAGE_KEY,
  team: TEAM_ATHLETE_STORAGE_KEY,
  coached: COACHED_ATHLETE_STORAGE_KEY,
};

function mergeWithDefaults(parsed: Partial<GenericAthleteData>): GenericAthleteData {
  const defaults = createEmptyGenericData();
  return {
    ...defaults,
    ...parsed,
    athlete: { ...defaults.athlete, ...parsed.athlete },
    meetPlans: parsed.meetPlans ?? defaults.meetPlans,
    injuries: parsed.injuries ?? defaults.injuries,
    trainingLogs: parsed.trainingLogs ?? defaults.trainingLogs,
    competitionResults: parsed.competitionResults ?? defaults.competitionResults,
    attendance: parsed.attendance ?? defaults.attendance,
    keepsakes: parsed.keepsakes ?? defaults.keepsakes,
    seasonSummaries: parsed.seasonSummaries ?? defaults.seasonSummaries,
    nutritionLogs: parsed.nutritionLogs ?? defaults.nutritionLogs,
  };
}

export function loadAthleteData(tier: AppTier, fallback: GenericAthleteData): GenericAthleteData {
  if (typeof window === "undefined") {
    return fallback;
  }

  try {
    const raw = safeGetItem(TIER_KEYS[tier]);
    if (!raw) return fallback;
    const parsed = safeParseJson<Partial<GenericAthleteData>>(raw, {});
    return mergeWithDefaults({ ...fallback, ...parsed });
  } catch {
    return fallback;
  }
}

export function saveAthleteData(tier: AppTier, data: GenericAthleteData): void {
  if (typeof window === "undefined") return;
  safeSetItem(TIER_KEYS[tier], JSON.stringify(data));
}

export { loadGenericAthleteData, saveGenericAthleteData } from "@/lib/storage/genericAthleteStorage";

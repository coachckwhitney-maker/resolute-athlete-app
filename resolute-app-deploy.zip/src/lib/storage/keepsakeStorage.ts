import type { AppTier } from "@/lib/types/appTier";
import { safeGetItem, safeParseJson, safeSetItem } from "@/lib/storage/safeStorage";

const IMAGE_KEYS: Partial<Record<AppTier, string>> = {
  generic: "resolute-keepsake-images-generic",
  team: "resolute-keepsake-images-team",
};

export function canStoreKeepsakes(tier: AppTier): boolean {
  return tier === "generic" || tier === "team";
}

export function loadKeepsakeImages(tier: AppTier): Record<string, string> {
  if (typeof window === "undefined" || !canStoreKeepsakes(tier)) return {};
  const key = IMAGE_KEYS[tier];
  if (!key) return {};

  try {
    const raw = safeGetItem(key);
    if (!raw) return {};
    return safeParseJson<Record<string, string>>(raw, {});
  } catch {
    return {};
  }
}

export function saveKeepsakeImage(tier: AppTier, id: string, imageData: string): void {
  if (typeof window === "undefined" || !canStoreKeepsakes(tier)) return;
  const key = IMAGE_KEYS[tier];
  if (!key) return;

  const images = loadKeepsakeImages(tier);
  images[id] = imageData;
  safeSetItem(key, JSON.stringify(images));
}

export function removeKeepsakeImage(tier: AppTier, id: string): void {
  if (typeof window === "undefined" || !canStoreKeepsakes(tier)) return;
  const key = IMAGE_KEYS[tier];
  if (!key) return;

  const images = loadKeepsakeImages(tier);
  delete images[id];
  safeSetItem(key, JSON.stringify(images));
}

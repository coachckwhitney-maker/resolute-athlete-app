import type {
  AttendanceEntry,
  PersonalRecord,
  TrainingLogCategory,
  TrainingLogEntry,
  WellnessMetric,
} from "@/lib/types/athlete";

export interface TrendPoint {
  label: string;
  value: number;
  date: string;
}

export function getWeekKey(dateStr: string): string {
  const date = new Date(dateStr + "T12:00:00");
  const day = date.getDay();
  const diff = date.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(date);
  monday.setDate(diff);
  return monday.toISOString().slice(0, 10);
}

export function formatWeekLabel(weekKey: string): string {
  const d = new Date(weekKey + "T12:00:00");
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export function aggregateTrainingByWeek(
  logs: TrainingLogEntry[],
  category: TrainingLogCategory
): TrendPoint[] {
  const filtered = logs.filter((l) => l.category === category);
  const byWeek = new Map<string, number>();

  for (const log of filtered) {
    const key = getWeekKey(log.date);
    byWeek.set(key, (byWeek.get(key) ?? 0) + log.value);
  }

  return [...byWeek.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-8)
    .map(([date, value]) => ({
      label: formatWeekLabel(date),
      value,
      date,
    }));
}

export function aggregateWellnessByLabel(
  metrics: WellnessMetric[],
  labelMatch: RegExp
): TrendPoint[] {
  const filtered = metrics.filter((m) => labelMatch.test(m.label));
  return filtered
    .slice()
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(-10)
    .map((m) => ({
      label: m.date.slice(5),
      value: m.value,
      date: m.date,
    }));
}

export function getPrProgression(records: PersonalRecord[]): TrendPoint[] {
  const byEvent = new Map<string, PersonalRecord[]>();
  for (const pr of records) {
    const list = byEvent.get(pr.event) ?? [];
    list.push(pr);
    byEvent.set(pr.event, list);
  }

  const points: TrendPoint[] = [];
  for (const [event, list] of byEvent) {
    const sorted = list.sort((a, b) => a.date.localeCompare(b.date));
    const latest = sorted[sorted.length - 1];
    const numeric = parseFloat(latest.value.replace(/[^\d.]/g, ""));
    if (!Number.isNaN(numeric)) {
      points.push({
        label: event,
        value: numeric,
        date: latest.date,
      });
    }
  }
  return points.slice(0, 8);
}

export function getAttendanceRate(attendance: AttendanceEntry[]): TrendPoint[] {
  const byWeek = new Map<string, { present: number; total: number }>();

  for (const entry of attendance) {
    const key = getWeekKey(entry.date);
    const current = byWeek.get(key) ?? { present: 0, total: 0 };
    current.total += 1;
    if (entry.present) current.present += 1;
    byWeek.set(key, current);
  }

  return [...byWeek.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-8)
    .map(([date, { present, total }]) => ({
      label: formatWeekLabel(date),
      value: total > 0 ? Math.round((present / total) * 100) : 0,
      date,
    }));
}

export function maxTrendValue(points: TrendPoint[]): number {
  if (points.length === 0) return 1;
  return Math.max(...points.map((p) => p.value), 1);
}

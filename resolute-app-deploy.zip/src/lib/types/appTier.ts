export type AppTier = "generic" | "team" | "coached";

/** @deprecated migrated to team or coached on load */
export type LegacyAppTier = "client";

export const APP_TIER_STORAGE_KEY = "resolute-app-tier";

export interface TierFeatures {
  blankSlate: boolean;
  whitneyVoice: boolean;
  hasWorkouts: boolean;
  culture: boolean;
  mindset: boolean;
  accountability: boolean;
  blueprint: boolean;
  nutrition: boolean;
  progress: boolean;
  showUpgradeToCoached: boolean;
}

export function getTierFeatures(tier: AppTier): TierFeatures {
  switch (tier) {
    case "coached":
      return {
        blankSlate: false,
        whitneyVoice: true,
        hasWorkouts: true,
        culture: true,
        mindset: true,
        accountability: true,
        blueprint: true,
        nutrition: true,
        progress: true,
        showUpgradeToCoached: false,
      };
    case "team":
      return {
        blankSlate: false,
        whitneyVoice: true,
        hasWorkouts: false,
        culture: true,
        mindset: true,
        accountability: true,
        blueprint: true,
        nutrition: true,
        progress: true,
        showUpgradeToCoached: true,
      };
    default:
      return {
        blankSlate: true,
        whitneyVoice: false,
        hasWorkouts: true,
        culture: false,
        mindset: false,
        accountability: true,
        blueprint: false,
        nutrition: false,
        progress: true,
        showUpgradeToCoached: true,
      };
  }
}

export function normalizeStoredTier(stored: string | null): AppTier | null {
  if (stored === "generic" || stored === "team" || stored === "coached") {
    return stored;
  }
  // Legacy: full "client" tier maps to coached (had workouts + Whitney)
  if (stored === "client") {
    return "coached";
  }
  return null;
}

export type ReadinessStatus = "green" | "yellow" | "red";

export type BlueprintDimension =
  | "speed"
  | "strength"
  | "mobility"
  | "power"
  | "recovery"
  | "nutrition"
  | "mindset"
  | "accountability"
  | "leadership"
  | "coachability";

export interface BlueprintScore {
  dimension: BlueprintDimension;
  label: string;
  score: number;
  trend: "up" | "down" | "flat";
}

export interface Athlete {
  id: string;
  name: string;
  sport: string;
  team: string;
  grade: number;
  readiness: ReadinessStatus;
  readinessNote: string;
  blueprintOverall: number;
  streak: number;
}

export interface WorkoutBlock {
  id: string;
  title: string;
  category: "warmup" | "sprint" | "lift" | "plyo" | "mobility" | "recovery";
  duration: string;
  description: string;
  why: string;
  /** Coach Whitney line — what you tell athletes on this type of work */
  coachLine?: string;
  completed: boolean;
}

export interface AccountabilityItem {
  id: string;
  label: string;
  completed: boolean;
  category: "recovery" | "training" | "life" | "mindset" | "nutrition";
  /** Coach Whitney accountability line for this habit */
  coachLine?: string;
}

export interface PersonalRecord {
  id: string;
  event: string;
  value: string;
  date: string;
  previous?: string;
}

export interface WellnessMetric {
  id: string;
  label: string;
  value: number;
  unit: string;
  date: string;
}

export interface MeetPlan {
  id: string;
  name: string;
  date: string;
  location?: string;
  events: string;
  goals?: string;
  notes?: string;
}

export interface InjuryEntry {
  id: string;
  date: string;
  injury: string;
  painLevel: number;
  treatment: string;
  returnToPlayDate: string;
  restrictions: string;
}

export type TrainingLogCategory =
  | "distance"
  | "sprint"
  | "jump"
  | "throw"
  | "strength";

export interface TrainingLogEntry {
  id: string;
  category: TrainingLogCategory;
  label: string;
  value: number;
  unit: string;
  date: string;
}

export interface CompetitionResult {
  id: string;
  date: string;
  meetName: string;
  event: string;
  result: string;
  place?: string;
  notes?: string;
}

export interface AttendanceEntry {
  id: string;
  date: string;
  present: boolean;
  note?: string;
}

export type KeepsakeType = "race_bib" | "meet_sticker" | "photo";

export interface KeepsakeEntry {
  id: string;
  type: KeepsakeType;
  title: string;
  meetName?: string;
  date: string;
  caption?: string;
}

export interface SeasonSummary {
  id: string;
  season: string;
  biggestImprovement: string;
  favoritePerformance: string;
  toughestChallenge: string;
  lessonsLearned: string;
  nextSeasonGoals: string;
  updatedAt: string;
}

export interface NutritionLogEntry {
  id: string;
  date: string;
  waterGlasses: number;
  proteinServings: number;
  fruitServings: number;
  vegetableServings: number;
  preWorkoutMeal: string;
  postWorkoutMeal: string;
  calories?: number;
  updatedAt: string;
}

export interface MindsetLesson {
  id: string;
  title: string;
  category: string;
  duration: string;
  description: string;
  completed: boolean;
}

export interface CoachMessage {
  id: string;
  message: string;
  date: string;
  focus: string;
}

export type CultureCategory =
  | "helping_teammates"
  | "cleaning_equipment"
  | "attendance"
  | "encouragement"
  | "volunteer_hours"
  | "leadership";

export interface CultureCategoryMeta {
  id: CultureCategory;
  label: string;
  description: string;
  pointsLabel: string;
  icon: string;
  /** Coach Whitney culture line for this category */
  coachLine: string;
}

export interface CulturePointEntry {
  id: string;
  athleteId: string;
  athleteName: string;
  category: CultureCategory;
  points: number;
  note: string;
  date: string;
}

export interface TeamCultureMember {
  id: string;
  name: string;
  grade: number;
  totalPoints: number;
  monthlyPoints: number;
  rank: number;
  breakdown: Record<CultureCategory, number>;
  highlight?: string;
  isCurrentUser?: boolean;
}

export interface AthleteCultureProfile {
  totalPoints: number;
  monthlyPoints: number;
  rank: number;
  teamSize: number;
  breakdown: Record<CultureCategory, number>;
  recentEntries: CulturePointEntry[];
}

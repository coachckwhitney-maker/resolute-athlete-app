import type { MindsetLesson } from "@/lib/types/athlete";

/** Favorite quotes — unmistakably Coach Whitney even without her name */
export interface FavoriteQuote {
  id: string;
  text: string;
  tag: string;
  lessonNote: string;
  category: string;
}

export const favoriteQuotes: FavoriteQuote[] = [
  {
    id: "nobody-watching",
    text: "Greatness isn't built on race day. It's built on the days nobody is watching.",
    tag: "Nobody Watching",
    lessonNote:
      "Meet day is the test — not the training. What you do on ordinary Tuesdays is what creates extraordinary Saturdays.",
    category: "Work Ethic",
  },
  {
    id: "door-open",
    text: "Talent may open the door, but discipline keeps it open.",
    tag: "Keep the Door Open",
    lessonNote:
      "Talent gets you in the room. Discipline, consistency, and standards are what keep you there — and what take you further than talent alone ever could.",
    category: "Discipline",
  },
  {
    id: "confidence-earned",
    text: "Confidence isn't something you're given. It's something you earn.",
    tag: "Earn Confidence",
    lessonNote:
      "You won't think your way into confidence. You prepare your way into it — rep by rep, habit by habit, day by day.",
    category: "Confidence",
  },
  {
    id: "hard-work",
    text: "When the work gets hard, that's where champions separate themselves.",
    tag: "When It Gets Hard",
    lessonNote:
      "Everyone can train when it's easy. The separation happens in the moments you want to quit — and choose not to.",
    category: "Champions",
  },
  {
    id: "choices-today",
    text: "Your future is built by the choices you make today.",
    tag: "Choices Today",
    lessonNote:
      "Every habit, every effort level, every decision to show up or skip out — you're building your future right now. Choose wisely.",
    category: "Identity",
  },
  {
    id: "every-rep",
    text: "Every rep is a vote for the athlete you're becoming.",
    tag: "Every Rep Counts",
    lessonNote:
      "Each rep is a small decision about who you are. Stack enough good votes and you become someone you can be proud of.",
    category: "Process",
  },
  {
    id: "excellence",
    text: "Don't just chase fast times. Chase excellence.",
    tag: "Chase Excellence",
    lessonNote:
      "Times are a result — not the mission. Pursue excellence in how you train, recover, lead, and compete. Fast follows when the standard is right.",
    category: "Excellence",
  },
  {
    id: "standard",
    text: "The standard is the standard.",
    tag: "The Standard",
    lessonNote:
      "We don't lower the bar because it's hard or because nobody's looking. The standard stays the standard — that's what makes this program different.",
    category: "Standards",
  },
  {
    id: "intentional",
    text: "Success isn't accidental. It's intentional.",
    tag: "Intentional Success",
    lessonNote:
      "Champions don't stumble into greatness. They build it on purpose — with plans, habits, and daily decisions that match where they say they want to go.",
    category: "Discipline",
  },
  {
    id: "teammates-best",
    text: "Your teammates deserve your best.",
    tag: "They Deserve Your Best",
    lessonNote:
      "You're not just training for yourself. Your energy, effort, and attitude affect everyone in the tent. Bring your best because they count on you.",
    category: "Team",
  },
];

export function favoriteQuoteToCoachSaying(quote: FavoriteQuote) {
  return {
    id: `favorite-${quote.id}`,
    text: quote.text,
    tag: quote.tag,
    lessonNote: quote.lessonNote,
    category: quote.category,
  };
}

export const favoriteQuotesCoachSayings = favoriteQuotes.map(favoriteQuoteToCoachSaying);

export function favoriteQuoteToLesson(
  quote: FavoriteQuote,
  completed = false
): MindsetLesson {
  return {
    id: `favorite-${quote.id}`,
    title: quote.text,
    category: quote.category,
    duration: "5 min",
    description: quote.lessonNote,
    completed,
  };
}

export const favoriteQuoteLessons: MindsetLesson[] = favoriteQuotes.map(
  (quote, i) => favoriteQuoteToLesson(quote, i === 5)
);

export function getDailyFavoriteQuote(date = new Date()): FavoriteQuote {
  const dayIndex =
    date.getFullYear() * 1000 + date.getMonth() * 50 + date.getDate();
  return favoriteQuotes[dayIndex % favoriteQuotes.length];
}

export const favoriteQuoteFeatured = favoriteQuotes[0];

import type { CoachMessage, MindsetLesson } from "@/lib/types/athlete";
import { favoriteQuotesCoachSayings } from "@/lib/data/favoriteQuotes";
import { mindsetPhilosophyLines } from "@/lib/data/mindsetPhilosophy";

/** Coach Whitney's voice — foundation sayings + daily athlete lines */
export interface CoachSaying {
  id: string;
  text: string;
  /** Short label for focus chips, marquee, etc. */
  tag: string;
  /** Coach context for mindset lessons */
  lessonNote: string;
  category: string;
}

/** Foundation — who you are as a coach */
export const signatureSayings: CoachSaying[] = [
  {
    id: "dream-to-be",
    text: "I will be the person I dream to be and not the person I accidentally become.",
    tag: "Dream to Be",
    lessonNote:
      "Every choice today is a vote for who you become. Don't drift — decide. Show up on purpose in training, school, and how you treat people.",
    category: "Identity",
  },
  {
    id: "ignite",
    text: "Ignite the fire.",
    tag: "Ignite the Fire",
    lessonNote:
      "Some days the fire is low. Your job isn't to wait for motivation — it's to spark it. One rep, one habit, one intentional act starts the flame.",
    category: "Motivation",
  },
  {
    id: "trust",
    text: "Trust the process.",
    tag: "Trust the Process",
    lessonNote:
      "Progress isn't always visible week to week. The work in the boring weeks is what shows up on meet day. Stay patient. Stay locked in.",
    category: "Process",
  },
  {
    id: "give",
    text: "You get what you give.",
    tag: "You Get What You Give",
    lessonNote:
      "Effort, energy, encouragement, preparation — it all comes back. Half-in gets half-out. Full commitment is the only way this works.",
    category: "Effort",
  },
  {
    id: "weakest-link",
    text: "We are only as strong as our weakest link.",
    tag: "Strongest Together",
    lessonNote:
      "Your team rises together. Lift the people around you. Don't leave anyone behind — culture, accountability, and championships are built as a unit.",
    category: "Team",
  },
  {
    id: "purpose",
    text: "Train with purpose.",
    tag: "Train With Purpose",
    lessonNote:
      "Every rep should have a reason. Know the why behind the workout. Random effort creates random results — intentional training builds champions.",
    category: "Training",
  },
  {
    id: "intention",
    text: "Built with intention.",
    tag: "Built With Intention",
    lessonNote:
      "Nothing great happens by accident. Sleep, nutrition, technique, attitude — build your day and your season on purpose, block by block.",
    category: "Discipline",
  },
  {
    id: "undeniable",
    text: "UNDENIABLE.",
    tag: "Undeniable",
    lessonNote:
      "When the work is done and the details are right, your performance speaks for itself. No excuses. No shortcuts. Make your effort undeniable.",
    category: "Excellence",
  },
  {
    id: "built-by-whitney",
    text: "Built by Whitney.",
    tag: "Built by Whitney",
    lessonNote:
      "This program is built on 20+ years of coaching real athletes — not a template from the internet. You're getting the whole athlete approach, every day.",
    category: "Resolute",
  },
  {
    id: "growth",
    text: "Growth can be uncomfortable, but it's always worth it.",
    tag: "Worth the Growth",
    lessonNote:
      "Getting better hurts sometimes — physically and mentally. Lean into the discomfort. That's where the breakthrough lives.",
    category: "Growth",
  },
];

/** What you say constantly to athletes — daily coaching identity */
export const athleteSayings: CoachSaying[] = [
  {
    id: "success-hands",
    text: "Your success is in your hands.",
    tag: "Your Hands",
    lessonNote:
      "I can coach you, plan for you, and believe in you — but I can't do the work for you. Ownership is everything. Take responsibility for today.",
    category: "Ownership",
  },
  {
    id: "show-up-purpose",
    text: "Show up with purpose.",
    tag: "Show Up With Purpose",
    lessonNote:
      "Being there isn't enough. Walk in knowing what you're working on, why it matters, and what standard you're holding yourself to.",
    category: "Presence",
  },
  {
    id: "consistency",
    text: "Consistency beats talent when talent isn't consistent.",
    tag: "Consistency Wins",
    lessonNote:
      "I've seen talented athletes fall short and disciplined athletes rise. The ones who show up every day — not just on good days — are the ones who win long term.",
    category: "Consistency",
  },
  {
    id: "little-things",
    text: "Do the little things right.",
    tag: "Little Things",
    lessonNote:
      "Warm-up quality, sleep, hydration, how you rack your weights, how you talk to teammates — the small stuff stacks up. Get the edges right.",
    category: "Details",
  },
  {
    id: "details",
    text: "Details matter.",
    tag: "Details Matter",
    lessonNote:
      "Arm action, shin angle, brace, recovery, attitude — championships are decided in the details most people skip. That's where we live.",
    category: "Details",
  },
  {
    id: "believe-work",
    text: "Believe in the work.",
    tag: "Believe in the Work",
    lessonNote:
      "Some days you won't feel it. Trust the plan anyway. The work is working even when the results haven't shown up yet.",
    category: "Faith",
  },
  {
    id: "worth-it",
    text: "Trust me when I say it's worth it.",
    tag: "It's Worth It",
    lessonNote:
      "I've coached this long enough to know — the hard days, the boring reps, the accountability nobody sees — it pays off. Stay with it.",
    category: "Trust",
  },
  {
    id: "work-shows",
    text: "The work always shows.",
    tag: "The Work Shows",
    lessonNote:
      "You can't fake preparation. When it's time to perform, what's inside comes out. Put in the work so meet day reflects who you've been becoming.",
    category: "Results",
  },
  {
    id: "no-shortcuts",
    text: "Don't chase shortcuts.",
    tag: "No Shortcuts",
    lessonNote:
      "There's no hack for speed, strength, or character. Skip steps and you'll find your ceiling. Do it the right way — every time.",
    category: "Discipline",
  },
  {
    id: "one-day",
    text: "Champions are built one day at a time.",
    tag: "One Day at a Time",
    lessonNote:
      "Don't overwhelm yourself with the whole season. Win today. Stack good days. That's how athletes become champions.",
    category: "Process",
  },
];

export const allCoachSayings: CoachSaying[] = [
  ...signatureSayings,
  ...athleteSayings,
  ...mindsetPhilosophyLines.map((line) => ({
    id: `philosophy-${line.id}`,
    text: line.text,
    tag: line.tag,
    lessonNote: line.lessonNote,
    category: line.category,
  })),
  ...favoriteQuotesCoachSayings,
];

/** Uppercase phrases for the scrolling ticker */
export const marqueeItems = [
  "CHOOSE TO BE THE DIFFERENCE",
  "YOUR TEAMMATES MATTER",
  "THE FAMILY MATTERS",
  "LEAD BY EXAMPLE",
  "YOUR WORDS HAVE POWER",
  "NO EXCUSES",
  "EFFORT IS A CHOICE",
  "OWN YOUR JOURNEY",
  "DETAILS MATTER",
  "SHOW UP WITH PURPOSE",
  "BELIEVE IN THE WORK",
  "TRUST THE PROCESS",
  "BUILT BY WHITNEY",
  "BUILD PEOPLE NOT JUST ATHLETES",
  "CHARACTER LASTS",
  "BEYOND THE SCOREBOARD",
  "THE STANDARD IS THE STANDARD",
  "CHASE EXCELLENCE",
  "EVERY REP COUNTS",
  "NOBODY IS WATCHING",
  "UNDENIABLE",
];

export function sayingToMindsetLesson(
  saying: CoachSaying,
  completed = false
): MindsetLesson {
  return {
    id: saying.id,
    title: saying.text,
    category: saying.category,
    duration: "5 min",
    description: saying.lessonNote,
    completed,
  };
}

export const signatureMindsetLessons: MindsetLesson[] = signatureSayings.map(
  (saying, i) => sayingToMindsetLesson(saying, i === 2)
);

export const athleteMindsetLessons: MindsetLesson[] = athleteSayings.map(
  (saying) => sayingToMindsetLesson(saying)
);

export const mindsetLessonsFromSayings: MindsetLesson[] = [
  ...signatureMindsetLessons,
  ...athleteMindsetLessons,
];

/** Pick a daily coach message — rotates through full coach voice */
export function getDailyCoachMessage(date = new Date()): CoachMessage {
  const dayIndex =
    date.getFullYear() * 1000 + date.getMonth() * 50 + date.getDate();
  const saying = allCoachSayings[dayIndex % allCoachSayings.length];

  return {
    id: `coach-${saying.id}`,
    message: saying.text,
    date: date.toISOString().slice(0, 10),
    focus: saying.tag,
  };
}

export const signatureFooter = "Built by Whitney.";

export const landingFeaturedQuote = signatureSayings[0];

export const sessionCompleteLine =
  "Every rep is a vote for the athlete you're becoming.";

/** Coach lines mapped to daily workout blocks */
export const workoutCoachLines: Record<string, string> = {
  warmup: athleteSayings.find((s) => s.id === "show-up-purpose")!.text,
  sprint: athleteSayings.find((s) => s.id === "details")!.text,
  lift: athleteSayings.find((s) => s.id === "believe-work")!.text,
  plyo: athleteSayings.find((s) => s.id === "no-shortcuts")!.text,
  mobility: athleteSayings.find((s) => s.id === "little-things")!.text,
  recovery: athleteSayings.find((s) => s.id === "work-shows")!.text,
};

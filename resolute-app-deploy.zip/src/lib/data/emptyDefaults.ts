import type {
  AccountabilityItem,
  Athlete,
  AttendanceEntry,
  BlueprintDimension,
  BlueprintScore,
  CompetitionResult,
  InjuryEntry,
  KeepsakeEntry,
  MeetPlan,
  NutritionLogEntry,
  SeasonSummary,
  PersonalRecord,
  TrainingLogEntry,
  WellnessMetric,
  WorkoutBlock,
} from "@/lib/types/athlete";

export const GENERIC_ATHLETE_STORAGE_KEY = "resolute-generic-athlete-data";
export const TEAM_ATHLETE_STORAGE_KEY = "resolute-team-athlete-data";
export const COACHED_ATHLETE_STORAGE_KEY = "resolute-coached-athlete-data";

export interface GenericAthleteData {
  athlete: Athlete;
  workouts: WorkoutBlock[];
  accountabilityItems: AccountabilityItem[];
  personalRecords: PersonalRecord[];
  wellnessMetrics: WellnessMetric[];
  blueprintScores: BlueprintScore[];
  meetPlans: MeetPlan[];
  injuries: InjuryEntry[];
  trainingLogs: TrainingLogEntry[];
  competitionResults: CompetitionResult[];
  attendance: AttendanceEntry[];
  keepsakes: KeepsakeEntry[];
  seasonSummaries: SeasonSummary[];
  nutritionLogs: NutritionLogEntry[];
}

const blueprintDimensions: { dimension: BlueprintDimension; label: string }[] = [
  { dimension: "speed", label: "Speed" },
  { dimension: "strength", label: "Strength" },
  { dimension: "mobility", label: "Mobility" },
  { dimension: "power", label: "Power" },
  { dimension: "recovery", label: "Recovery" },
  { dimension: "nutrition", label: "Nutrition" },
  { dimension: "mindset", label: "Mindset" },
  { dimension: "accountability", label: "Accountability" },
  { dimension: "leadership", label: "Leadership" },
  { dimension: "coachability", label: "Coachability" },
];

export function createEmptyBlueprintScores(): BlueprintScore[] {
  return blueprintDimensions.map(({ dimension, label }) => ({
    dimension,
    label,
    score: 0,
    trend: "flat" as const,
  }));
}

export function createEmptyGenericData(): GenericAthleteData {
  return {
    athlete: {
      id: "local",
      name: "",
      sport: "",
      team: "",
      grade: 0,
      readiness: "green",
      readinessNote: "",
      blueprintOverall: 0,
      streak: 0,
    },
    workouts: [],
    accountabilityItems: [],
    personalRecords: [],
    wellnessMetrics: [],
    blueprintScores: createEmptyBlueprintScores(),
    meetPlans: [],
    injuries: [],
    trainingLogs: [],
    competitionResults: [],
    attendance: [],
    keepsakes: [],
    seasonSummaries: [],
    nutritionLogs: [],
  };
}

export function computeBlueprintOverall(scores: BlueprintScore[]): number {
  const rated = scores.filter((s) => s.score > 0);
  if (rated.length === 0) return 0;
  return Math.round(rated.reduce((sum, s) => sum + s.score, 0) / rated.length);
}

export function createId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

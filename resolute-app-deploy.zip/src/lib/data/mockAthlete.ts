import type {
  AccountabilityItem,
  Athlete,
  BlueprintScore,
  CoachMessage,
  MindsetLesson,
  PersonalRecord,
  WellnessMetric,
  WorkoutBlock,
} from "@/lib/types/athlete";
import {
  getDailyCoachMessage,
  mindsetLessonsFromSayings,
  workoutCoachLines,
} from "@/lib/data/signatureSayings";
import { habitCoachLines } from "@/lib/data/accountabilitySayings";

export const athlete: Athlete = {
  id: "1",
  name: "Jordan",
  sport: "Track & Field",
  team: "Resolute Track Club",
  grade: 11,
  readiness: "yellow",
  readinessNote: "Slept 6 hours — check in before sprints",
  blueprintOverall: 82,
  streak: 12,
};

export const coachMessage: CoachMessage = getDailyCoachMessage();

export const todaysWorkout: WorkoutBlock[] = [
  {
    id: "warmup",
    title: "Dynamic Warm-Up",
    category: "warmup",
    duration: "12 min",
    description: "A-skips, B-skips, high knees, butt kicks, leg swings",
    why: "Prepares your nervous system for max velocity work. Cold muscles = slow muscles.",
    coachLine: workoutCoachLines.warmup,
    completed: true,
  },
  {
    id: "sprint",
    title: "6 × 40m Acceleration",
    category: "sprint",
    duration: "25 min",
    description: "Full recovery between reps. Focus on push, not reach.",
    why: "40m builds the acceleration phase — the first 30m wins races. We're training force into the ground, not overstriding.",
    coachLine: workoutCoachLines.sprint,
    completed: false,
  },
  {
    id: "lift",
    title: "Trap Bar Deadlift",
    category: "lift",
    duration: "20 min",
    description: "4 × 3 @ 85%. Rest 3 min. Brace hard, drive through the floor.",
    why: "Posterior chain strength is the engine for sprint speed. This transfers directly to your first 20 meters.",
    coachLine: workoutCoachLines.lift,
    completed: false,
  },
  {
    id: "plyo",
    title: "Depth Jumps + Bounds",
    category: "plyo",
    duration: "15 min",
    description: "4 × 4 depth jumps from 18\". 4 × 30m bounds with full recovery.",
    why: "Teaches your body to absorb and redirect force — critical for block starts and hurdle clearance.",
    coachLine: workoutCoachLines.plyo,
    completed: false,
  },
  {
    id: "mobility",
    title: "Hip & Ankle Mobility",
    category: "mobility",
    duration: "10 min",
    description: "90/90 hip switches, ankle dorsiflexion drills, couch stretch",
    why: "Restricted hips limit stride length. Mobile ankles improve shin angle at ground contact.",
    coachLine: workoutCoachLines.mobility,
    completed: false,
  },
  {
    id: "recovery",
    title: "Recovery Checklist",
    category: "recovery",
    duration: "5 min",
    description: "Foam roll quads/hamstrings, 10 min walk, hydration log",
    why: "Recovery is training. What you do after the workout determines how you adapt.",
    coachLine: workoutCoachLines.recovery,
    completed: false,
  },
];

export const accountabilityItems: AccountabilityItem[] = [
  { id: "sleep", label: "Slept 8+ hours", completed: false, category: "recovery", coachLine: habitCoachLines.sleep },
  { id: "hydrate", label: "Hydrated (80+ oz)", completed: true, category: "recovery", coachLine: habitCoachLines.hydrate },
  { id: "protein", label: "Protein goal hit", completed: false, category: "nutrition", coachLine: habitCoachLines.protein },
  { id: "mobility", label: "Mobility completed", completed: false, category: "training", coachLine: habitCoachLines.mobility },
  { id: "lift", label: "Lift completed", completed: false, category: "training", coachLine: habitCoachLines.lift },
  { id: "sprint", label: "Sprint session done", completed: false, category: "training", coachLine: habitCoachLines.sprint },
  { id: "homework", label: "Homework complete", completed: true, category: "life", coachLine: habitCoachLines.homework },
  { id: "mental", label: "Mental health check-in", completed: false, category: "mindset", coachLine: habitCoachLines.mental },
];

export const personalRecords: PersonalRecord[] = [
  { id: "1", event: "100m", value: "11.34", date: "2026-06-14", previous: "11.52" },
  { id: "2", event: "200m", value: "23.18", date: "2026-05-22", previous: "23.45" },
  { id: "3", event: "40-yard dash", value: "4.68", date: "2026-06-14", previous: "4.74" },
  { id: "4", event: "Flying 10m", value: "1.02", date: "2026-06-01", previous: "1.05" },
  { id: "5", event: "Vertical Jump", value: "32\"", date: "2026-05-15", previous: "30\"" },
  { id: "6", event: "Broad Jump", value: "9'2\"", date: "2026-05-15" },
  { id: "7", event: "Trap Bar DL", value: "405 lbs", date: "2026-06-28", previous: "385 lbs" },
  { id: "8", event: "Back Squat", value: "315 lbs", date: "2026-04-10" },
];

export const wellnessMetrics: WellnessMetric[] = [
  { id: "1", label: "Sleep", value: 6, unit: "hrs", date: "2026-07-07" },
  { id: "2", label: "Body Weight", value: 165, unit: "lbs", date: "2026-07-07" },
  { id: "3", label: "Soreness", value: 4, unit: "/10", date: "2026-07-07" },
  { id: "4", label: "Energy", value: 6, unit: "/10", date: "2026-07-07" },
  { id: "5", label: "Motivation", value: 8, unit: "/10", date: "2026-07-07" },
];

export const blueprintScores: BlueprintScore[] = [
  { dimension: "speed", label: "Speed", score: 88, trend: "up" },
  { dimension: "strength", label: "Strength", score: 85, trend: "up" },
  { dimension: "mobility", label: "Mobility", score: 72, trend: "flat" },
  { dimension: "power", label: "Power", score: 84, trend: "up" },
  { dimension: "recovery", label: "Recovery", score: 68, trend: "down" },
  { dimension: "nutrition", label: "Nutrition", score: 75, trend: "flat" },
  { dimension: "mindset", label: "Mindset", score: 90, trend: "up" },
  { dimension: "accountability", label: "Accountability", score: 86, trend: "up" },
  { dimension: "leadership", label: "Leadership", score: 82, trend: "flat" },
  { dimension: "coachability", label: "Coachability", score: 94, trend: "up" },
];

export const mindsetLessons: MindsetLesson[] = mindsetLessonsFromSayings;

export const categoryLabels: Record<string, string> = {
  warmup: "Warm-Up",
  sprint: "Sprint",
  lift: "Lift",
  plyo: "Plyometrics",
  mobility: "Mobility",
  recovery: "Recovery",
};

export const categoryColors: Record<string, string> = {
  warmup: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  sprint: "bg-red-500/20 text-red-300 border-red-500/30",
  lift: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  plyo: "bg-purple-500/20 text-purple-300 border-purple-500/30",
  mobility: "bg-green-500/20 text-green-300 border-green-500/30",
  recovery: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
};

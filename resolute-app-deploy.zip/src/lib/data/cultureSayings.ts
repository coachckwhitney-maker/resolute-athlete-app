import type { MindsetLesson } from "@/lib/types/athlete";

/** Unmistakably Coach Whitney — team culture voice */
export interface CultureStatement {
  id: string;
  text: string;
  tag: string;
  lessonNote: string;
  category: string;
}

export const cultureStatements: CultureStatement[] = [
  {
    id: "difference",
    text: "Choose to be the difference.",
    tag: "Be the Difference",
    lessonNote:
      "Anyone can go through the motions. Resolute athletes choose to elevate the room — in effort, attitude, and how they treat people.",
    category: "Impact",
  },
  {
    id: "give-back",
    text: "Give back to this program what it has given to you.",
    tag: "Give Back",
    lessonNote:
      "This team has invested in you — time, belief, opportunity. Leave it better. Clean up, show up, lift others, and honor what you've received.",
    category: "Gratitude",
  },
  {
    id: "teammates",
    text: "Your teammates matter.",
    tag: "Teammates Matter",
    lessonNote:
      "You're not on this journey alone. How you treat the person next to you defines our culture — and your character.",
    category: "Team",
  },
  {
    id: "family",
    text: "The family we've built matters.",
    tag: "The Family",
    lessonNote:
      "Resolute is more than a team. Protect the culture we've built. Show up for each other like family does.",
    category: "Family",
  },
  {
    id: "push-better",
    text: "Push each other to be better.",
    tag: "Push Each Other",
    lessonNote:
      "Iron sharpens iron. Hold each other to a high standard — in reps, in effort, and how we compete together.",
    category: "Excellence",
  },
  {
    id: "words",
    text: "Your words have power.",
    tag: "Words Have Power",
    lessonNote:
      "What you say to a teammate can build them up or tear them down. Choose words that make people better — especially when it's hard.",
    category: "Leadership",
  },
  {
    id: "lead-example",
    text: "Lead by example.",
    tag: "Lead by Example",
    lessonNote:
      "Don't wait for a title to lead. The best captains are the ones who do the right thing when nobody's watching.",
    category: "Leadership",
  },
  {
    id: "changing-lives",
    text: "You never know whose life you're changing.",
    tag: "Changing Lives",
    lessonNote:
      "That encouraging word, that extra rep together, showing up for someone struggling — you might be the reason someone keeps going.",
    category: "Impact",
  },
];

export function cultureStatementToLesson(
  statement: CultureStatement,
  completed = false
): MindsetLesson {
  return {
    id: `culture-${statement.id}`,
    title: statement.text,
    category: statement.category,
    duration: "5 min",
    description: statement.lessonNote,
    completed,
  };
}

export const cultureMindsetLessons: MindsetLesson[] = cultureStatements.map(
  (statement) => cultureStatementToLesson(statement)
);

export function getDailyCultureStatement(date = new Date()): CultureStatement {
  const dayIndex =
    date.getFullYear() * 1000 + date.getMonth() * 50 + date.getDate();
  return cultureStatements[dayIndex % cultureStatements.length];
}

export const cultureFeaturedStatement = cultureStatements[0];

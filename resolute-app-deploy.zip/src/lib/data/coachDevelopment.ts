export const coachDevelopmentHeadline = {
  tag: "Coach Development",
  title: "Build Winning Teams",
  subtitle:
    "Mentorship on culture and whole-athlete development — or hire Whitney on-site to train your team in speed, agility, and strength.",
};

export const coachDevelopmentCard = {
  tag: "For Coaches",
  title: coachDevelopmentHeadline.title,
  description:
    "Team development mentorship — or hire Coach Whitney to train your athletes in speed, agility, and strength on-site.",
  cta: "Explore team development",
};

export const coachDevelopmentIntro =
  "Whitney mentors coaches on culture, mindset, and accountability — and she also works directly with teams on the track and in the weight room. Speed, agility, strength: the physical development that supports everything else.";

export const coachOfferings = [
  {
    id: "mentorship",
    title: "1:1 Coach Mentorship",
    description:
      "Proven guidance on leadership, athlete communication, and the daily culture decisions that build teams people want to be part of.",
    topics: ["Leadership voice", "Hard conversations", "Athlete buy-in"],
  },
  {
    id: "culture",
    title: "Team Culture Systems",
    description:
      "Build a family — not just a roster. Learn how to reward character, attendance, and leadership alongside performance.",
    topics: ["Culture points", "Team standards", "Parent & athlete alignment"],
  },
  {
    id: "blueprint",
    title: "Whole-Athlete Blueprint",
    description:
      "Go beyond times and marks. Use the 10-dimension framework to develop complete athletes who can actually win when it matters.",
    topics: ["10 dimensions", "Holistic development", "Long-term athlete growth"],
  },
  {
    id: "mindset",
    title: "Mindset & Accountability",
    description:
      "Coach the person, not just the performance. Tools for confidence, failure, pressure, and the habits that stack into champions.",
    topics: ["Daily messaging", "Accountability language", "Pre-meet & race-day voice"],
  },
  {
    id: "on-site-training",
    title: "Hire Whitney to Train Your Team",
    description:
      "Bring Coach Whitney to your program for hands-on speed, agility, and strength development — clinics, camp days, or team training built on 20+ years of proven results.",
    topics: ["Speed development", "Agility & plyometrics", "Strength training"],
    featured: true,
  },
] as const;

export const coachPhilosophyQuotes = [
  {
    text: "I don't just build athletes — I build people.",
    tag: "Foundation",
  },
  {
    text: "The goal is always to win — but you can't become a champion by developing one thing and ignoring the rest.",
    tag: "Whole Athlete",
  },
  {
    text: "Excuses don't build champions. I love you enough to tell you the truth.",
    tag: "Accountability",
  },
] as const;

export const coachCredibility = [
  { value: "20+", label: "Years Coaching" },
  { value: "10", label: "Blueprint Dimensions" },
  { value: "Resolute", label: "Resolute Track Club" },
] as const;

export const coachInquiryCta = {
  primary: "Inquire About Team Development",
  secondary:
    "Tell Whitney about your team — size, sport, and where you want to grow on culture and whole-athlete development.",
};

export const coachTrainingInquiryCta = {
  primary: "Inquire About On-Site Training",
  secondary:
    "Hire Coach Whitney to train your team in speed, agility, and strength — clinics, camps, or ongoing sessions at your facility.",
};

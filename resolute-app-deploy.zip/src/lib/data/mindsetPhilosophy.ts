import type { MindsetLesson } from "@/lib/types/athlete";

/** Where Coach Whitney's heart shows — building people, not just athletes */
export interface MindsetPhilosophyLine {
  id: string;
  text: string;
  tag: string;
  lessonNote: string;
  category: string;
}

export const mindsetPhilosophyLines: MindsetPhilosophyLine[] = [
  {
    id: "build-people",
    text: "I don't just build athletes—I build people.",
    tag: "Build People",
    lessonNote:
      "Track is what we do — but it's not all you are. I'm coaching the whole person: character, confidence, discipline, and who you become when the season ends.",
    category: "Purpose",
  },
  {
    id: "gift",
    text: "Sports changed my life. I coach so I can give that gift to someone else.",
    tag: "Pass the Gift",
    lessonNote:
      "I know what this sport can do for a kid — belief, structure, belonging, confidence. That's why I show up every day. I want that for you.",
    category: "Heart",
  },
  {
    id: "confidence",
    text: "Confidence is built through preparation.",
    tag: "Built Through Prep",
    lessonNote:
      "You don't walk into a meet hoping to feel confident. You earn it in the weeks nobody sees — the reps, the habits, the boring work. Preparation is the source.",
    category: "Confidence",
  },
  {
    id: "character",
    text: "Character lasts longer than medals.",
    tag: "Character Lasts",
    lessonNote:
      "Medals fade. Times get broken. Who you are — how you treat people, how you handle losing, how you show up — that stays with you forever.",
    category: "Character",
  },
  {
    id: "scoreboard",
    text: "The scoreboard doesn't define you.",
    tag: "Beyond the Scoreboard",
    lessonNote:
      "One race, one result, one bad day — none of that is your whole story. You're more than a time or a place. Don't let a number shrink who you are.",
    category: "Identity",
  },
  {
    id: "identity",
    text: "Your identity is bigger than your performance.",
    tag: "Bigger Identity",
    lessonNote:
      "You're a person first, an athlete second. Performance matters — but it doesn't determine your worth. Build an identity that holds up on good days and bad.",
    category: "Identity",
  },
];

export function mindsetPhilosophyToLesson(
  line: MindsetPhilosophyLine,
  completed = false
): MindsetLesson {
  return {
    id: `philosophy-${line.id}`,
    title: line.text,
    category: line.category,
    duration: "5 min",
    description: line.lessonNote,
    completed,
  };
}

export const mindsetPhilosophyLessons: MindsetLesson[] = mindsetPhilosophyLines.map(
  (line, i) => mindsetPhilosophyToLesson(line, i === 0)
);

export function getDailyMindsetPhilosophy(date = new Date()): MindsetPhilosophyLine {
  const dayIndex =
    date.getFullYear() * 1000 + date.getMonth() * 50 + date.getDate();
  return mindsetPhilosophyLines[dayIndex % mindsetPhilosophyLines.length];
}

export const mindsetPhilosophyFeatured = mindsetPhilosophyLines[0];

/** For daily coach message rotation on dashboard */
export const mindsetPhilosophyCoachPool = mindsetPhilosophyLines.map((line) => ({
  id: line.id,
  text: line.text,
  tag: line.tag,
}));

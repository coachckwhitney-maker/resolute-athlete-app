import type {
  AthleteCultureProfile,
  CultureCategoryMeta,
  TeamCultureMember,
} from "@/lib/types/athlete";
import { getDailyCultureStatement } from "@/lib/data/cultureSayings";

export const cultureCategories: CultureCategoryMeta[] = [
  {
    id: "helping_teammates",
    label: "Helping Teammates",
    description: "Carrying spikes, sharing knowledge, picking up a struggling teammate",
    pointsLabel: "+15 pts",
    icon: "🤝",
    coachLine: "Your teammates matter.",
  },
  {
    id: "cleaning_equipment",
    label: "Cleaning Equipment",
    description: "Hurdles, blocks, mats, team tent — leave it better than you found it",
    pointsLabel: "+10 pts",
    icon: "🧹",
    coachLine: "Give back to this program what it has given to you.",
  },
  {
    id: "attendance",
    label: "Attendance",
    description: "Showing up on time, every practice, every meet",
    pointsLabel: "+10 pts",
    icon: "📍",
    coachLine: "Lead by example.",
  },
  {
    id: "encouragement",
    label: "Encouragement",
    description: "Lifting others up when it matters most",
    pointsLabel: "+5 pts",
    icon: "💬",
    coachLine: "Your words have power.",
  },
  {
    id: "volunteer_hours",
    label: "Volunteer Hours",
    description: "Meets, community events, club service",
    pointsLabel: "+20 pts/hr",
    icon: "❤️",
    coachLine: "Choose to be the difference.",
  },
  {
    id: "leadership",
    label: "Leadership",
    description: "Leading warm-ups, captains, mentoring younger athletes",
    pointsLabel: "+25 pts",
    icon: "⭐",
    coachLine: "You never know whose life you're changing.",
  },
];

export const athleteCulture: AthleteCultureProfile = {
  totalPoints: 485,
  monthlyPoints: 120,
  rank: 3,
  teamSize: 24,
  breakdown: {
    helping_teammates: 85,
    cleaning_equipment: 60,
    attendance: 150,
    encouragement: 45,
    volunteer_hours: 80,
    leadership: 65,
  },
  recentEntries: [
    {
      id: "1",
      athleteId: "1",
      athleteName: "Jordan",
      category: "encouragement",
      points: 5,
      note: "Pumped up the 4×1 before their race",
      date: "2026-07-06",
    },
    {
      id: "2",
      athleteId: "1",
      athleteName: "Jordan",
      category: "cleaning_equipment",
      points: 10,
      note: "Put away all hurdles after practice",
      date: "2026-07-05",
    },
    {
      id: "3",
      athleteId: "1",
      athleteName: "Jordan",
      category: "attendance",
      points: 10,
      note: "On time — full practice",
      date: "2026-07-05",
    },
  ],
};

export const teamCultureLeaderboard: TeamCultureMember[] = [
  {
    id: "2",
    name: "Mia",
    grade: 12,
    totalPoints: 620,
    monthlyPoints: 165,
    rank: 1,
    highlight: "Culture Champion — lives it every day",
    breakdown: {
      helping_teammates: 120,
      cleaning_equipment: 90,
      attendance: 180,
      encouragement: 80,
      volunteer_hours: 100,
      leadership: 50,
    },
  },
  {
    id: "3",
    name: "Devon",
    grade: 10,
    totalPoints: 540,
    monthlyPoints: 140,
    rank: 2,
    highlight: "Never misses — leads by example",
    breakdown: {
      helping_teammates: 70,
      cleaning_equipment: 50,
      attendance: 200,
      encouragement: 60,
      volunteer_hours: 60,
      leadership: 100,
    },
  },
  {
    id: "1",
    name: "Jordan",
    grade: 11,
    totalPoints: 485,
    monthlyPoints: 120,
    rank: 3,
    isCurrentUser: true,
    breakdown: {
      helping_teammates: 85,
      cleaning_equipment: 60,
      attendance: 150,
      encouragement: 45,
      volunteer_hours: 80,
      leadership: 65,
    },
  },
  {
    id: "4",
    name: "Alex",
    grade: 9,
    totalPoints: 410,
    monthlyPoints: 95,
    rank: 4,
    breakdown: {
      helping_teammates: 100,
      cleaning_equipment: 40,
      attendance: 120,
      encouragement: 70,
      volunteer_hours: 40,
      leadership: 40,
    },
  },
  {
    id: "5",
    name: "Sam",
    grade: 11,
    totalPoints: 380,
    monthlyPoints: 80,
    rank: 5,
    breakdown: {
      helping_teammates: 50,
      cleaning_equipment: 70,
      attendance: 140,
      encouragement: 30,
      volunteer_hours: 50,
      leadership: 40,
    },
  },
];

export const cultureCoachMessage = getDailyCultureStatement().text;

export function getCategoryMeta(id: string) {
  return cultureCategories.find((c) => c.id === id);
}

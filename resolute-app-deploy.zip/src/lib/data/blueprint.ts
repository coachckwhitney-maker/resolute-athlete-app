import type { BlueprintDimension } from "@/lib/types/athlete";

export const blueprintPhilosophy = {
  headline: "Develop The Whole Athlete",
  tagline: "Details matter. Champions are built one day at a time.",
  subhead:
    "That's the most important thing we do. The goal is always to win — but you can't become a champion by developing one thing and ignoring the rest. Do the little things right. Your success is in your hands.",
  before: "One PR makes me a champion.",
  after: "Am I developing the whole athlete?",
  beforeSub: "One dimension",
  afterSub: "Whole athlete",
  coachQuote:
    "I don't just build athletes—I build people. Sports changed my life, and I coach to give that gift to someone else. The goal is always to win — but character lasts longer than medals. Your identity is bigger than your performance.",
};

export const blueprintDimensionInfo: Record<
  BlueprintDimension,
  { description: string; why: string }
> = {
  speed: {
    description: "Acceleration, max velocity, and race performance",
    why: "Champions are fast — but speed is one dimension. It grows when mechanics, strength, and recovery are all in place.",
  },
  strength: {
    description: "Force production in the weight room",
    why: "You can't be a complete athlete without strength. Champions develop it rep by rep.",
  },
  mobility: {
    description: "Range of motion, flexibility, injury prevention",
    why: "Champions stay healthy long enough to reach their potential. Mobility keeps you competing.",
  },
  power: {
    description: "Explosiveness — jumps, bounds, plyometrics",
    why: "Power wins races. It's part of the whole athlete — connecting strength to speed on the track.",
  },
  recovery: {
    description: "Sleep, rest, and how well your body adapts",
    why: "The work doesn't count if you don't recover. Champions treat recovery as part of training.",
  },
  nutrition: {
    description: "Fueling, hydration, and body composition",
    why: "You can't out-train bad fuel. Nutrition determines whether every other dimension can work.",
  },
  mindset: {
    description: "Confidence, focus, handling pressure and failure",
    why: "Confidence is built through preparation. The scoreboard doesn't define you — your identity is bigger than your performance.",
  },
  accountability: {
    description: "Daily habits, consistency, showing up",
    why: "Champions win boring days. Accountability turns potential into progress over months and years.",
  },
  leadership: {
    description: "How you impact teammates and team culture",
    why: "The best athletes make everyone around them better. Leadership is part of becoming a champion.",
  },
  coachability: {
    description: "Growth mindset, taking feedback, trusting the process",
    why: "Champions keep getting better. Coachability is what makes every dimension keep growing.",
  },
};

export const blueprintPillars = [
  {
    label: "Physical",
    dims: ["Speed", "Strength", "Mobility", "Power"],
    note: "What you develop on the track and in the weight room",
  },
  {
    label: "Recovery",
    dims: ["Recovery", "Nutrition"],
    note: "What makes the work actually count",
  },
  {
    label: "Mental",
    dims: ["Mindset", "Accountability"],
    note: "What separates good athletes from champions",
  },
  {
    label: "Character",
    dims: ["Leadership", "Coachability"],
    note: "What makes you a champion — not just a fast athlete",
  },
];

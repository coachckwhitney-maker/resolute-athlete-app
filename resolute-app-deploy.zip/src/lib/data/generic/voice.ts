import type { CoachMessage, MindsetLesson } from "@/lib/types/athlete";

export const genericCoachName = "Your Coach";

export const genericMarqueeItems = [
  "DISCIPLINE",
  "CONSISTENCY",
  "RECOVERY",
  "STRENGTH",
  "SPEED",
  "WHOLE ATHLETE",
  "SHOW UP",
  "DO THE WORK",
];

const genericDailyMessages: Omit<CoachMessage, "date">[] = [
  {
    id: "g1",
    message: "Focus on what you can control today — effort, habits, and attitude.",
    focus: "Daily Focus",
  },
  {
    id: "g2",
    message: "Champions are built in the weeks nobody sees. Win today.",
    focus: "Process",
  },
  {
    id: "g3",
    message: "Train with purpose. Every session should have a reason.",
    focus: "Purpose",
  },
  {
    id: "g4",
    message: "Recovery is part of training. Don't skip what helps you adapt.",
    focus: "Recovery",
  },
  {
    id: "g5",
    message: "Small daily habits stack into big results over time.",
    focus: "Habits",
  },
  {
    id: "g6",
    message: "Be coachable. The athletes who keep improving ask what they can fix.",
    focus: "Growth",
  },
];

export function getGenericDailyCoachMessage(date = new Date()): CoachMessage {
  const dayIndex =
    date.getFullYear() * 1000 + date.getMonth() * 50 + date.getDate();
  const msg = genericDailyMessages[dayIndex % genericDailyMessages.length];
  return { ...msg, date: date.toISOString().slice(0, 10) };
}

export const genericBlueprintPhilosophy = {
  headline: "Develop The Whole Athlete",
  tagline: "More than workouts — a complete development system.",
  subhead:
    "Speed, strength, recovery, mindset, and character all matter. Track your progress across every dimension, not just one PR.",
  before: "One PR defines me.",
  after: "Am I developing every dimension?",
  beforeSub: "One result",
  afterSub: "Whole athlete",
  coachQuote:
    "The best athletes develop more than speed. They build strength, recovery, mindset, and accountability — and winning becomes possible when the whole picture is in place.",
};

export const genericCultureMessage =
  "Great teams are built on more than times. Show up, encourage teammates, and leave every practice better than you found it.";

export const genericSessionCompleteLine =
  "Daily habits done. Stack another good day.";

export const genericAccountabilityFeatured =
  "Consistency beats motivation. Show up even when you don't feel like it.";

export const genericMindsetFeatured =
  "Your mindset is a skill. You can train it like anything else.";

export const genericLandingSubtitle =
  "Your blank athlete tracker — log workouts, habits, PRs, and scores. Nothing pre-filled.";

export const genericCoachBentoLine =
  "Start empty. Build your own training log.";

export const genericMindsetLessons: MindsetLesson[] = [
  {
    id: "g-m1",
    title: "Trust the process.",
    category: "Process",
    duration: "5 min",
    description:
      "Results aren't always visible week to week. Stay patient and keep stacking good training days.",
    completed: false,
  },
  {
    id: "g-m2",
    title: "Effort is a choice.",
    category: "Effort",
    duration: "5 min",
    description:
      "Some days motivation is low. Discipline is choosing to show up anyway.",
    completed: false,
  },
  {
    id: "g-m3",
    title: "Confidence comes from preparation.",
    category: "Confidence",
    duration: "5 min",
    description:
      "You earn belief through reps, habits, and consistent work — not wishful thinking.",
    completed: false,
  },
  {
    id: "g-m4",
    title: "Handle pressure with routine.",
    category: "Performance",
    duration: "5 min",
    description:
      "When it matters most, fall back on what you've practiced — breathing, cues, and pre-performance habits.",
    completed: false,
  },
  {
    id: "g-m5",
    title: "Learn from bad days.",
    category: "Resilience",
    duration: "5 min",
    description:
      "A rough session or race doesn't define you. Extract the lesson and move forward.",
    completed: false,
  },
  {
    id: "g-m6",
    title: "Set goals you control.",
    category: "Planning",
    duration: "5 min",
    description:
      "Process goals — sleep, effort, technique — lead to outcomes you can't always control.",
    completed: false,
  },
];

export const genericWorkoutCoachLines: Record<string, string> = {
  warmup: "Prepare with intention.",
  sprint: "Details matter in every rep.",
  lift: "Strength supports everything else.",
  plyo: "Power is trained, not hoped for.",
  mobility: "Stay healthy enough to keep progressing.",
  recovery: "Adaptation happens after the work.",
};

export const genericHabitCoachLines: Record<string, string> = {
  sleep: "Recovery starts with sleep.",
  hydrate: "Fuel the work you're doing.",
  protein: "Support what you're building.",
  mobility: "Small maintenance, big payoff.",
  lift: "Strength is non-negotiable.",
  sprint: "Speed is a skill — practice it.",
  homework: "Balance matters off the track too.",
  mental: "Check in with yourself honestly.",
};

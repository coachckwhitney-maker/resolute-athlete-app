import type { MindsetLesson } from "@/lib/types/athlete";

/** What Coach Whitney says in hard conversations — accountability voice */
export interface AccountabilityLine {
  id: string;
  text: string;
  tag: string;
  lessonNote: string;
  category: string;
}

export const accountabilityLines: AccountabilityLine[] = [
  {
    id: "challenge-believe",
    text: "I will always challenge you because I believe in you.",
    tag: "Because I Believe",
    lessonNote:
      "Hard coaching isn't punishment — it's proof I see your potential. When I push you, it's because I know what you're capable of becoming.",
    category: "Belief",
  },
  {
    id: "holding-accountable",
    text: "Part of my job is holding you accountable.",
    tag: "My Job",
    lessonNote:
      "Accountability isn't optional here. I will call out shortcuts, missed habits, and excuses — because that's what real coaching looks like.",
    category: "Standards",
  },
  {
    id: "tell-truth",
    text: "I love you enough to tell you the truth.",
    tag: "Tell the Truth",
    lessonNote:
      "I won't tell you what you want to hear if it's not what you need to hear. Honesty is how we build trust — and champions.",
    category: "Honesty",
  },
  {
    id: "no-excuses",
    text: "Excuses don't build champions.",
    tag: "No Excuses",
    lessonNote:
      "Everyone has a reason. Champions decide what they're going to do anyway. Drop the story — do the work.",
    category: "Discipline",
  },
  {
    id: "effort-choice",
    text: "Effort is a choice.",
    tag: "Effort Is a Choice",
    lessonNote:
      "Some days you won't feel like it. Show up anyway. How hard you try today is a decision only you can make.",
    category: "Effort",
  },
  {
    id: "talent-discipline",
    text: "Talent doesn't replace discipline.",
    tag: "Discipline Over Talent",
    lessonNote:
      "Talent gets you noticed. Discipline gets you better — day after day, when nobody's watching. Don't rely on what came easy.",
    category: "Discipline",
  },
  {
    id: "own-journey",
    text: "Own your journey.",
    tag: "Own Your Journey",
    lessonNote:
      "Your results, your habits, your response to hard feedback — that's yours. Take ownership. Nobody can do this for you.",
    category: "Ownership",
  },
];

export function accountabilityLineToLesson(
  line: AccountabilityLine,
  completed = false
): MindsetLesson {
  return {
    id: `accountability-${line.id}`,
    title: line.text,
    category: line.category,
    duration: "5 min",
    description: line.lessonNote,
    completed,
  };
}

export const accountabilityMindsetLessons: MindsetLesson[] = accountabilityLines.map(
  (line) => accountabilityLineToLesson(line)
);

export function getDailyAccountabilityLine(date = new Date()): AccountabilityLine {
  const dayIndex =
    date.getFullYear() * 1000 + date.getMonth() * 50 + date.getDate();
  return accountabilityLines[dayIndex % accountabilityLines.length];
}

export const accountabilityFeaturedLine = accountabilityLines[3]; // Excuses don't build champions

/** One coach line per daily habit category */
export const habitCoachLines: Record<string, string> = {
  sleep: accountabilityLines.find((l) => l.id === "effort-choice")!.text,
  hydrate: accountabilityLines.find((l) => l.id === "own-journey")!.text,
  protein: accountabilityLines.find((l) => l.id === "talent-discipline")!.text,
  mobility: accountabilityLines.find((l) => l.id === "holding-accountable")!.text,
  lift: accountabilityLines.find((l) => l.id === "no-excuses")!.text,
  sprint: accountabilityLines.find((l) => l.id === "challenge-believe")!.text,
  homework: accountabilityLines.find((l) => l.id === "own-journey")!.text,
  mental: accountabilityLines.find((l) => l.id === "tell-truth")!.text,
};

export const accountabilityCompleteLine =
  accountabilityLines.find((l) => l.id === "effort-choice")!.text;

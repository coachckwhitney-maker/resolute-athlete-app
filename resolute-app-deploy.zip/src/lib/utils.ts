import { clsx, type ClassValue } from "clsx";

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function getReadinessColor(status: "green" | "yellow" | "red") {
  switch (status) {
    case "green":
      return "text-resolute-red bg-resolute-red/10 border-resolute-red/30";
    case "yellow":
      return "text-resolute-warning bg-resolute-warning/10 border-resolute-warning/30";
    case "red":
      return "text-resolute-danger bg-resolute-danger/10 border-resolute-danger/30";
  }
}

export function getReadinessDot(status: "green" | "yellow" | "red") {
  switch (status) {
    case "green":
      return "bg-resolute-red shadow-[0_0_8px_rgba(206,255,0,0.6)]";
    case "yellow":
      return "bg-resolute-warning";
    case "red":
      return "bg-resolute-danger";
  }
}

export function getTrendIcon(trend: "up" | "down" | "flat") {
  switch (trend) {
    case "up":
      return "↑";
    case "down":
      return "↓";
    case "flat":
      return "→";
  }
}

export function getScoreColor(score: number) {
  if (score >= 85) return "text-resolute-red";
  if (score >= 70) return "text-white";
  return "text-resolute-warning";
}

export function getScoreBarColor(score: number) {
  if (score >= 85) return "bg-resolute-red";
  if (score >= 70) return "bg-white";
  return "bg-resolute-warning";
}

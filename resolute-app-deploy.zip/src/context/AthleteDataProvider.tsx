"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useAppTier } from "@/context/AppTierProvider";
import {
  computeBlueprintOverall,
  createEmptyGenericData,
  createId,
  type GenericAthleteData,
} from "@/lib/data/emptyDefaults";
import { loadAthleteData, saveAthleteData } from "@/lib/storage/athleteStorage";
import {
  canStoreKeepsakes,
  loadKeepsakeImages,
  removeKeepsakeImage,
  saveKeepsakeImage,
} from "@/lib/storage/keepsakeStorage";
import {
  athlete as demoAthlete,
  accountabilityItems as demoAccountability,
  blueprintScores as demoBlueprintScores,
  personalRecords as demoPersonalRecords,
  todaysWorkout as demoWorkouts,
  wellnessMetrics as demoWellness,
} from "@/lib/data/mockAthlete";
import type { AppTier } from "@/lib/types/appTier";
import type {
  AccountabilityItem,
  AttendanceEntry,
  Athlete,
  BlueprintDimension,
  BlueprintScore,
  CompetitionResult,
  InjuryEntry,
  KeepsakeEntry,
  MeetPlan,
  NutritionLogEntry,
  SeasonSummary,
  PersonalRecord,
  TrainingLogEntry,
  WellnessMetric,
  WorkoutBlock,
} from "@/lib/types/athlete";

interface AthleteDataContextValue {
  ready: boolean;
  isBlankSlate: boolean;
  canSelfTrack: boolean;
  canManageKeepsakes: boolean;
  canManageSeasonSummary: boolean;
  canManageNutrition: boolean;
  athlete: Athlete;
  workouts: WorkoutBlock[];
  accountabilityItems: AccountabilityItem[];
  personalRecords: PersonalRecord[];
  wellnessMetrics: WellnessMetric[];
  blueprintScores: BlueprintScore[];
  meetPlans: MeetPlan[];
  injuries: InjuryEntry[];
  trainingLogs: TrainingLogEntry[];
  competitionResults: CompetitionResult[];
  attendance: AttendanceEntry[];
  keepsakes: KeepsakeEntry[];
  seasonSummaries: SeasonSummary[];
  nutritionLogs: NutritionLogEntry[];
  getKeepsakeImage: (id: string) => string | undefined;
  updateAthlete: (patch: Partial<Athlete>) => void;
  setWorkouts: (workouts: WorkoutBlock[]) => void;
  addWorkout: (workout: Omit<WorkoutBlock, "id" | "completed">) => void;
  toggleWorkout: (id: string) => void;
  removeWorkout: (id: string) => void;
  setAccountabilityItems: (items: AccountabilityItem[]) => void;
  addAccountabilityItem: (label: string) => void;
  toggleAccountabilityItem: (id: string) => void;
  removeAccountabilityItem: (id: string) => void;
  addPersonalRecord: (record: Omit<PersonalRecord, "id">) => void;
  removePersonalRecord: (id: string) => void;
  addWellnessMetric: (metric: Omit<WellnessMetric, "id">) => void;
  removeWellnessMetric: (id: string) => void;
  updateBlueprintScore: (dimension: BlueprintDimension, score: number) => void;
  addMeetPlan: (plan: Omit<MeetPlan, "id">) => void;
  removeMeetPlan: (id: string) => void;
  addInjury: (entry: Omit<InjuryEntry, "id">) => void;
  removeInjury: (id: string) => void;
  addTrainingLog: (entry: Omit<TrainingLogEntry, "id">) => void;
  removeTrainingLog: (id: string) => void;
  addCompetitionResult: (result: Omit<CompetitionResult, "id">) => void;
  removeCompetitionResult: (id: string) => void;
  addAttendance: (entry: Omit<AttendanceEntry, "id">) => void;
  removeAttendance: (id: string) => void;
  addKeepsake: (entry: Omit<KeepsakeEntry, "id">, imageData: string) => void;
  removeKeepsake: (id: string) => void;
  saveSeasonSummary: (
    summary: Omit<SeasonSummary, "id" | "updatedAt"> & { id?: string }
  ) => void;
  removeSeasonSummary: (id: string) => void;
  saveNutritionLog: (
    log: Omit<NutritionLogEntry, "id" | "updatedAt"> & { id?: string }
  ) => void;
  removeNutritionLog: (id: string) => void;
}

const AthleteDataContext = createContext<AthleteDataContextValue | null>(null);

const demoData: GenericAthleteData = {
  ...createEmptyGenericData(),
  athlete: demoAthlete,
  workouts: demoWorkouts,
  accountabilityItems: demoAccountability,
  personalRecords: demoPersonalRecords,
  wellnessMetrics: demoWellness,
  blueprintScores: demoBlueprintScores,
};

function getProgramData(tier: "team" | "coached"): GenericAthleteData {
  if (tier === "team") {
    return { ...demoData, workouts: [] };
  }
  return demoData;
}

function getFallbackData(tier: AppTier): GenericAthleteData {
  if (tier === "generic") return createEmptyGenericData();
  return getProgramData(tier);
}

export function AthleteDataProvider({ children }: { children: React.ReactNode }) {
  const { voice } = useAppTier();
  const tier = voice.tier;
  const isBlankSlate = voice.features.blankSlate;
  const canSelfTrack = true;
  const canManageKeepsakes = canStoreKeepsakes(tier);
  const canManageSeasonSummary = tier === "team";
  const canManageNutrition = voice.features.nutrition;
  const [data, setData] = useState<GenericAthleteData>(() => getFallbackData(tier));
  const [keepsakeImages, setKeepsakeImages] = useState<Record<string, string>>(() =>
    typeof window === "undefined" || !canStoreKeepsakes(tier)
      ? {}
      : loadKeepsakeImages(tier)
  );
  const [ready, setReady] = useState(() => typeof window !== "undefined");

  useEffect(() => {
    const fallback = getFallbackData(tier);
    setData(loadAthleteData(tier, fallback));
    setKeepsakeImages(canStoreKeepsakes(tier) ? loadKeepsakeImages(tier) : {});
    setReady(true);
  }, [tier]);

  const persist = useCallback(
    (next: GenericAthleteData) => {
      setData(next);
      saveAthleteData(tier, next);
    },
    [tier]
  );

  const updateAthlete = useCallback(
    (patch: Partial<Athlete>) => {
      persist({ ...data, athlete: { ...data.athlete, ...patch } });
    },
    [data, persist]
  );

  const setWorkouts = useCallback(
    (workouts: WorkoutBlock[]) => {
      persist({ ...data, workouts });
    },
    [data, persist]
  );

  const addWorkout = useCallback(
    (workout: Omit<WorkoutBlock, "id" | "completed">) => {
      persist({
        ...data,
        workouts: [...data.workouts, { ...workout, id: createId("workout"), completed: false }],
      });
    },
    [data, persist]
  );

  const toggleWorkout = useCallback(
    (id: string) => {
      persist({
        ...data,
        workouts: data.workouts.map((w) =>
          w.id === id ? { ...w, completed: !w.completed } : w
        ),
      });
    },
    [data, persist]
  );

  const removeWorkout = useCallback(
    (id: string) => {
      persist({ ...data, workouts: data.workouts.filter((w) => w.id !== id) });
    },
    [data, persist]
  );

  const setAccountabilityItems = useCallback(
    (items: AccountabilityItem[]) => {
      persist({ ...data, accountabilityItems: items });
    },
    [data, persist]
  );

  const addAccountabilityItem = useCallback(
    (label: string) => {
      persist({
        ...data,
        accountabilityItems: [
          ...data.accountabilityItems,
          {
            id: createId("habit"),
            label,
            completed: false,
            category: "training",
          },
        ],
      });
    },
    [data, persist]
  );

  const toggleAccountabilityItem = useCallback(
    (id: string) => {
      const items = data.accountabilityItems.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      );
      persist({ ...data, accountabilityItems: items });
    },
    [data, persist]
  );

  const removeAccountabilityItem = useCallback(
    (id: string) => {
      persist({
        ...data,
        accountabilityItems: data.accountabilityItems.filter((item) => item.id !== id),
      });
    },
    [data, persist]
  );

  const addPersonalRecord = useCallback(
    (record: Omit<PersonalRecord, "id">) => {
      persist({
        ...data,
        personalRecords: [{ ...record, id: createId("pr") }, ...data.personalRecords],
      });
    },
    [data, persist]
  );

  const removePersonalRecord = useCallback(
    (id: string) => {
      persist({
        ...data,
        personalRecords: data.personalRecords.filter((pr) => pr.id !== id),
      });
    },
    [data, persist]
  );

  const addWellnessMetric = useCallback(
    (metric: Omit<WellnessMetric, "id">) => {
      persist({
        ...data,
        wellnessMetrics: [{ ...metric, id: createId("wellness") }, ...data.wellnessMetrics],
      });
    },
    [data, persist]
  );

  const removeWellnessMetric = useCallback(
    (id: string) => {
      persist({
        ...data,
        wellnessMetrics: data.wellnessMetrics.filter((m) => m.id !== id),
      });
    },
    [data, persist]
  );

  const updateBlueprintScore = useCallback(
    (dimension: BlueprintDimension, score: number) => {
      if (!voice.features.blueprint) return;
      const blueprintScores = data.blueprintScores.map((item) =>
        item.dimension === dimension
          ? {
              ...item,
              score: Math.min(100, Math.max(0, score)),
              trend: "flat" as const,
            }
          : item
      );
      const blueprintOverall = computeBlueprintOverall(blueprintScores);
      persist({
        ...data,
        blueprintScores,
        athlete: { ...data.athlete, blueprintOverall },
      });
    },
    [voice.features.blueprint, data, persist]
  );

  const addMeetPlan = useCallback(
    (plan: Omit<MeetPlan, "id">) => {
      persist({
        ...data,
        meetPlans: [{ ...plan, id: createId("meet") }, ...data.meetPlans],
      });
    },
    [data, persist]
  );

  const removeMeetPlan = useCallback(
    (id: string) => {
      persist({ ...data, meetPlans: data.meetPlans.filter((m) => m.id !== id) });
    },
    [data, persist]
  );

  const addInjury = useCallback(
    (entry: Omit<InjuryEntry, "id">) => {
      persist({
        ...data,
        injuries: [{ ...entry, id: createId("injury") }, ...data.injuries],
      });
    },
    [data, persist]
  );

  const removeInjury = useCallback(
    (id: string) => {
      persist({ ...data, injuries: data.injuries.filter((i) => i.id !== id) });
    },
    [data, persist]
  );

  const addTrainingLog = useCallback(
    (entry: Omit<TrainingLogEntry, "id">) => {
      persist({
        ...data,
        trainingLogs: [{ ...entry, id: createId("log") }, ...data.trainingLogs],
      });
    },
    [data, persist]
  );

  const removeTrainingLog = useCallback(
    (id: string) => {
      persist({ ...data, trainingLogs: data.trainingLogs.filter((l) => l.id !== id) });
    },
    [data, persist]
  );

  const addCompetitionResult = useCallback(
    (result: Omit<CompetitionResult, "id">) => {
      persist({
        ...data,
        competitionResults: [{ ...result, id: createId("comp") }, ...data.competitionResults],
      });
    },
    [data, persist]
  );

  const removeCompetitionResult = useCallback(
    (id: string) => {
      persist({
        ...data,
        competitionResults: data.competitionResults.filter((r) => r.id !== id),
      });
    },
    [data, persist]
  );

  const addAttendance = useCallback(
    (entry: Omit<AttendanceEntry, "id">) => {
      persist({
        ...data,
        attendance: [{ ...entry, id: createId("att") }, ...data.attendance],
      });
    },
    [data, persist]
  );

  const removeAttendance = useCallback(
    (id: string) => {
      persist({ ...data, attendance: data.attendance.filter((a) => a.id !== id) });
    },
    [data, persist]
  );

  const getKeepsakeImage = useCallback(
    (id: string) => keepsakeImages[id],
    [keepsakeImages]
  );

  const addKeepsake = useCallback(
    (entry: Omit<KeepsakeEntry, "id">, imageData: string) => {
      if (!canManageKeepsakes) return;
      const id = createId("keepsake");
      saveKeepsakeImage(tier, id, imageData);
      setKeepsakeImages((prev) => ({ ...prev, [id]: imageData }));
      persist({
        ...data,
        keepsakes: [{ ...entry, id }, ...data.keepsakes],
      });
    },
    [canManageKeepsakes, tier, data, persist]
  );

  const removeKeepsake = useCallback(
    (id: string) => {
      if (!canManageKeepsakes) return;
      removeKeepsakeImage(tier, id);
      setKeepsakeImages((prev) => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
      persist({ ...data, keepsakes: data.keepsakes.filter((k) => k.id !== id) });
    },
    [canManageKeepsakes, tier, data, persist]
  );

  const saveSeasonSummary = useCallback(
    (summary: Omit<SeasonSummary, "id" | "updatedAt"> & { id?: string }) => {
      if (!canManageSeasonSummary) return;
      const updatedAt = new Date().toISOString();
      const existing = summary.id
        ? data.seasonSummaries.find((s) => s.id === summary.id)
        : undefined;

      if (existing) {
        persist({
          ...data,
          seasonSummaries: data.seasonSummaries.map((s) =>
            s.id === existing.id ? { ...existing, ...summary, updatedAt } : s
          ),
        });
        return;
      }

      persist({
        ...data,
        seasonSummaries: [
          {
            ...summary,
            id: createId("season"),
            updatedAt,
          },
          ...data.seasonSummaries,
        ],
      });
    },
    [canManageSeasonSummary, data, persist]
  );

  const removeSeasonSummary = useCallback(
    (id: string) => {
      if (!canManageSeasonSummary) return;
      persist({
        ...data,
        seasonSummaries: data.seasonSummaries.filter((s) => s.id !== id),
      });
    },
    [canManageSeasonSummary, data, persist]
  );

  const saveNutritionLog = useCallback(
    (log: Omit<NutritionLogEntry, "id" | "updatedAt"> & { id?: string }) => {
      if (!canManageNutrition) return;
      const updatedAt = new Date().toISOString();
      const existingById = log.id
        ? data.nutritionLogs.find((entry) => entry.id === log.id)
        : undefined;
      const existingByDate = data.nutritionLogs.find((entry) => entry.date === log.date);
      const existing = existingById ?? existingByDate;

      if (existing) {
        persist({
          ...data,
          nutritionLogs: data.nutritionLogs.map((entry) =>
            entry.id === existing.id ? { ...existing, ...log, updatedAt } : entry
          ),
        });
        return;
      }

      persist({
        ...data,
        nutritionLogs: [
          { ...log, id: createId("nutrition"), updatedAt },
          ...data.nutritionLogs,
        ],
      });
    },
    [canManageNutrition, data, persist]
  );

  const removeNutritionLog = useCallback(
    (id: string) => {
      if (!canManageNutrition) return;
      persist({
        ...data,
        nutritionLogs: data.nutritionLogs.filter((entry) => entry.id !== id),
      });
    },
    [canManageNutrition, data, persist]
  );

  const value = useMemo(
    () => ({
      ready,
      isBlankSlate,
      canSelfTrack,
      canManageKeepsakes,
      canManageSeasonSummary,
      canManageNutrition,
      athlete: data.athlete,
      workouts: data.workouts,
      accountabilityItems: data.accountabilityItems,
      personalRecords: data.personalRecords,
      wellnessMetrics: data.wellnessMetrics,
      blueprintScores: data.blueprintScores,
      meetPlans: data.meetPlans,
      injuries: data.injuries,
      trainingLogs: data.trainingLogs,
      competitionResults: data.competitionResults,
      attendance: data.attendance,
      keepsakes: data.keepsakes,
      seasonSummaries: data.seasonSummaries,
      nutritionLogs: data.nutritionLogs,
      getKeepsakeImage,
      updateAthlete,
      setWorkouts,
      addWorkout,
      toggleWorkout,
      removeWorkout,
      setAccountabilityItems,
      addAccountabilityItem,
      toggleAccountabilityItem,
      removeAccountabilityItem,
      addPersonalRecord,
      removePersonalRecord,
      addWellnessMetric,
      removeWellnessMetric,
      updateBlueprintScore,
      addMeetPlan,
      removeMeetPlan,
      addInjury,
      removeInjury,
      addTrainingLog,
      removeTrainingLog,
      addCompetitionResult,
      removeCompetitionResult,
      addAttendance,
      removeAttendance,
      addKeepsake,
      removeKeepsake,
      saveSeasonSummary,
      removeSeasonSummary,
      saveNutritionLog,
      removeNutritionLog,
    }),
    [
      ready,
      isBlankSlate,
      canSelfTrack,
      canManageKeepsakes,
      canManageSeasonSummary,
      canManageNutrition,
      data,
      updateAthlete,
      setWorkouts,
      addWorkout,
      toggleWorkout,
      removeWorkout,
      setAccountabilityItems,
      addAccountabilityItem,
      toggleAccountabilityItem,
      removeAccountabilityItem,
      addPersonalRecord,
      removePersonalRecord,
      addWellnessMetric,
      removeWellnessMetric,
      updateBlueprintScore,
      addMeetPlan,
      removeMeetPlan,
      addInjury,
      removeInjury,
      addTrainingLog,
      removeTrainingLog,
      addCompetitionResult,
      removeCompetitionResult,
      addAttendance,
      removeAttendance,
      addKeepsake,
      removeKeepsake,
      saveSeasonSummary,
      removeSeasonSummary,
      saveNutritionLog,
      removeNutritionLog,
      getKeepsakeImage,
    ]
  );

  return (
    <AthleteDataContext.Provider value={value}>{children}</AthleteDataContext.Provider>
  );
}

export function useAthleteData() {
  const ctx = useContext(AthleteDataContext);
  if (!ctx) {
    throw new Error("useAthleteData must be used within AthleteDataProvider");
  }
  return ctx;
}

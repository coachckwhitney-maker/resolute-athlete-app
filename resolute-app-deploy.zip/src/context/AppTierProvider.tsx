"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import type { AppTier } from "@/lib/types/appTier";
import {
  APP_TIER_STORAGE_KEY,
  normalizeStoredTier,
} from "@/lib/types/appTier";
import { safeGetItem, safeRemoveItem, safeSetItem } from "@/lib/storage/safeStorage";
import {
  COACHED_PREVIEW_CODE,
  SUBSCRIPTIONS_ENABLED,
  TEAM_ACCESS_CODE,
} from "@/lib/config/tier";
import { resolveCoachVoice, type CoachVoice } from "@/lib/coach/voice";

interface AppTierContextValue {
  tier: AppTier | null;
  ready: boolean;
  voice: CoachVoice;
  setTier: (tier: AppTier) => void;
  unlockTeamWithCode: (code: string) => boolean;
  /** @deprecated use unlockTeamWithCode */
  upgradeWithCode: (code: string) => boolean;
  unlockCoachedWithCode: (code: string) => boolean;
  unlockCoachedViaSubscription: () => boolean;
  downgradeToGeneric: () => void;
  resetTierChoice: () => void;
}

const AppTierContext = createContext<AppTierContextValue | null>(null);

export function AppTierProvider({ children }: { children: React.ReactNode }) {
  const [tier, setTierState] = useState<AppTier | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("reset") === "1") {
      safeRemoveItem(APP_TIER_STORAGE_KEY);
      setTierState(null);
      params.delete("reset");
      const next = params.toString();
      const url = next ? `${window.location.pathname}?${next}` : window.location.pathname;
      window.history.replaceState(null, "", url);
      setReady(true);
      return;
    }

    const tierParam = params.get("tier");
    if (tierParam === "generic" || tierParam === "team" || tierParam === "coached") {
      safeSetItem(APP_TIER_STORAGE_KEY, tierParam);
      setTierState(tierParam);
      params.delete("tier");
      const next = params.toString();
      const url = next ? `${window.location.pathname}?${next}` : window.location.pathname;
      window.history.replaceState(null, "", url);
      setReady(true);
      return;
    }

    const stored = safeGetItem(APP_TIER_STORAGE_KEY);
    const normalized = normalizeStoredTier(stored);
    if (normalized) {
      setTierState(normalized);
      if (stored === "client") {
        safeSetItem(APP_TIER_STORAGE_KEY, normalized);
      }
    }
    setReady(true);
  }, []);

  const setTier = useCallback((next: AppTier) => {
    safeSetItem(APP_TIER_STORAGE_KEY, next);
    setTierState(next);
  }, []);

  const unlockTeamWithCode = useCallback(
    (code: string) => {
      if (code.trim().toUpperCase() !== TEAM_ACCESS_CODE) {
        return false;
      }
      setTier("team");
      return true;
    },
    [setTier]
  );

  const unlockCoachedWithCode = useCallback(
    (code: string) => {
      if (code.trim().toUpperCase() !== COACHED_PREVIEW_CODE) {
        return false;
      }
      setTier("coached");
      return true;
    },
    [setTier]
  );

  const unlockCoachedViaSubscription = useCallback(() => {
    if (!SUBSCRIPTIONS_ENABLED) {
      return false;
    }
    setTier("coached");
    return true;
  }, [setTier]);

  const downgradeToGeneric = useCallback(() => {
    setTier("generic");
  }, [setTier]);

  const resetTierChoice = useCallback(() => {
    safeRemoveItem(APP_TIER_STORAGE_KEY);
    setTierState(null);
  }, []);

  const activeTier: AppTier = tier ?? "generic";
  const voice = useMemo(() => resolveCoachVoice(activeTier), [activeTier]);

  const value = useMemo(
    () => ({
      tier,
      ready,
      voice,
      setTier,
      unlockTeamWithCode,
      upgradeWithCode: unlockTeamWithCode,
      unlockCoachedWithCode,
      unlockCoachedViaSubscription,
      downgradeToGeneric,
      resetTierChoice,
    }),
    [
      tier,
      ready,
      voice,
      setTier,
      unlockTeamWithCode,
      unlockCoachedWithCode,
      unlockCoachedViaSubscription,
      downgradeToGeneric,
      resetTierChoice,
    ]
  );

  return (
    <AppTierContext.Provider value={value}>{children}</AppTierContext.Provider>
  );
}

export function useAppTier() {
  const ctx = useContext(AppTierContext);
  if (!ctx) {
    throw new Error("useAppTier must be used within AppTierProvider");
  }
  return ctx;
}

export function useCoachVoice() {
  return useAppTier().voice;
}

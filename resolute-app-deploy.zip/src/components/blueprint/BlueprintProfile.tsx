"use client";

import { cn, getScoreColor, getTrendIcon } from "@/lib/utils";
import { AnimatedBar } from "@/components/ui/AnimatedBar";
import { ProgressRing } from "@/components/ui/ProgressRing";
import { blueprintDimensionInfo } from "@/lib/data/blueprint";
import type { BlueprintDimension, BlueprintScore } from "@/lib/types/athlete";

interface BlueprintProfileProps {
  scores: BlueprintScore[];
  overall: number;
  editable?: boolean;
  onScoreChange?: (dimension: BlueprintDimension, score: number) => void;
}

export function BlueprintProfile({
  scores,
  overall,
  editable = false,
  onScoreChange,
}: BlueprintProfileProps) {
  return (
    <section>
      <div className="animate-fade-up bento mb-6 overflow-hidden p-8 text-center red-glow">
        <ProgressRing value={overall} size={168} strokeWidth={8} className="mx-auto" />
        <p className="headline mt-6 text-3xl text-white">Whole Athlete Score</p>
        <p className="mt-2 font-accent text-xs text-white/40">
          {overall}/100 — {editable ? "rate yourself across all dimensions" : "whole athlete score"}
        </p>
      </div>

      <p className="label-caps mb-4">Your 10 Dimensions</p>

      <div className="space-y-3">
        {scores.map((item, i) => {
          const info = blueprintDimensionInfo[item.dimension];
          return (
            <div
              key={item.dimension}
              className={cn(
                "animate-fade-up animate-stagger glass rounded-xl p-4 transition-all duration-500 hover:bg-white/[0.04]",
                `stagger-${Math.min(i + 1, 8)}`
              )}
            >
              <div className="mb-2 flex items-center justify-between">
                <span className="font-accent text-xs font-bold uppercase tracking-widest text-white/70">
                  {item.label}
                </span>
                <div className="flex items-center gap-3">
                  {!editable && (
                    <span
                      className={cn(
                        "text-sm font-bold",
                        item.trend === "up"
                          ? "text-resolute-red"
                          : item.trend === "down"
                            ? "text-resolute-danger"
                            : "text-white/25"
                      )}
                    >
                      {getTrendIcon(item.trend)}
                    </span>
                  )}
                  <span className={cn("stat-number text-4xl", getScoreColor(item.score))}>
                    {item.score}
                  </span>
                </div>
              </div>

              <p className="text-xs text-white/45">{info.description}</p>
              {!editable && (
                <p className="mt-2 text-xs leading-relaxed text-white/30 italic">
                  {info.why}
                </p>
              )}

              {editable ? (
                <input
                  type="range"
                  min={0}
                  max={100}
                  step={1}
                  value={item.score}
                  onChange={(e) =>
                    onScoreChange?.(item.dimension, Number(e.target.value))
                  }
                  className="mt-4 w-full accent-resolute-red"
                />
              ) : (
                <AnimatedBar value={item.score} delay={i * 80} className="mt-3 h-1 rounded-full" />
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}

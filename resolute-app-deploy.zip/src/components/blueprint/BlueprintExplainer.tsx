"use client";

import { BlueprintShift } from "@/components/blueprint/BlueprintShift";
import { blueprintPillars } from "@/lib/data/blueprint";
import { useCoachVoice } from "@/context/AppTierProvider";

export function BlueprintExplainer() {
  const voice = useCoachVoice();
  const philosophy = voice.blueprintPhilosophy;

  return (
    <section className="mb-8 space-y-4">
      <BlueprintShift />

      <div className="glass rounded-xl p-5">
        <p className="label-caps">All 10 Dimensions</p>
        <p className="headline mt-3 text-2xl leading-tight text-white">
          {philosophy.headline}
        </p>
        <p className="headline text-xl text-gradient-red">{philosophy.tagline}</p>
        <p className="mt-3 text-sm leading-relaxed text-white/50">{philosophy.subhead}</p>
        <p className="label-caps mt-4 mb-3">4 Pillars · 10 Dimensions</p>
        <div className="grid grid-cols-2 gap-3">
          {blueprintPillars.map((pillar) => (
            <div key={pillar.label} className="glass rounded-xl p-4">
              <p className="font-accent text-xs font-bold uppercase tracking-wider text-resolute-red">
                {pillar.label}
              </p>
              <p className="mt-2 text-xs leading-relaxed text-white/50">
                {pillar.dims.join(" · ")}
              </p>
              {"note" in pillar && (
                <p className="mt-2 text-[10px] leading-relaxed text-white/30 italic">
                  {pillar.note}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      <blockquote className="border-l-2 border-resolute-red py-1 pl-4">
        <p className="label-caps text-resolute-red">{voice.coachName}</p>
        <p className="mt-2 text-sm leading-relaxed text-white/70 italic">
          &ldquo;{philosophy.coachQuote}&rdquo;
        </p>
      </blockquote>
    </section>
  );
}

export { BlueprintShowcase } from "@/components/blueprint/BlueprintShift";

"use client";

import { AppShell } from "@/components/layout/AppShell";
import { BlueprintExplainer } from "@/components/blueprint/BlueprintExplainer";
import { BlueprintProfile } from "@/components/blueprint/BlueprintProfile";
import { FeaturePaywall } from "@/components/upgrade/FeaturePaywall";
import { useCoachVoice } from "@/context/AppTierProvider";
import { useAthleteData } from "@/context/AthleteDataProvider";

export function BlueprintPageClient() {
  const voice = useCoachVoice();
  const { athlete, blueprintScores, updateBlueprintScore, isBlankSlate } = useAthleteData();

  if (!voice.features.blueprint) {
    return (
      <FeaturePaywall
        feature="Athlete Blueprint"
        description="Rate yourself across 10 dimensions of the whole athlete — nutrition, recovery, mindset, speed, and more. Blueprint development is included with Resolute and coached athletes."
      />
    );
  }

  return (
    <AppShell>
      <BlueprintExplainer />

      <header className="mb-6 mt-2">
        <p className="label-caps text-resolute-red">
          {isBlankSlate ? "Your Self-Rating" : "Your Scores"}
        </p>
        <h1 className="headline text-[clamp(2.5rem,10vw,3.5rem)] leading-none">
          <span className="text-white">Athlete</span>{" "}
          <span className="text-gradient-red">Blueprint</span>
        </h1>
        {isBlankSlate && (
          <p className="mt-2 text-sm text-white/40">
            Rate yourself 0–100 on each dimension. Your overall score updates automatically.
          </p>
        )}
      </header>

      <BlueprintProfile
        scores={blueprintScores}
        overall={athlete.blueprintOverall}
        editable={isBlankSlate || voice.isCoached}
        onScoreChange={updateBlueprintScore}
      />
    </AppShell>
  );
}

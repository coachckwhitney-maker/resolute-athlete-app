"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { blueprintPillars } from "@/lib/data/blueprint";
import { useCoachVoice } from "@/context/AppTierProvider";

interface BlueprintShiftProps {
  compact?: boolean;
}

export function BlueprintShift({ compact = false }: BlueprintShiftProps) {
  const voice = useCoachVoice();
  const philosophy = voice.blueprintPhilosophy;

  return (
    <div className={compact ? "glass-red rounded-xl p-4" : "glass-red rounded-xl p-5 red-glow"}>
      <p className="label-caps text-resolute-red">The Athlete Blueprint</p>

      <p className={`headline mt-2 text-white ${compact ? "text-2xl" : "text-3xl"}`}>
        {philosophy.headline}
      </p>
      <p className={`headline text-gradient-red ${compact ? "text-lg" : "text-2xl"}`}>
        {philosophy.tagline}
      </p>

      {!compact && (
        <p className="mt-3 text-sm leading-relaxed text-white/55">{philosophy.subhead}</p>
      )}

      <div className={`grid grid-cols-2 gap-3 ${compact ? "mt-4" : "mt-5"}`}>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-white/30">
            {philosophy.beforeSub}
          </p>
          <p
            className={`headline mt-1 text-white/40 line-through ${compact ? "text-base" : "text-lg"}`}
          >
            {philosophy.before}
          </p>
        </div>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-resolute-red">
            {philosophy.afterSub}
          </p>
          <p
            className={`headline mt-1 text-gradient-red ${compact ? "text-base" : "text-lg"}`}
          >
            {philosophy.after}
          </p>
        </div>
      </div>
    </div>
  );
}

export function BlueprintShowcase() {
  const voice = useCoachVoice();
  const philosophy = voice.blueprintPhilosophy;

  return (
    <section className="space-y-4">
      <BlueprintShift />

      <div className="glass rounded-xl p-5">
        <p className="label-caps">All 10 Dimensions</p>
        <p className="mt-3 text-sm leading-relaxed text-white/60">{philosophy.subhead}</p>
        <p className="label-caps mt-4 mb-3">4 Pillars · 10 Dimensions</p>
        <div className="grid grid-cols-2 gap-2">
          {blueprintPillars.map((pillar) => (
            <div key={pillar.label} className="rounded-lg bg-white/[0.03] p-3">
              <p className="font-accent text-[10px] font-bold uppercase tracking-wider text-resolute-red">
                {pillar.label}
              </p>
              <p className="mt-1 text-[11px] leading-relaxed text-white/50">
                {pillar.dims.join(" · ")}
              </p>
              {"note" in pillar && (
                <p className="mt-1.5 text-[10px] leading-relaxed text-white/30 italic">
                  {pillar.note}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      <blockquote className="border-l-2 border-resolute-red py-1 pl-4">
        <p className="label-caps text-resolute-red">{voice.coachName}</p>
        <p className="mt-2 text-sm leading-relaxed text-white/65 italic">
          &ldquo;{philosophy.coachQuote}&rdquo;
        </p>
      </blockquote>

      <Link href="/blueprint" className="btn-ghost flex w-full items-center justify-center gap-2">
        See Your Blueprint
        <ArrowRight className="h-4 w-4" />
      </Link>
    </section>
  );
}

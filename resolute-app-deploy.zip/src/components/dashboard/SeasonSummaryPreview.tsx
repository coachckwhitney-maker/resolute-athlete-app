"use client";

import Link from "next/link";
import { BookOpen } from "lucide-react";
import { useAthleteData } from "@/context/AthleteDataProvider";

export function SeasonSummaryPreview() {
  const { seasonSummaries, canManageSeasonSummary } = useAthleteData();

  if (!canManageSeasonSummary) return null;

  const latest = seasonSummaries[0];

  return (
    <section className="mb-8">
      <Link
        href="/season-summary"
        className="glass group block rounded-xl p-5 transition-colors hover:bg-white/[0.04]"
      >
        <div className="flex items-start gap-4">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-resolute-red/15">
            <BookOpen className="h-5 w-5 text-resolute-red" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="label-caps text-resolute-red">Season Summary</p>
            <p className="headline mt-1 text-xl text-white group-hover:text-white">
              End-of-season reflection
            </p>
            {latest ? (
              <p className="mt-2 line-clamp-2 text-sm text-white/45">
                {latest.season}: {latest.biggestImprovement || latest.nextSeasonGoals || "Tap to view your reflection"}
              </p>
            ) : (
              <p className="mt-2 text-sm text-white/45">
                Biggest improvement, favorite performance, toughest challenge, lessons & next-season goals.
              </p>
            )}
            <p className="mt-3 text-xs uppercase tracking-wider text-white/30 group-hover:text-resolute-red/80">
              {latest ? "View or update →" : "Start reflection →"}
            </p>
          </div>
        </div>
      </Link>
    </section>
  );
}

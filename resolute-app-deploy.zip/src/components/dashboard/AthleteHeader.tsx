"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { cn, getReadinessColor, getReadinessDot } from "@/lib/utils";
import { ProgressRing } from "@/components/ui/ProgressRing";
import { useCoachVoice } from "@/context/AppTierProvider";
import { useAthleteData } from "@/context/AthleteDataProvider";
import type { Athlete } from "@/lib/types/athlete";
import { Flame, TrendingUp } from "lucide-react";

interface AthleteHeaderProps {
  athlete: Athlete;
  workoutProgress: number;
  progressLabel?: string;
}

export function AthleteHeader({ athlete, workoutProgress, progressLabel = "Done" }: AthleteHeaderProps) {
  const voice = useCoachVoice();
  const { isBlankSlate, updateAthlete } = useAthleteData();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(athlete.name);
  const [sport, setSport] = useState(athlete.sport);

  const displayName = athlete.name.trim() || (isBlankSlate ? "Your Profile" : athlete.name);
  const displayInitial = displayName[0]?.toUpperCase() ?? "?";
  const showMeta = athlete.sport.trim() || (!isBlankSlate && athlete.grade > 0);

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    updateAthlete({ name: name.trim(), sport: sport.trim() });
    setEditing(false);
  }

  return (
    <motion.header
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className="mb-8"
    >
      <motion.div
        whileHover={{ scale: 1.005 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="relative overflow-hidden bento p-6"
      >
        <motion.div
          animate={{ x: [0, 10, 0], y: [0, -5, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="pointer-events-none absolute -right-4 -top-4 font-display text-[9rem] leading-none text-white/[0.04]"
        >
          {displayInitial}
        </motion.div>

        <div className="relative flex items-start justify-between gap-4">
          <div className="min-w-0 flex-1">
            {isBlankSlate ? (
              <p className="label-caps text-resolute-red">Athlete Tracker</p>
            ) : (
              <p className="label-caps text-resolute-red">{athlete.team}</p>
            )}
            {editing ? (
              <form onSubmit={handleSave} className="mt-3 space-y-3">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-white/30 focus:border-resolute-red focus:outline-none"
                />
                <input
                  value={sport}
                  onChange={(e) => setSport(e.target.value)}
                  placeholder="Your sport"
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-white/30 focus:border-resolute-red focus:outline-none"
                />
                <div className="flex gap-2">
                  <button type="submit" className="btn-red flex-1">
                    Save
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditing(false)}
                    className="btn-ghost flex-1"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => isBlankSlate && setEditing(true)}
                  className={cn("text-left", isBlankSlate && "cursor-pointer")}
                >
                  <h1 className="headline mt-2 text-[clamp(2.5rem,10vw,3.5rem)] text-white">
                    {displayName}
                  </h1>
                </button>
                {showMeta ? (
                  <p className="mt-2 font-accent text-xs text-white/40">
                    {!isBlankSlate && athlete.grade > 0 && `Grade ${athlete.grade} · `}
                    {athlete.sport}
                  </p>
                ) : isBlankSlate ? (
                  <button
                    type="button"
                    onClick={() => setEditing(true)}
                    className="mt-2 text-xs font-bold uppercase tracking-wider text-resolute-red"
                  >
                    Set up your profile →
                  </button>
                ) : null}
              </>
            )}
          </div>
          <ProgressRing value={workoutProgress} size={92} strokeWidth={5} label={progressLabel} />
        </div>
      </motion.div>

      <div className={cn("mt-3 grid gap-3", voice.features.blueprint ? "grid-cols-2" : "grid-cols-1")}>
        <motion.div
          whileHover={{ scale: 1.03, y: -2 }}
          className="glass-red bento flex items-center gap-3 p-4"
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-resolute-red/20">
            <Flame className="h-5 w-5 text-resolute-red animate-pulse-red" />
          </div>
          <div>
            <motion.p
              key={athlete.streak}
              initial={{ scale: 1.3, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="stat-number text-4xl text-resolute-red"
            >
              {athlete.streak}
            </motion.p>
            <p className="label-caps">Day Streak</p>
          </div>
        </motion.div>

        {voice.features.blueprint && (
        <motion.div whileHover={{ scale: 1.03, y: -2 }} className="bento flex items-center gap-3 p-4">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/5">
            <TrendingUp className="h-5 w-5 text-white/60" />
          </div>
          <div>
            <p className="stat-number text-4xl text-gradient-red">{athlete.blueprintOverall}</p>
            <p className="label-caps">Blueprint</p>
          </div>
        </motion.div>
        )}
      </div>

      {!isBlankSlate && athlete.readinessNote && (
        <motion.div
          initial={{ opacity: 0, x: -16 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className={cn(
            "mt-3 flex items-center gap-3 border p-4 backdrop-blur-sm",
            getReadinessColor(athlete.readiness)
          )}
        >
          <span className={cn("h-2.5 w-2.5 shrink-0 rounded-full", getReadinessDot(athlete.readiness))} />
          <div>
            <p className="font-accent text-xs font-bold uppercase tracking-wider capitalize">
              Readiness · {athlete.readiness}
            </p>
            <p className="mt-0.5 text-xs opacity-70">{athlete.readinessNote}</p>
          </div>
        </motion.div>
      )}
    </motion.header>
  );
}

"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, ChevronDown, Clock, Sparkles } from "lucide-react";
import { categoryLabels } from "@/lib/data/mockAthlete";
import { cn } from "@/lib/utils";
import type { WorkoutBlock } from "@/lib/types/athlete";

interface WorkoutCardProps {
  block: WorkoutBlock;
  index: number;
  onToggle: (id: string) => void;
}

const categoryStyle: Record<string, { border: string; glow: string; tag: string }> = {
  warmup: { border: "border-l-orange-400", glow: "hover:shadow-[0_0_30px_rgba(251,146,60,0.15)]", tag: "text-orange-400" },
  sprint: { border: "border-l-resolute-red", glow: "hover:shadow-glow-sm", tag: "text-resolute-red" },
  lift: { border: "border-l-white/60", glow: "hover:shadow-[0_0_30px_rgba(255,255,255,0.08)]", tag: "text-white/60" },
  plyo: { border: "border-l-purple-400", glow: "hover:shadow-[0_0_30px_rgba(192,132,252,0.15)]", tag: "text-purple-400" },
  mobility: { border: "border-l-cyan-400", glow: "hover:shadow-[0_0_30px_rgba(34,211,238,0.15)]", tag: "text-cyan-400" },
  recovery: { border: "border-l-emerald-400", glow: "hover:shadow-[0_0_30px_rgba(52,211,153,0.15)]", tag: "text-emerald-400" },
};

export function WorkoutCard({ block, index, onToggle }: WorkoutCardProps) {
  const [expanded, setExpanded] = useState(false);
  const style = categoryStyle[block.category];

  return (
    <motion.article
      layout
      initial={false}
      animate={{ opacity: block.completed ? 0.45 : 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
      whileTap={{ scale: 0.985 }}
      className={cn(
        "glass border-l-[3px] transition-shadow duration-500",
        style.border,
        style.glow
      )}
    >
      <div className="flex items-start gap-4 p-5">
        <motion.button
          type="button"
          onClick={() => onToggle(block.id)}
          whileTap={{ scale: 0.85 }}
          className={cn(
            "mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border-2 transition-all duration-300",
            block.completed
              ? "border-resolute-red bg-resolute-red shadow-glow-sm"
              : "border-white/20 hover:border-resolute-red hover:bg-resolute-red/10"
          )}
          aria-label={block.completed ? "Mark incomplete" : "Mark complete"}
        >
          <AnimatePresence mode="wait">
            {block.completed && (
              <motion.div
                initial={{ scale: 0, rotate: -90 }}
                animate={{ scale: 1, rotate: 0 }}
                exit={{ scale: 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 20 }}
              >
                <Check className="h-4 w-4 text-white" strokeWidth={3} />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>

        <div className="min-w-0 flex-1">
          <button
            type="button"
            className="w-full text-left"
            onClick={() => setExpanded(!expanded)}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className={cn("label-caps", style.tag)}>
                  {categoryLabels[block.category]}
                </span>
                <h3
                  className={cn(
                    "headline mt-1 text-2xl transition-all",
                    block.completed && "line-through opacity-50"
                  )}
                >
                  {block.title}
                </h3>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1 text-white/35">
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  <span className="font-accent text-[10px] font-semibold">{block.duration}</span>
                </div>
                <motion.div animate={{ rotate: expanded ? 180 : 0 }} transition={{ duration: 0.3 }}>
                  <ChevronDown className={cn("h-4 w-4", expanded && "text-resolute-red")} />
                </motion.div>
              </div>
            </div>
          </button>

          <AnimatePresence>
            {expanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="overflow-hidden"
              >
                <p className="mt-4 text-sm leading-relaxed text-white/55">{block.description}</p>
                <div className="glass-red mt-4 rounded-xl p-4">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-3.5 w-3.5 text-resolute-red" />
                    <p className="label-caps text-resolute-red">Why This Matters</p>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-white/75">{block.why}</p>
                  {block.coachLine && (
                    <p className="mt-3 border-t border-white/10 pt-3 font-display text-base uppercase tracking-wide text-resolute-red">
                      &ldquo;{block.coachLine}&rdquo;
                    </p>
                  )}
                </div>
                {!block.completed && (
                  <motion.button
                    type="button"
                    onClick={() => onToggle(block.id)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    className="btn-red mt-4 w-full py-3 text-xs"
                  >
                    Complete Block
                  </motion.button>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.article>
  );
}

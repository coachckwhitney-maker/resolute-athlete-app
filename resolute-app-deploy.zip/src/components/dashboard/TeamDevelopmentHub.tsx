"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Apple,
  BookOpen,
  Brain,
  CheckSquare,
  Heart,
  Hexagon,
  Moon,
  TrendingUp,
} from "lucide-react";
import { UpgradeCTA } from "@/components/upgrade/UpgradeComparison";

const developmentLinks = [
  {
    href: "/culture",
    icon: Heart,
    label: "Team Culture",
    desc: "Standards, points & how we show up for each other",
  },
  {
    href: "/mindset",
    icon: Brain,
    label: "Mindset",
    desc: "Coach Whitney's philosophy & mental training",
  },
  {
    href: "/accountability",
    icon: CheckSquare,
    label: "Daily Habits",
    desc: "Check-ins, streaks & holding yourself accountable",
  },
  {
    href: "/nutrition",
    icon: Apple,
    label: "Nutrition",
    desc: "Daily water, protein, fruits, vegetables & pre/post-workout meals",
  },
  {
    href: "/progress",
    icon: TrendingUp,
    label: "Recovery & Wellness",
    desc: "Sleep, soreness, energy — track how your body adapts",
  },
  {
    href: "/blueprint",
    icon: Hexagon,
    label: "Athlete Blueprint",
    desc: "10 dimensions of the whole athlete",
  },
  {
    href: "/season-summary",
    icon: BookOpen,
    label: "Season Summary",
    desc: "End-of-season reflection — improvement, performances, lessons & next-year goals",
  },
];

export function TeamDevelopmentHub() {
  return (
    <section className="mb-8">
      <div className="mb-5">
        <p className="label-caps text-resolute-red">Beyond Practice</p>
        <h2 className="headline text-3xl text-white">Develop the Whole Athlete</h2>
        <p className="mt-2 text-sm text-white/45">
          You train with us on the track. Use this portal for culture, mindset, recovery,
          and everything else that makes a complete athlete.
        </p>
      </div>

      <div className="space-y-3">
        {developmentLinks.map(({ href, icon: Icon, label, desc }, i) => (
          <motion.div
            key={href}
            initial={false}
            whileHover={{ scale: 1.01, x: 4 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
          >
            <Link
              href={href}
              className="card-interactive flex items-start gap-4 p-5"
            >
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-resolute-red/15">
                <Icon className="h-5 w-5 text-resolute-red" />
              </div>
              <div>
                <p className="headline text-xl text-white">{label}</p>
                <p className="mt-1 text-sm text-white/45">{desc}</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>

      <div className="glass-red mt-6 flex items-start gap-3 rounded-xl p-5">
        <Moon className="mt-0.5 h-5 w-5 shrink-0 text-resolute-red" />
        <div>
          <p className="text-sm font-semibold text-white">No workouts here on purpose</p>
          <p className="mt-1 text-xs leading-relaxed text-white/45">
            Your training plan lives at practice. This app is for developing who you are
            between sessions — recovery, mindset, culture, and accountability.
          </p>
        </div>
      </div>

      <UpgradeCTA
        className="mt-6"
        title="Want remote coaching?"
        description="Coached Athlete adds daily workouts through the app — for athletes not training with us locally."
      />
    </section>
  );
}

"use client";

import Link from "next/link";
import {
  Activity,
  Calendar,
  HeartPulse,
  ImageIcon,
  Medal,
  TrendingUp,
  Users,
} from "lucide-react";
import { useAthleteData } from "@/context/AthleteDataProvider";

export function ProgressPreview() {
  const {
    meetPlans,
    injuries,
    personalRecords,
    trainingLogs,
    competitionResults,
    wellnessMetrics,
    attendance,
    keepsakes,
    canManageKeepsakes,
  } = useAthleteData();

  const cards = [
    {
      href: "/progress",
      icon: TrendingUp,
      label: "PR Progression",
      count: personalRecords.length,
      hint: "personal records",
    },
    {
      href: "/progress",
      icon: Activity,
      label: "Training Volume",
      count: trainingLogs.length,
      hint: "volume logs",
    },
    {
      href: "/progress",
      icon: HeartPulse,
      label: "Wellness & Sleep",
      count: wellnessMetrics.length,
      hint: "wellness entries",
    },
    {
      href: "/progress",
      icon: Calendar,
      label: "Meet Planner",
      count: meetPlans.length,
      hint: "upcoming meets",
    },
    {
      href: "/progress",
      icon: HeartPulse,
      label: "Injury Tracker",
      count: injuries.length,
      hint: "injury logs",
    },
    {
      href: "/progress",
      icon: Medal,
      label: "Competition Results",
      count: competitionResults.length,
      hint: "meet results",
    },
    {
      href: "/progress",
      icon: Users,
      label: "Attendance",
      count: attendance.length,
      hint: "days logged",
    },
    ...(canManageKeepsakes
      ? [
          {
            href: "/progress?tab=keepsakes",
            icon: ImageIcon,
            label: "Meet Keepsakes",
            count: keepsakes.length,
            hint: "bibs, stickers & photos",
          },
        ]
      : []),
  ];

  return (
    <section className="mb-8">
      <div className="mb-4 flex items-end justify-between">
        <div>
          <p className="label-caps text-resolute-red">Progress Dashboard</p>
          <h2 className="headline text-3xl">Track & Visualize</h2>
        </div>
        <Link href="/progress" className="text-xs uppercase tracking-wider text-white/40 hover:text-white">
          Open →
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {cards.map((card) => (
          <Link
            key={card.label}
            href={card.href}
            className="glass group rounded-xl p-4 transition-colors hover:bg-white/[0.04]"
          >
            <card.icon className="mb-2 h-4 w-4 text-resolute-red" />
            <p className="text-xs font-medium uppercase tracking-wider text-white/50 group-hover:text-white/70">
              {card.label}
            </p>
            <p className="mt-1 font-display text-3xl text-white">{card.count}</p>
            <p className="text-[10px] text-white/30">{card.hint}</p>
          </Link>
        ))}
      </div>
    </section>
  );
}

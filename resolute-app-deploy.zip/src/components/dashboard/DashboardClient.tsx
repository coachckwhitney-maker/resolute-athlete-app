"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AppShell } from "@/components/layout/AppShell";
import { AthleteHeader } from "@/components/dashboard/AthleteHeader";
import { BlueprintPreview } from "@/components/dashboard/BlueprintPreview";
import { CoachMessageCard } from "@/components/dashboard/CoachMessageCard";
import { WorkoutCard } from "@/components/dashboard/WorkoutCard";
import { CulturePreview } from "@/components/culture/CulturePreview";
import { TeamDevelopmentHub } from "@/components/dashboard/TeamDevelopmentHub";
import { ProgressPreview } from "@/components/dashboard/ProgressPreview";
import { KeepsakesPreview } from "@/components/dashboard/KeepsakesPreview";
import { SeasonSummaryPreview } from "@/components/dashboard/SeasonSummaryPreview";
import { NutritionPreview } from "@/components/dashboard/NutritionPreview";
import { UpgradeCTA } from "@/components/upgrade/UpgradeComparison";
import { EmptyState } from "@/components/ui/EmptyState";
import { Marquee } from "@/components/ui/Marquee";
import { SessionProgressBar } from "@/components/ui/SessionProgressBar";
import { FadeUp } from "@/components/ui/Motion";
import { useCoachVoice } from "@/context/AppTierProvider";
import { useAthleteData } from "@/context/AthleteDataProvider";
import type { WorkoutBlock } from "@/lib/types/athlete";

function withWorkoutCoachLines(
  blocks: WorkoutBlock[],
  lines: Record<string, string>
): WorkoutBlock[] {
  return blocks.map((block) => ({
    ...block,
    coachLine: lines[block.category] ?? block.coachLine,
  }));
}

export function DashboardClient() {
  const voice = useCoachVoice();
  const {
    ready,
    isBlankSlate,
    athlete,
    workouts: storedWorkouts,
    blueprintScores,
    toggleWorkout,
    addWorkout,
  } = useAthleteData();

  const coachMessage = useMemo(() => voice.getDailyCoachMessage(), [voice]);
  const workouts = useMemo(
    () => withWorkoutCoachLines(storedWorkouts, voice.workoutCoachLines),
    [storedWorkouts, voice.workoutCoachLines]
  );

  const [showAddWorkout, setShowAddWorkout] = useState(false);
  const [workoutTitle, setWorkoutTitle] = useState("");

  const completedCount = workouts.filter((b) => b.completed).length;
  const workoutProgress =
    workouts.length > 0 ? Math.round((completedCount / workouts.length) * 100) : 0;
  const allDone = workouts.length > 0 && completedCount === workouts.length;
  const isTeamPortal = voice.isTeamAthlete;

  function handleAddWorkout(e: React.FormEvent) {
    e.preventDefault();
    if (!workoutTitle.trim()) return;
    addWorkout({
      title: workoutTitle.trim(),
      category: "lift",
      duration: "",
      description: "",
      why: "",
    });
    setWorkoutTitle("");
    setShowAddWorkout(false);
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="label-caps text-white/30">Loading your tracker...</p>
      </div>
    );
  }

  return (
    <>
      {voice.hasWorkouts && <SessionProgressBar progress={workoutProgress} />}
      <AppShell>
        <AthleteHeader
          athlete={athlete}
          workoutProgress={isTeamPortal ? athlete.blueprintOverall : workoutProgress}
          progressLabel={isTeamPortal ? "Score" : "Done"}
        />

        {voice.features.whitneyVoice && <CoachMessageCard message={coachMessage} />}

        {isBlankSlate && (
          <div className="mb-6 rounded-xl border border-white/10 bg-white/[0.02] p-5">
            <p className="label-caps text-resolute-red">Your Tracker</p>
            <p className="headline mt-2 text-2xl text-white">Start logging your training</p>
            <p className="mt-2 text-sm text-white/45">
              Add workouts, meets, injuries, PRs, volume logs, and wellness — everything you enter is yours.
            </p>
          </div>
        )}

        {voice.features.showUpgradeToCoached && (
          <UpgradeCTA className="mb-6" />
        )}

        {voice.features.blueprint && (
          <BlueprintPreview overall={athlete.blueprintOverall} scores={blueprintScores} />
        )}

        <ProgressPreview />

        <KeepsakesPreview />

        {voice.features.culture && <CulturePreview />}

        {isTeamPortal && <SeasonSummaryPreview />}

        {voice.features.nutrition && <NutritionPreview />}

        {isTeamPortal && <TeamDevelopmentHub />}

        {voice.hasWorkouts && (
          <>
            <AnimatePresence>
              {allDone && (
                <motion.div
                  initial={false}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="mb-6 bento p-5 text-center red-glow"
                >
                  <p className="headline mt-3 text-3xl text-gradient-red">Session Complete</p>
                  <p className="mt-1 font-accent text-xs text-white/50">
                    &ldquo;{voice.sessionCompleteLine}&rdquo;
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            <Marquee />

            <FadeUp delay={0.2} className="mt-8">
              <section>
                <div className="mb-5 flex items-end justify-between">
                  <div>
                    <p className="label-caps text-resolute-red">Today&apos;s Session</p>
                    <h2 className="headline text-4xl">Training</h2>
                  </div>
                  {workouts.length > 0 && (
                    <motion.div
                      key={completedCount}
                      initial={{ scale: 1.2 }}
                      animate={{ scale: 1 }}
                      className="glass-red rounded-xl px-4 py-2 text-right"
                    >
                      <p className="stat-number text-3xl text-resolute-red">{completedCount}</p>
                      <p className="label-caps">of {workouts.length}</p>
                    </motion.div>
                  )}
                </div>

                {workouts.length === 0 ? (
                  <EmptyState
                    title={isBlankSlate ? "No workouts yet" : "No session assigned"}
                    description={
                      isBlankSlate
                        ? "Add today's training blocks and check them off as you go."
                        : "Coach Whitney will assign your training here."
                    }
                    actionLabel={isBlankSlate ? "Add Workout" : undefined}
                    onAction={isBlankSlate ? () => setShowAddWorkout(true) : undefined}
                  />
                ) : (
                  <div className="space-y-3">
                    {workouts.map((block, i) => (
                      <WorkoutCard
                        key={block.id}
                        block={block}
                        index={i}
                        onToggle={toggleWorkout}
                      />
                    ))}
                  </div>
                )}

                {isBlankSlate && showAddWorkout && (
                  <form
                    onSubmit={handleAddWorkout}
                    className="mt-4 space-y-3 rounded-xl border border-white/10 bg-white/[0.02] p-4"
                  >
                    <label className="label-caps" htmlFor="workout-title">
                      Workout name
                    </label>
                    <input
                      id="workout-title"
                      value={workoutTitle}
                      onChange={(e) => setWorkoutTitle(e.target.value)}
                      placeholder="e.g. Upper body lift"
                      className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-white/30 focus:border-resolute-red focus:outline-none"
                    />
                    <div className="flex gap-2">
                      <button type="submit" className="btn-red flex-1">
                        Save
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowAddWorkout(false)}
                        className="btn-ghost flex-1"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}

                {isBlankSlate && workouts.length > 0 && !showAddWorkout && (
                  <button
                    type="button"
                    onClick={() => setShowAddWorkout(true)}
                    className="btn-ghost mt-4 w-full"
                  >
                    Add Workout
                  </button>
                )}
              </section>
            </FadeUp>
          </>
        )}
      </AppShell>
    </>
  );
}

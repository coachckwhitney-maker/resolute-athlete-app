"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { useCoachVoice } from "@/context/AppTierProvider";
import type { CoachMessage } from "@/lib/types/athlete";

interface CoachMessageCardProps {
  message: CoachMessage;
}

export function CoachMessageCard({ message }: CoachMessageCardProps) {
  const voice = useCoachVoice();

  return (
    <motion.section
      initial={false}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.7, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="relative mb-6 overflow-hidden"
    >
      <div className="gradient-border">
        <div className="gradient-border-inner relative overflow-hidden p-6">
          <div className="pointer-events-none absolute -right-8 -top-8 opacity-[0.05]">
            <Image
              src="/logos/resolute-logo-stripe.png"
              alt=""
              width={200}
              height={200}
              aria-hidden
              className="rotate-12 object-contain"
            />
          </div>

          <motion.div
            animate={{ width: ["0%", "100%"] }}
            transition={{ duration: 1, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="absolute left-0 top-0 h-1 bg-resolute-red"
          />

          <div className="relative">
            <div className="mb-4 flex items-center gap-2">
              <motion.div
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="h-2 w-2 rounded-full bg-resolute-red shadow-[0_0_8px_rgba(227,24,55,0.8)]"
              />
              <p className="label-caps text-resolute-red">
                {voice.coachName} · Live
              </p>
            </div>

            <blockquote className="headline text-[clamp(1.75rem,6vw,2.5rem)] leading-[1.0] text-white">
              &ldquo;{message.message}&rdquo;
            </blockquote>

            <motion.div
              initial={false}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="mt-6 flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3">
                <span className="label-caps">Focus</span>
                <span className="glass-red px-4 py-1.5 font-display text-xl uppercase tracking-wider text-resolute-red">
                  {message.focus}
                </span>
              </div>
              {voice.coachFooter && (
                <span className="label-caps shrink-0 text-white/30">{voice.coachFooter}</span>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </motion.section>
  );
}

"use client";

import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { AnimatedBar } from "@/components/ui/AnimatedBar";
import { cn, getScoreColor } from "@/lib/utils";
import type { BlueprintScore } from "@/lib/types/athlete";

interface BlueprintPreviewProps {
  overall: number;
  scores: BlueprintScore[];
}

export function BlueprintPreview({ overall, scores }: BlueprintPreviewProps) {
  const rated = scores.filter((s) => s.score > 0);
  const focusArea = rated.length
    ? [...rated].sort((a, b) => a.score - b.score)[0]
    : null;
  const topScore = rated.length
    ? [...rated].sort((a, b) => b.score - a.score)[0]
    : null;
  const isEmpty = rated.length === 0;

  return (
    <section className="animate-fade-up stagger-3 animate-stagger relative mb-8">
      <div className="bento overflow-hidden p-6">
        {!isEmpty && (
          <span className="pointer-events-none absolute -right-2 -top-4 font-display text-[9rem] leading-none text-white/[0.04]">
            {overall}
          </span>
        )}

        <div className="relative flex items-end justify-between">
          <div>
            <p className="label-caps text-resolute-red">Athlete Blueprint</p>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="stat-number text-gradient-red">{overall}</span>
              <span className="font-display text-3xl text-white/20">/100</span>
            </div>
            <p className="mt-2 text-xs text-white/40">
              {isEmpty
                ? "Rate yourself across 10 dimensions"
                : "Whole athlete · 10 dimensions"}
            </p>
          </div>
          <Link
            href="/blueprint"
            className="flex h-12 w-12 items-center justify-center rounded-xl bg-resolute-red text-white shadow-glow-sm transition-all hover:scale-105 hover:shadow-glow active:scale-95"
            aria-label="View full Athlete Blueprint"
          >
            <ArrowUpRight className="h-5 w-5" />
          </Link>
        </div>

        {isEmpty ? (
          <p className="relative mt-5 text-sm text-white/45">
            No scores yet. Open your blueprint and rate each dimension.
          </p>
        ) : (
          <div className="relative mt-5 grid grid-cols-2 gap-3">
            <div className="glass rounded-xl p-4">
              <p className="label-caps">Strongest</p>
              <p className={cn("headline mt-1 text-2xl", getScoreColor(topScore!.score))}>
                {topScore!.label}
              </p>
              <p className="font-accent text-xs text-white/35">{topScore!.score}/100</p>
            </div>
            <div className="glass-red rounded-xl p-4">
              <p className="label-caps text-resolute-red">Focus Area</p>
              <p className="headline mt-1 text-2xl text-white">{focusArea!.label}</p>
              <AnimatedBar value={focusArea!.score} className="mt-3 h-1" />
            </div>
          </div>
        )}

        <Link
          href="/blueprint"
          className="relative mt-4 block text-center text-xs font-bold uppercase tracking-widest text-resolute-red hover:text-white transition-colors"
        >
          {isEmpty ? "Set up your blueprint →" : "View all 10 dimensions →"}
        </Link>
      </div>
    </section>
  );
}

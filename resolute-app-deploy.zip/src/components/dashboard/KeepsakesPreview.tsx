"use client";

import Link from "next/link";
import Image from "next/image";
import { ImageIcon } from "lucide-react";
import { useAthleteData } from "@/context/AthleteDataProvider";

export function KeepsakesPreview() {
  const { keepsakes, getKeepsakeImage, canManageKeepsakes } = useAthleteData();

  if (!canManageKeepsakes) return null;

  const recent = keepsakes.slice(0, 4);

  return (
    <section className="mb-8">
      <div className="mb-4 flex items-end justify-between">
        <div>
          <p className="label-caps text-resolute-red">Meet Keepsakes</p>
          <h2 className="headline text-3xl">Memory Wall</h2>
          <p className="mt-1 text-xs text-white/40">
            Race bibs, meet stickers & photos from your season
          </p>
        </div>
        <Link
          href="/progress?tab=keepsakes"
          className="text-xs uppercase tracking-wider text-white/40 hover:text-white"
        >
          {keepsakes.length > 0 ? "View all →" : "Add →"}
        </Link>
      </div>

      {recent.length === 0 ? (
        <Link
          href="/progress?tab=keepsakes"
          className="glass flex items-center gap-4 rounded-xl border border-dashed border-white/10 p-5 transition-colors hover:border-resolute-red/30 hover:bg-white/[0.03]"
        >
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-resolute-red/10">
            <ImageIcon className="h-6 w-6 text-resolute-red" />
          </div>
          <div>
            <p className="font-medium text-white/80">Save your first keepsake</p>
            <p className="mt-0.5 text-xs text-white/40">
              Attach a bib, sticker, or photo from your next meet
            </p>
          </div>
        </Link>
      ) : (
        <div className="grid grid-cols-4 gap-2">
          {recent.map((item) => {
            const src = getKeepsakeImage(item.id);
            return (
              <Link
                key={item.id}
                href="/progress?tab=keepsakes"
                className="relative aspect-square overflow-hidden rounded-lg bg-black/40 ring-1 ring-white/10 transition-transform hover:scale-[1.02]"
              >
                {src ? (
                  <Image src={src} alt={item.title} fill unoptimized className="object-cover" />
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <ImageIcon className="h-5 w-5 text-white/20" />
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      )}
    </section>
  );
}

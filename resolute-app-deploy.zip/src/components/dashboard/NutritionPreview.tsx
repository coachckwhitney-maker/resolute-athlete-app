"use client";

import Link from "next/link";
import { Apple, Droplets } from "lucide-react";
import { useAthleteData } from "@/context/AthleteDataProvider";

function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

export function NutritionPreview() {
  const { nutritionLogs, canManageNutrition } = useAthleteData();

  if (!canManageNutrition) return null;

  const todayLog = nutritionLogs.find((entry) => entry.date === todayKey());

  return (
    <section className="mb-8">
      <Link
        href="/nutrition"
        className="glass group block rounded-xl p-5 transition-colors hover:bg-white/[0.04]"
      >
        <div className="flex items-start gap-4">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-resolute-red/15">
            <Apple className="h-5 w-5 text-resolute-red" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="label-caps text-resolute-red">Nutrition</p>
            <p className="headline mt-1 text-xl text-white">Daily fuel tracker</p>
            {todayLog ? (
              <div className="mt-2 flex flex-wrap gap-3 text-xs text-white/45">
                <span className="inline-flex items-center gap-1">
                  <Droplets className="h-3 w-3 text-resolute-red/70" />
                  {todayLog.waterGlasses} water
                </span>
                <span>{todayLog.proteinServings} protein</span>
                <span>{todayLog.fruitServings} fruit</span>
                <span>{todayLog.vegetableServings} veg</span>
              </div>
            ) : (
              <p className="mt-2 text-sm text-white/45">
                Water, protein, fruits, vegetables & pre/post-workout meals — no calorie counting required.
              </p>
            )}
            <p className="mt-3 text-xs uppercase tracking-wider text-white/30 group-hover:text-resolute-red/80">
              {todayLog ? "Update today →" : "Log today →"}
            </p>
          </div>
        </div>
      </Link>
    </section>
  );
}

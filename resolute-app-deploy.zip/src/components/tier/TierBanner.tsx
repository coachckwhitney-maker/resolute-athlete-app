"use client";

import Link from "next/link";
import { useCoachVoice } from "@/context/AppTierProvider";

export function TierBanner() {
  const voice = useCoachVoice();

  if (voice.isCoached) {
    return (
      <div className="mb-4 flex items-center justify-between rounded-xl border border-resolute-red/25 bg-resolute-red/10 px-4 py-2">
        <p className="font-accent text-[10px] font-bold uppercase tracking-wider text-resolute-red">
          {voice.tierLabel.name}
        </p>
        <span className="text-[10px] text-white/40">Coached by Coach Whitney</span>
      </div>
    );
  }

  if (voice.isTeamAthlete) {
    return (
      <div className="mb-4 flex items-center justify-between gap-3 rounded-xl border border-resolute-red/25 bg-resolute-red/10 px-4 py-3">
        <div>
          <p className="font-accent text-[10px] font-bold uppercase tracking-wider text-resolute-red">
            {voice.tierLabel.name}
          </p>
          <p className="text-xs text-white/45">Whole-athlete development · no app workouts</p>
        </div>
        <Link
          href="/upgrade"
          className="shrink-0 rounded-lg border border-resolute-red/40 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-resolute-red"
        >
          Remote Coaching
        </Link>
      </div>
    );
  }

  return (
    <div className="mb-4 flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3">
      <div>
        <p className="font-accent text-[10px] font-bold uppercase tracking-wider text-white/40">
          {voice.tierLabel.name}
        </p>
        <p className="text-xs text-white/45">Your blank tracker</p>
      </div>
      <Link
        href="/upgrade"
        className="shrink-0 rounded-lg bg-resolute-red px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-white"
      >
        Upgrade
      </Link>
    </div>
  );
}

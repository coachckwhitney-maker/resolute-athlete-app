"use client";

import Link from "next/link";
import { useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { UpgradeComparison } from "@/components/upgrade/UpgradeComparison";
import { useAppTier } from "@/context/AppTierProvider";
import {
  SUBSCRIPTIONS_ENABLED,
  subscriptionPricing,
  tierLabels,
  upgradeHeadline,
  coachedTagline,
} from "@/lib/config/tier";
import { ArrowLeft, Check, ChevronDown, KeyRound, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export function UpgradeClient() {
  const { unlockTeamWithCode, unlockCoachedWithCode, voice } = useAppTier();
  const [billing, setBilling] = useState<"monthly" | "yearly">("yearly");
  const [teamCode, setTeamCode] = useState("");
  const [teamCodeError, setTeamCodeError] = useState(false);
  const [teamCodeSuccess, setTeamCodeSuccess] = useState(false);
  const [showTeamCode, setShowTeamCode] = useState(false);
  const [subscribeNotice, setSubscribeNotice] = useState<string | null>(null);

  const pricing = subscriptionPricing[billing];
  const isCoached = voice.isCoached;
  const isTeam = voice.isTeamAthlete;

  function handleSubscribe() {
    if (SUBSCRIPTIONS_ENABLED) {
      return;
    }
    setSubscribeNotice(
      "App Store subscriptions are coming soon. Current Resolute athletes: use your free team code below."
    );
  }

  function handleTeamCodeSubmit(e: React.FormEvent) {
    e.preventDefault();
    const ok = unlockTeamWithCode(teamCode);
    if (ok) {
      setTeamCodeSuccess(true);
      setTeamCodeError(false);
    } else {
      setTeamCodeError(true);
    }
  }

  if (isCoached) {
    return (
      <AppShell>
        <Link href="/dashboard" className="mb-6 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white/40 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
          Back
        </Link>
        <div className="glass-red rounded-xl p-6 text-center red-glow">
          <p className="headline text-3xl text-gradient-red">You&apos;re Coached</p>
          <p className="mt-2 text-sm text-white/55">
            {tierLabels.coached.name} — daily workouts and Coach Whitney&apos;s full program.
          </p>
          <Link href="/dashboard" className="btn-red mt-6 inline-flex w-full justify-center">
            Go to Today
          </Link>
        </div>
      </AppShell>
    );
  }

  if (isTeam || teamCodeSuccess) {
    return (
      <AppShell>
        <Link href="/dashboard" className="mb-6 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white/40 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
          Back
        </Link>
        <div className="glass-red rounded-xl p-6 text-center red-glow">
          <p className="headline text-3xl text-gradient-red">Welcome, Resolute Athlete</p>
          <p className="mt-2 text-sm text-white/55">
            {tierLabels.team.name} — culture, mindset, recovery & whole-athlete development.
            No app workouts — you train with us in person.
          </p>
          <Link href="/dashboard" className="btn-red mt-6 inline-flex w-full justify-center">
            Open Portal
          </Link>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <Link
        href="/dashboard"
        className="mb-6 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white/40 hover:text-white"
      >
        <ArrowLeft className="h-4 w-4" />
        Back
      </Link>

      <header className="mb-8">
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-resolute-red/15">
          <Sparkles className="h-6 w-6 text-resolute-red" />
        </div>
        <h1 className="headline text-[clamp(2.25rem,9vw,3rem)] leading-none text-white">
          {upgradeHeadline.coached.title}
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-white/45">
          {coachedTagline}
        </p>
      </header>

      <UpgradeComparison className="mb-8" highlight="coached" />

      <section className="mb-8">
        <p className="label-caps mb-4 text-resolute-red">Coached Athlete · Subscribe</p>
        <div className="mb-4 flex gap-2 rounded-xl border border-white/10 bg-white/[0.02] p-1">
          {(["monthly", "yearly"] as const).map((plan) => {
            const option = subscriptionPricing[plan];
            const active = billing === plan;
            return (
              <button
                key={plan}
                type="button"
                onClick={() => setBilling(plan)}
                className={cn(
                  "relative flex-1 rounded-lg px-3 py-3 text-left transition-all",
                  active
                    ? "bg-resolute-red text-white shadow-glow-sm"
                    : "text-white/50 hover:text-white/70"
                )}
              >
                {"recommended" in option && option.recommended && (
                  <span
                    className={cn(
                      "absolute -top-2 right-2 rounded-full px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider",
                      active ? "bg-white text-resolute-red" : "bg-resolute-red/20 text-resolute-red"
                    )}
                  >
                    Best
                  </span>
                )}
                <span className="block text-xs font-bold uppercase tracking-wider">
                  {option.label}
                </span>
                <span className="headline mt-1 block text-2xl">
                  ${option.amount}
                  <span className="text-sm font-normal opacity-70">{option.period}</span>
                </span>
              </button>
            );
          })}
        </div>

        <p className="mb-4 text-xs text-white/40">{pricing.tagline}</p>

        <button type="button" onClick={handleSubscribe} className="btn-red w-full">
          Subscribe — ${pricing.amount}
          {pricing.period}
        </button>

        {subscribeNotice && (
          <p className="mt-3 rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white/55">
            {subscribeNotice}
          </p>
        )}

        <ul className="mt-4 space-y-2">
          {[
            "Daily workouts assigned in-app",
            "Coach Whitney trains you remotely",
            "Full program — speed, strength, recovery",
          ].map((item) => (
            <li key={item} className="flex items-center gap-2 text-xs text-white/45">
              <Check className="h-3.5 w-3.5 text-resolute-red" />
              {item}
            </li>
          ))}
        </ul>
      </section>

      <div className="divider-glow mb-8" />

      <section>
        <button
          type="button"
          onClick={() => setShowTeamCode((open) => !open)}
          className="flex w-full items-center justify-between rounded-xl border border-white/10 bg-white/[0.02] px-4 py-4 text-left"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/5">
              <KeyRound className="h-5 w-5 text-white/50" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">Current Resolute high school athlete?</p>
              <p className="text-xs text-white/40">Free portal — culture, mindset, recovery (no app workouts)</p>
            </div>
          </div>
          <ChevronDown
            className={cn(
              "h-5 w-5 text-white/30 transition-transform",
              showTeamCode && "rotate-180"
            )}
          />
        </button>

        {showTeamCode && (
          <form
            onSubmit={handleTeamCodeSubmit}
            className="mt-4 space-y-3 rounded-xl border border-white/10 bg-white/[0.02] p-4"
          >
            <div>
              <label className="label-caps" htmlFor="team-code">
                Team Access Code
              </label>
              <input
                id="team-code"
                type="text"
                value={teamCode}
                onChange={(e) => {
                  setTeamCode(e.target.value);
                  setTeamCodeError(false);
                }}
                placeholder="From Coach Whitney"
                className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-white/30 focus:border-resolute-red focus:outline-none"
                autoComplete="off"
              />
              {teamCodeError && (
                <p className="mt-2 text-sm text-resolute-red">
                  That code didn&apos;t work. Ask Coach Whitney if you&apos;re on the team.
                </p>
              )}
            </div>
            <button type="submit" className="btn-ghost w-full border-resolute-red/30 text-resolute-red">
              Unlock Free — Resolute Athlete Portal
            </button>
          </form>
        )}
      </section>

      <p className="mt-8 text-center text-xs text-white/30">
        Current plan: {voice.tierLabel.name}
      </p>
    </AppShell>
  );
}

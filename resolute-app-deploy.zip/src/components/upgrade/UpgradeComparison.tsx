import Link from "next/link";
import { Check, Lock } from "lucide-react";
import { tierComparison, tierLabels } from "@/lib/config/tier";
import { cn } from "@/lib/utils";

interface UpgradeComparisonProps {
  className?: string;
  highlight?: "team" | "coached";
}

export function UpgradeComparison({
  className,
  highlight = "coached",
}: UpgradeComparisonProps) {
  return (
    <div className={cn("grid gap-4", className)}>
      <div className={cn("bento p-5", highlight === "team" && "ring-1 ring-resolute-red/40")}>
        <p className="label-caps text-white/40">{tierLabels.team.name}</p>
        <p className="headline mt-1 text-2xl text-white">Free · Team</p>
        <ul className="mt-4 space-y-2.5">
          {tierComparison.team.map((item) => (
            <li key={item} className="flex items-start gap-2 text-sm text-white/50">
              <Check className="mt-0.5 h-4 w-4 shrink-0 text-white/30" />
              {item}
            </li>
          ))}
        </ul>
      </div>

      <div
        className={cn(
          "glass-red relative overflow-hidden p-5 red-glow",
          highlight === "coached" && "ring-1 ring-resolute-red"
        )}
      >
        <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-resolute-red/20 blur-2xl" />
        <p className="label-caps text-resolute-red">{tierLabels.coached.name}</p>
        <p className="headline mt-1 text-2xl text-gradient-red">Paid · Remote</p>
        <ul className="relative mt-4 space-y-2.5">
          {tierComparison.coached.map((item) => (
            <li key={item} className="flex items-start gap-2 text-sm text-white/70">
              <Check className="mt-0.5 h-4 w-4 shrink-0 text-resolute-red" />
              {item}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

interface UpgradeCTAProps {
  variant?: "card" | "inline";
  className?: string;
  title?: string;
  description?: string;
}

export function UpgradeCTA({
  variant = "card",
  className,
  title = "Get Coached by Coach Whitney",
  description = "Daily workouts through the app — for athletes training remotely.",
}: UpgradeCTAProps) {
  if (variant === "inline") {
    return (
      <Link
        href="/upgrade"
        className={cn(
          "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-resolute-red hover:text-resolute-red-bright",
          className
        )}
      >
        <Lock className="h-3.5 w-3.5" />
        Upgrade to coached
      </Link>
    );
  }

  return (
    <Link
      href="/upgrade"
      className={cn(
        "group block overflow-hidden rounded-xl border border-resolute-red/30 bg-gradient-to-br from-resolute-red/15 to-transparent p-5 transition-all hover:border-resolute-red/50 hover:shadow-glow-sm",
        className
      )}
    >
      <p className="label-caps text-resolute-red">{title}</p>
      <p className="headline mt-2 text-2xl leading-tight text-white">
        Coached Athlete
      </p>
      <p className="mt-2 text-sm text-white/45">{description}</p>
      <span className="mt-4 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-resolute-red transition-transform group-hover:translate-x-1">
        View plans
        <span aria-hidden>→</span>
      </span>
    </Link>
  );
}

"use client";

import Link from "next/link";
import { AppShell } from "@/components/layout/AppShell";
import { EmptyState } from "@/components/ui/EmptyState";

interface FeaturePaywallProps {
  feature: string;
  description: string;
}

export function FeaturePaywall({ feature, description }: FeaturePaywallProps) {
  return (
    <AppShell>
      <EmptyState
        title={`${feature} — Coached Athletes`}
        description={description}
        actionLabel="Get Coached by Coach Whitney"
        onAction={() => {
          window.location.assign("/upgrade");
        }}
      />
      <Link
        href="/dashboard"
        className="btn-ghost mx-auto mt-4 block max-w-xs text-center"
      >
        Back to dashboard
      </Link>
    </AppShell>
  );
}

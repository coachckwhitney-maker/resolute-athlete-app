"use client";

import Link from "next/link";
import { AppShell } from "@/components/layout/AppShell";
import { MindsetLibrary } from "@/components/mindset/MindsetLibrary";
import { MindsetPhilosophyWall } from "@/components/mindset/MindsetPhilosophyWall";
import { FavoriteQuotesWall } from "@/components/mindset/FavoriteQuotesWall";
import { UpgradeCTA } from "@/components/upgrade/UpgradeComparison";
import { useCoachVoice } from "@/context/AppTierProvider";
import { getClientFavoriteQuote } from "@/lib/coach/voice";
import { signatureFooter } from "@/lib/data/signatureSayings";
import { Brain } from "lucide-react";

export function MindsetPageClient() {
  const voice = useCoachVoice();
  const lessons = voice.mindsetLessons;
  const dailyQuote = voice.getDailyMindsetQuote();
  const clientFavorite = voice.features.whitneyVoice ? getClientFavoriteQuote() : null;

  if (!voice.features.mindset) {
    return (
      <AppShell>
        <header className="mb-8">
          <div className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-resolute-red" />
            <p className="label-caps text-resolute-red">Mindset Library</p>
          </div>
          <h1 className="headline mt-2 text-4xl text-white">Resolute Athletes Only</h1>
          <p className="mt-3 text-sm text-white/45">
            Coach Whitney&apos;s mindset library is included with the team portal or coached
            subscription.
          </p>
        </header>
        <UpgradeCTA />
        <Link href="/dashboard" className="btn-ghost mt-4 block w-full text-center">
          Back to Today
        </Link>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <header className="animate-fade-up mb-8">
        <p className="label-caps text-resolute-red">The Heart of Coaching</p>
        <h1 className="headline text-5xl">
          Mindset
          <br />
          <span className="text-gradient-red">Library</span>
        </h1>
        <p className="mt-2 text-sm text-white/40 text-balance">
          &ldquo;{voice.mindsetFeatured}&rdquo;
        </p>
      </header>

      <blockquote className="glass-red mb-10 border-l-2 border-resolute-red p-5">
        <p className="label-caps text-resolute-red">
          {voice.coachName} · {dailyQuote.tag}
        </p>
        <p className="headline mt-2 text-2xl leading-tight text-white">
          &ldquo;{dailyQuote.text}&rdquo;
        </p>
        {dailyQuote.note && (
          <p className="mt-3 text-sm leading-relaxed text-white/50">{dailyQuote.note}</p>
        )}
        {voice.coachFooter && (
          <p className="label-caps mt-4 text-white/30">{signatureFooter}</p>
        )}
      </blockquote>

      {lessons.showPhilosophyWall && <MindsetPhilosophyWall />}

      {clientFavorite && (
        <blockquote className="glass mb-10 border-l-2 border-white/20 p-5">
          <p className="label-caps">Quote of the Day · {clientFavorite.tag}</p>
          <p className="headline mt-2 text-xl leading-tight text-gradient-red">
            &ldquo;{clientFavorite.text}&rdquo;
          </p>
        </blockquote>
      )}

      {lessons.showFavoriteQuotes && <FavoriteQuotesWall />}

      {lessons.showFavoriteQuotes && (
        <MindsetLibrary
          title="Sounds Like Coach Whitney"
          subtitle="Favorite quotes — your voice, even without your name on them"
          initialLessons={lessons.favoriteLessons}
        />
      )}

      {lessons.showFoundation && (
        <MindsetLibrary
          title="Your Foundation"
          subtitle="Who you are as a coach"
          initialLessons={lessons.foundationLessons}
          className="mt-12"
        />
      )}

      {lessons.showAthleteLines && (
        <MindsetLibrary
          title="What I Tell My Athletes"
          subtitle="What you say constantly — on the track, in the weight room, every day"
          initialLessons={lessons.athleteLessons}
          className="mt-12"
        />
      )}

      {lessons.showCulture && (
        <MindsetLibrary
          title="Team Culture"
          subtitle="Unmistakably Coach Whitney — how we treat each other and this program"
          initialLessons={lessons.cultureLessons}
          className="mt-12"
        />
      )}

      {lessons.showAccountability && (
        <MindsetLibrary
          title="Hard Conversations"
          subtitle="What you say when you hold athletes accountable — because you believe in them"
          initialLessons={lessons.accountabilityLessons}
          className="mt-12"
        />
      )}

      {voice.isTeamAthlete && (
        <UpgradeCTA className="mt-12" />
      )}
    </AppShell>
  );
}

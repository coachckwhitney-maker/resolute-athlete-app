import { mindsetPhilosophyLines } from "@/lib/data/mindsetPhilosophy";

export function MindsetPhilosophyWall() {
  return (
    <section className="mb-8">
      <p className="label-caps text-resolute-red">The Heart of Coaching</p>
      <p className="mt-1 text-sm text-white/40">
        Why you coach — building people, not just athletes
      </p>
      <div className="mt-5 grid gap-3">
        {mindsetPhilosophyLines.map((line) => (
          <div
            key={line.id}
            className="bento overflow-hidden rounded-xl border-l-2 border-resolute-red/50 p-5"
          >
            <p className="font-accent text-[10px] font-bold uppercase tracking-wider text-resolute-red">
              {line.tag}
            </p>
            <p className="headline mt-2 text-xl leading-tight text-white">
              &ldquo;{line.text}&rdquo;
            </p>
            <p className="mt-3 text-sm leading-relaxed text-white/50">{line.lessonNote}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

"use client";

import { useEffect, useState } from "react";
import { Check, Play } from "lucide-react";
import { cn } from "@/lib/utils";
import type { MindsetLesson } from "@/lib/types/athlete";

interface MindsetLibraryProps {
  initialLessons: MindsetLesson[];
  title?: string;
  subtitle?: string;
  className?: string;
}

export function MindsetLibrary({
  initialLessons,
  title,
  subtitle,
  className = "",
}: MindsetLibraryProps) {
  const [lessons, setLessons] = useState(initialLessons);
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    setLessons(initialLessons);
  }, [initialLessons]);

  const completed = lessons.filter((l) => l.completed).length;

  function toggleComplete(id: string) {
    setLessons((prev) =>
      prev.map((l) => (l.id === id ? { ...l, completed: !l.completed } : l))
    );
  }

  return (
    <section className={className}>
      {title && (
        <div className="mb-5">
          <p className="label-caps text-resolute-red">{title}</p>
          {subtitle && (
            <p className="mt-1 text-sm text-white/40">{subtitle}</p>
          )}
        </div>
      )}
      <div className="mb-6 flex items-end justify-between">
        <p className="label-caps">{completed}/{lessons.length} Complete</p>
        <div className="flex gap-1">
          {lessons.map((l) => (
            <div
              key={l.id}
              className={cn(
                "h-1 w-6 transition-all duration-500",
                l.completed ? "bg-resolute-red" : "bg-white/10"
              )}
            />
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {lessons.map((lesson, i) => {
          const isActive = activeId === lesson.id;
          return (
            <article
              key={lesson.id}
              className={cn(
                "animate-fade-up animate-stagger overflow-hidden border transition-all duration-300",
                `stagger-${Math.min(i + 1, 8)}`,
                isActive
                  ? "border-resolute-red bg-resolute-red/5"
                  : "border-white/10 bg-resolute-900",
                lesson.completed && !isActive && "opacity-60"
              )}
            >
              <button
                type="button"
                className="flex w-full items-start gap-4 p-5 text-left"
                onClick={() => setActiveId(isActive ? null : lesson.id)}
              >
                <div
                  className={cn(
                    "flex h-12 w-12 shrink-0 items-center justify-center transition-all",
                    isActive ? "bg-resolute-red" : "border border-white/20"
                  )}
                >
                  <Play
                    className={cn(
                      "h-5 w-5 fill-current",
                      isActive ? "text-white" : "text-white/60"
                    )}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="label-caps">{lesson.category}</span>
                    <span className="text-white/30">·</span>
                    <span className="text-xs text-white/30">{lesson.duration}</span>
                    {lesson.completed && (
                      <Check className="ml-auto h-4 w-4 text-resolute-red" />
                    )}
                  </div>
                  <h3 className={`headline mt-1 ${lesson.title.length > 40 ? "text-xl" : "text-2xl"}`}>
                    {lesson.title}
                  </h3>
                </div>
              </button>

              {isActive && (
                <div className="animate-fade-in border-t border-white/10 px-5 pb-5">
                  <p className="mt-4 text-sm leading-relaxed text-white/60">
                    {lesson.description}
                  </p>
                  <button
                    type="button"
                    onClick={() => toggleComplete(lesson.id)}
                    className={cn(
                      "mt-4 w-full py-3 text-xs font-bold uppercase tracking-widest transition-all active:scale-[0.98]",
                      lesson.completed
                        ? "border border-white/20 text-white/60"
                        : "bg-resolute-red text-white hover:bg-resolute-red-bright"
                    )}
                  >
                    {lesson.completed ? "Mark Incomplete" : "Complete Lesson"}
                  </button>
                </div>
              )}
            </article>
          );
        })}
      </div>
    </section>
  );
}

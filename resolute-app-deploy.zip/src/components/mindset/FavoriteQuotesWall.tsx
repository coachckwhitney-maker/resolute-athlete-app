import { favoriteQuotes } from "@/lib/data/favoriteQuotes";

export function FavoriteQuotesWall() {
  return (
    <section className="mb-8">
      <p className="label-caps text-resolute-red">Sounds Like Coach Whitney</p>
      <p className="mt-1 text-sm text-white/40">
        Read these without a name attached — still unmistakably you
      </p>

      {/* Highlight scroll */}
      <div className="no-scrollbar -mx-6 mt-5 flex snap-x snap-mandatory gap-4 overflow-x-auto px-6 pb-2">
        {favoriteQuotes.map((quote) => (
          <div
            key={quote.id}
            className="card-interactive min-w-[280px] shrink-0 snap-center p-5"
          >
            <p className="font-accent text-[10px] font-bold uppercase tracking-wider text-resolute-red">
              {quote.tag}
            </p>
            <p className="headline mt-3 text-xl leading-tight text-white">
              &ldquo;{quote.text}&rdquo;
            </p>
            <p className="mt-3 text-xs leading-relaxed text-white/45">{quote.lessonNote}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

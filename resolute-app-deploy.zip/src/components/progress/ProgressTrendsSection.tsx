"use client";

import { useState } from "react";
import { Medal, Trash2, Users } from "lucide-react";
import { TrendChart } from "@/components/progress/TrendChart";
import {
  TrackingForm,
  TrackingInput,
  TrackingSelect,
  TrackingTextarea,
} from "@/components/progress/TrackingForm";
import type {
  AttendanceEntry,
  CompetitionResult,
  PersonalRecord,
  TrainingLogCategory,
  TrainingLogEntry,
  WellnessMetric,
} from "@/lib/types/athlete";
import {
  aggregateTrainingByWeek,
  aggregateWellnessByLabel,
  getAttendanceRate,
  getPrProgression,
} from "@/lib/utils/progressTrends";

interface ProgressTrendsSectionProps {
  personalRecords: PersonalRecord[];
  wellnessMetrics: WellnessMetric[];
  trainingLogs: TrainingLogEntry[];
  competitionResults: CompetitionResult[];
  attendance: AttendanceEntry[];
  canEdit: boolean;
  onAddTrainingLog: (entry: Omit<TrainingLogEntry, "id">) => void;
  onAddCompetitionResult: (result: Omit<CompetitionResult, "id">) => void;
  onAddAttendance: (entry: Omit<AttendanceEntry, "id">) => void;
  onRemoveCompetitionResult: (id: string) => void;
}

const VOLUME_CATEGORIES: {
  category: TrainingLogCategory;
  label: string;
  unit: string;
  subtitle: string;
}[] = [
  { category: "distance", label: "Weekly Mileage", unit: "mi", subtitle: "Total distance per week" },
  { category: "sprint", label: "Sprint Volume", unit: "reps", subtitle: "Sprint reps or meters per week" },
  { category: "jump", label: "Jump Count", unit: "jumps", subtitle: "Jumps per week" },
  { category: "throw", label: "Throw Count", unit: "throws", subtitle: "Throws per week" },
  { category: "strength", label: "Strength Progress", unit: "lbs", subtitle: "Top lifts or volume per week" },
];

export function ProgressTrendsSection({
  personalRecords,
  wellnessMetrics,
  trainingLogs,
  competitionResults,
  attendance,
  canEdit,
  onAddTrainingLog,
  onAddCompetitionResult,
  onAddAttendance,
  onRemoveCompetitionResult,
}: ProgressTrendsSectionProps) {
  const [showVolumeForm, setShowVolumeForm] = useState(false);
  const [showCompForm, setShowCompForm] = useState(false);
  const [showAttForm, setShowAttForm] = useState(false);
  const [volumeCategory, setVolumeCategory] = useState<TrainingLogCategory>("distance");
  const [volumeValue, setVolumeValue] = useState("");
  const [volumeDate, setVolumeDate] = useState(new Date().toISOString().slice(0, 10));
  const [compDate, setCompDate] = useState("");
  const [compMeet, setCompMeet] = useState("");
  const [compEvent, setCompEvent] = useState("");
  const [compResult, setCompResult] = useState("");
  const [compPlace, setCompPlace] = useState("");
  const [attDate, setAttDate] = useState(new Date().toISOString().slice(0, 10));
  const [attPresent, setAttPresent] = useState("yes");
  const [attNote, setAttNote] = useState("");

  const prPoints = getPrProgression(personalRecords);
  const sleepPoints = aggregateWellnessByLabel(wellnessMetrics, /sleep/i);
  const wellnessPoints = aggregateWellnessByLabel(wellnessMetrics, /wellness|soreness|energy|mood/i);
  const attendancePoints = getAttendanceRate(attendance);

  function handleVolumeSubmit(e: React.FormEvent) {
    e.preventDefault();
    const meta = VOLUME_CATEGORIES.find((c) => c.category === volumeCategory)!;
    if (!volumeValue.trim()) return;
    onAddTrainingLog({
      category: volumeCategory,
      label: meta.label,
      value: Number(volumeValue),
      unit: meta.unit,
      date: volumeDate,
    });
    setVolumeValue("");
    setShowVolumeForm(false);
  }

  function handleCompSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!compDate || !compMeet.trim() || !compEvent.trim() || !compResult.trim()) return;
    onAddCompetitionResult({
      date: compDate,
      meetName: compMeet.trim(),
      event: compEvent.trim(),
      result: compResult.trim(),
      place: compPlace.trim() || undefined,
    });
    setCompDate("");
    setCompMeet("");
    setCompEvent("");
    setCompResult("");
    setCompPlace("");
    setShowCompForm(false);
  }

  function handleAttSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!attDate) return;
    onAddAttendance({
      date: attDate,
      present: attPresent === "yes",
      note: attNote.trim() || undefined,
    });
    setAttNote("");
    setShowAttForm(false);
  }

  return (
    <div className="space-y-8">
      <div>
        <p className="label-caps text-resolute-red">Visual Progress</p>
        <p className="mt-1 text-xs text-white/40">
          Trends update as you log — athletes see progress over time
        </p>
        {canEdit && (
          <button
            type="button"
            onClick={() => setShowVolumeForm(true)}
            className="btn-ghost mt-3 w-full text-xs"
          >
            Log Training Volume
          </button>
        )}
      </div>

      {canEdit && showVolumeForm && (
        <TrackingForm onSubmit={handleVolumeSubmit} onCancel={() => setShowVolumeForm(false)}>
          <TrackingSelect
            value={volumeCategory}
            onChange={(v) => setVolumeCategory(v as TrainingLogCategory)}
            options={VOLUME_CATEGORIES.map((c) => ({ value: c.category, label: c.label }))}
          />
          <TrackingInput value={volumeDate} onChange={setVolumeDate} type="date" placeholder="Date" />
          <TrackingInput value={volumeValue} onChange={setVolumeValue} type="number" placeholder="Value" />
        </TrackingForm>
      )}

      <TrendChart
        title="PR Progression"
        subtitle="Latest marks by event"
        points={prPoints}
        emptyMessage="Add PRs to see progression"
      />

      {VOLUME_CATEGORIES.map((cat) => (
        <TrendChart
          key={cat.category}
          title={cat.label}
          subtitle={cat.subtitle}
          points={aggregateTrainingByWeek(trainingLogs, cat.category)}
          unit={cat.unit}
          emptyMessage={`Log ${cat.label.toLowerCase()} to build your trend`}
        />
      ))}

      <TrendChart
        title="Sleep Trend"
        subtitle="From wellness logs labeled Sleep"
        points={sleepPoints}
        unit="hrs"
        emptyMessage="Log wellness with label 'Sleep' to track rest"
      />

      <TrendChart
        title="Wellness Trend"
        subtitle="Soreness, energy, mood & wellness scores"
        points={wellnessPoints}
        emptyMessage="Log wellness metrics to track recovery"
      />

      <section>
        <div className="mb-4 flex items-center justify-between">
          <div>
            <p className="label-caps text-resolute-red">Competition Results</p>
            <p className="mt-1 text-xs text-white/40">Meet performances over the season</p>
          </div>
          {canEdit && !showCompForm && (
            <button type="button" onClick={() => setShowCompForm(true)} className="btn-ghost text-xs">
              Add Result
            </button>
          )}
        </div>

        {canEdit && showCompForm && (
          <TrackingForm onSubmit={handleCompSubmit} onCancel={() => setShowCompForm(false)} className="mb-4">
            <TrackingInput value={compDate} onChange={setCompDate} type="date" placeholder="Date" required />
            <TrackingInput value={compMeet} onChange={setCompMeet} placeholder="Meet name" required />
            <TrackingInput value={compEvent} onChange={setCompEvent} placeholder="Event" required />
            <TrackingInput value={compResult} onChange={setCompResult} placeholder="Result" required />
            <TrackingInput value={compPlace} onChange={setCompPlace} placeholder="Place (optional)" />
          </TrackingForm>
        )}

        {competitionResults.length === 0 ? (
          <p className="text-sm text-white/35">No competition results yet</p>
        ) : (
          <div className="space-y-2">
            {competitionResults.map((result) => (
              <div
                key={result.id}
                className="glass flex items-center justify-between rounded-xl px-5 py-4"
              >
                <div className="flex items-center gap-3">
                  <Medal className="h-4 w-4 text-resolute-red" />
                  <div>
                    <p className="font-medium text-white/85">
                      {result.event} — {result.result}
                    </p>
                    <p className="text-xs text-white/35">
                      {result.meetName} · {result.date}
                      {result.place && ` · ${result.place}`}
                    </p>
                  </div>
                </div>
                {canEdit && (
                  <button
                    type="button"
                    onClick={() => onRemoveCompetitionResult(result.id)}
                    className="text-white/30 hover:text-resolute-red"
                    aria-label="Remove result"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      <section>
        <div className="mb-4 flex items-center justify-between">
          <div>
            <p className="label-caps text-resolute-red">Attendance</p>
            <p className="mt-1 text-xs text-white/40">Weekly attendance rate</p>
          </div>
          {canEdit && !showAttForm && (
            <button type="button" onClick={() => setShowAttForm(true)} className="btn-ghost text-xs">
              Log Day
            </button>
          )}
        </div>

        <TrendChart
          title="Attendance Rate"
          subtitle="Present vs total sessions per week"
          points={attendancePoints}
          unit="%"
          emptyMessage="Log practice attendance to see your rate"
        />

        {canEdit && showAttForm && (
          <TrackingForm onSubmit={handleAttSubmit} onCancel={() => setShowAttForm(false)} className="mt-4">
            <TrackingInput value={attDate} onChange={setAttDate} type="date" placeholder="Date" required />
            <TrackingSelect
              value={attPresent}
              onChange={setAttPresent}
              options={[
                { value: "yes", label: "Present" },
                { value: "no", label: "Absent" },
              ]}
            />
            <TrackingTextarea value={attNote} onChange={setAttNote} placeholder="Note (optional)" />
          </TrackingForm>
        )}

        {attendance.length > 0 && (
          <div className="mt-3 space-y-2">
            {attendance.slice(0, 5).map((entry) => (
              <div
                key={entry.id}
                className="flex items-center gap-2 text-sm text-white/50"
              >
                <Users className="h-3.5 w-3.5" />
                {entry.date} — {entry.present ? "Present" : "Absent"}
                {entry.note && <span className="text-white/30">· {entry.note}</span>}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

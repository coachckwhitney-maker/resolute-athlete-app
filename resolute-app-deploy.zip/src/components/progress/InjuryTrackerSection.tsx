"use client";

import { useState } from "react";
import { AlertTriangle, Trash2 } from "lucide-react";
import { EmptyState } from "@/components/ui/EmptyState";
import {
  TrackingForm,
  TrackingInput,
  TrackingTextarea,
} from "@/components/progress/TrackingForm";
import type { InjuryEntry } from "@/lib/types/athlete";

interface InjuryTrackerSectionProps {
  injuries: InjuryEntry[];
  onAdd: (entry: Omit<InjuryEntry, "id">) => void;
  onRemove: (id: string) => void;
  canEdit: boolean;
}

export function InjuryTrackerSection({
  injuries,
  onAdd,
  onRemove,
  canEdit,
}: InjuryTrackerSectionProps) {
  const [showForm, setShowForm] = useState(false);
  const [date, setDate] = useState("");
  const [injury, setInjury] = useState("");
  const [painLevel, setPainLevel] = useState("5");
  const [treatment, setTreatment] = useState("");
  const [returnToPlayDate, setReturnToPlayDate] = useState("");
  const [restrictions, setRestrictions] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!date.trim() || !injury.trim()) return;
    onAdd({
      date,
      injury: injury.trim(),
      painLevel: Math.min(10, Math.max(1, Number(painLevel) || 5)),
      treatment: treatment.trim(),
      returnToPlayDate,
      restrictions: restrictions.trim(),
    });
    setDate("");
    setInjury("");
    setPainLevel("5");
    setTreatment("");
    setReturnToPlayDate("");
    setRestrictions("");
    setShowForm(false);
  }

  return (
    <section>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <p className="label-caps text-resolute-red">Injury Tracker</p>
          <p className="mt-1 text-xs text-white/40">
            Date, injury, pain level, treatment, return-to-play & restrictions
          </p>
        </div>
        {canEdit && !showForm && (
          <button type="button" onClick={() => setShowForm(true)} className="btn-ghost text-xs">
            Log Injury
          </button>
        )}
      </div>

      {injuries.length === 0 ? (
        <EmptyState
          title="No injuries logged"
          description="Track niggles and injuries so you and your coach can manage load and return-to-play."
          actionLabel={canEdit ? "Log Injury" : undefined}
          onAction={canEdit ? () => setShowForm(true) : undefined}
        />
      ) : (
        <div className="space-y-3">
          {injuries.map((entry) => (
            <div key={entry.id} className="glass rounded-xl p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="rounded-lg bg-resolute-red/10 p-2">
                    <AlertTriangle className="h-4 w-4 text-resolute-red" />
                  </div>
                  <div>
                    <p className="font-medium text-white">{entry.injury}</p>
                    <p className="text-xs text-white/40">{entry.date}</p>
                  </div>
                </div>
                {canEdit && (
                  <button
                    type="button"
                    onClick={() => onRemove(entry.id)}
                    className="rounded-lg p-2 text-white/30 hover:bg-white/5 hover:text-resolute-red"
                    aria-label="Remove injury entry"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-white/40">Pain level</p>
                  <p className="font-display text-3xl text-resolute-red">{entry.painLevel}/10</p>
                </div>
                {entry.returnToPlayDate && (
                  <div>
                    <p className="text-white/40">Return-to-play</p>
                    <p className="text-white/80">{entry.returnToPlayDate}</p>
                  </div>
                )}
              </div>
              {entry.treatment && (
                <p className="mt-3 text-sm">
                  <span className="text-white/40">Treatment: </span>
                  <span className="text-white/75">{entry.treatment}</span>
                </p>
              )}
              {entry.restrictions && (
                <p className="mt-2 text-sm">
                  <span className="text-white/40">Restrictions: </span>
                  <span className="text-white/75">{entry.restrictions}</span>
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      {canEdit && showForm && (
        <TrackingForm
          onSubmit={handleSubmit}
          onCancel={() => setShowForm(false)}
          submitLabel="Save Entry"
          className="mt-4"
        >
          <TrackingInput value={date} onChange={setDate} placeholder="Date" type="date" required />
          <TrackingInput value={injury} onChange={setInjury} placeholder="Injury" required />
          <div>
            <label className="label-caps mb-2 block">Pain level (1–10)</label>
            <input
              type="range"
              min={1}
              max={10}
              value={painLevel}
              onChange={(e) => setPainLevel(e.target.value)}
              className="w-full accent-resolute-red"
            />
            <p className="mt-1 text-center font-display text-2xl text-resolute-red">
              {painLevel}/10
            </p>
          </div>
          <TrackingInput value={treatment} onChange={setTreatment} placeholder="Treatment" />
          <TrackingInput
            value={returnToPlayDate}
            onChange={setReturnToPlayDate}
            placeholder="Return-to-play date"
            type="date"
          />
          <TrackingTextarea
            value={restrictions}
            onChange={setRestrictions}
            placeholder="Restrictions (e.g. no sprinting, limited jumps)"
          />
        </TrackingForm>
      )}
    </section>
  );
}

"use client";

import { useRef, useState } from "react";
import Image from "next/image";
import { Camera, ImageIcon, Sticker, Tag, Trash2, X } from "lucide-react";
import { EmptyState } from "@/components/ui/EmptyState";
import {
  TrackingForm,
  TrackingInput,
  TrackingSelect,
  TrackingTextarea,
} from "@/components/progress/TrackingForm";
import type { KeepsakeEntry, KeepsakeType } from "@/lib/types/athlete";
import { compressImageFile } from "@/lib/utils/compressImage";
import { cn } from "@/lib/utils";

const TYPE_OPTIONS: { value: KeepsakeType; label: string; icon: typeof Tag }[] = [
  { value: "race_bib", label: "Race Bib", icon: Tag },
  { value: "meet_sticker", label: "Meet Sticker", icon: Sticker },
  { value: "photo", label: "Photo", icon: Camera },
];

function typeLabel(type: KeepsakeType): string {
  return TYPE_OPTIONS.find((o) => o.value === type)?.label ?? "Keepsake";
}

interface KeepsakesSectionProps {
  keepsakes: KeepsakeEntry[];
  getImage: (id: string) => string | undefined;
  onAdd: (entry: Omit<KeepsakeEntry, "id">, imageData: string) => void;
  onRemove: (id: string) => void;
  canEdit: boolean;
}

export function KeepsakesSection({
  keepsakes,
  getImage,
  onAdd,
  onRemove,
  canEdit,
}: KeepsakesSectionProps) {
  const [showForm, setShowForm] = useState(false);
  const [type, setType] = useState<KeepsakeType>("race_bib");
  const [title, setTitle] = useState("");
  const [meetName, setMeetName] = useState("");
  const [date, setDate] = useState("");
  const [caption, setCaption] = useState("");
  const [preview, setPreview] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setUploadError("Please choose a photo or scan (JPEG, PNG, etc.)");
      return;
    }
    setUploadError("");
    setUploading(true);
    try {
      const compressed = await compressImageFile(file);
      setPreview(compressed);
    } catch {
      setUploadError("Could not process that image. Try another file.");
    } finally {
      setUploading(false);
    }
  }

  function resetForm() {
    setType("race_bib");
    setTitle("");
    setMeetName("");
    setDate("");
    setCaption("");
    setPreview(null);
    setUploadError("");
    if (fileRef.current) fileRef.current.value = "";
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim() || !date.trim() || !preview) {
      setUploadError(!preview ? "Attach a photo of your bib, sticker, or memory" : "");
      return;
    }
    onAdd(
      {
        type,
        title: title.trim(),
        meetName: meetName.trim() || undefined,
        date,
        caption: caption.trim() || undefined,
      },
      preview
    );
    resetForm();
    setShowForm(false);
  }

  const expanded = expandedId ? keepsakes.find((k) => k.id === expandedId) : null;
  const expandedImage = expanded ? getImage(expanded.id) : undefined;

  return (
    <section>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <p className="label-caps text-resolute-red">Meet Keepsakes</p>
          <p className="mt-1 text-xs text-white/40">
            Attach race bibs, meet stickers, or photos — your season in pictures
          </p>
        </div>
        {canEdit && !showForm && (
          <button type="button" onClick={() => setShowForm(true)} className="btn-ghost text-xs">
            Add Keepsake
          </button>
        )}
      </div>

      {keepsakes.length === 0 ? (
        <EmptyState
          title="No keepsakes yet"
          description="Snap a race bib, peel a meet sticker, or save a photo from the line — build your memory wall here."
          actionLabel={canEdit ? "Add Keepsake" : undefined}
          onAction={canEdit ? () => setShowForm(true) : undefined}
        />
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {keepsakes.map((item) => {
            const src = getImage(item.id);
            const Icon = TYPE_OPTIONS.find((o) => o.value === item.type)?.icon ?? ImageIcon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setExpandedId(item.id)}
                className="group glass overflow-hidden rounded-xl text-left transition-colors hover:bg-white/[0.04]"
              >
                <div className="relative aspect-[4/5] bg-black/40">
                  {src ? (
                    <Image
                      src={src}
                      alt={item.title}
                      fill
                      unoptimized
                      className="object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center text-white/20">
                      <ImageIcon className="h-10 w-10" />
                    </div>
                  )}
                  <span className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-black/60 px-2 py-1 text-[10px] uppercase tracking-wider text-white/80">
                    <Icon className="h-3 w-3 text-resolute-red" />
                    {typeLabel(item.type)}
                  </span>
                </div>
                <div className="p-3">
                  <p className="truncate font-medium text-sm text-white/90">{item.title}</p>
                  <p className="truncate text-[11px] text-white/35">
                    {item.meetName ? `${item.meetName} · ` : ""}
                    {item.date}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {canEdit && showForm && (
        <TrackingForm
          onSubmit={handleSubmit}
          onCancel={() => {
            resetForm();
            setShowForm(false);
          }}
          submitLabel={uploading ? "Processing…" : "Save Keepsake"}
          className="mt-4"
        >
          <TrackingSelect
            value={type}
            onChange={(v) => setType(v as KeepsakeType)}
            options={TYPE_OPTIONS.map((o) => ({ value: o.value, label: o.label }))}
          />
          <TrackingInput value={title} onChange={setTitle} placeholder="Title (e.g. State Finals Bib)" required />
          <TrackingInput value={meetName} onChange={setMeetName} placeholder="Meet name (optional)" />
          <TrackingInput value={date} onChange={setDate} placeholder="Date" type="date" required />
          <TrackingTextarea value={caption} onChange={setCaption} placeholder="Caption or memory (optional)" />

          <div>
            <p className="label-caps mb-2">Photo</p>
            <label
              className={cn(
                "flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-white/15 bg-white/[0.02] px-4 py-8 transition-colors hover:border-resolute-red/40",
                preview && "border-solid border-white/10 p-2"
              )}
            >
              {preview ? (
                <div className="relative aspect-[4/3] w-full overflow-hidden rounded-lg">
                  <Image src={preview} alt="Preview" fill unoptimized className="object-cover" />
                </div>
              ) : (
                <>
                  <Camera className="mb-2 h-8 w-8 text-resolute-red/70" />
                  <p className="text-sm text-white/50">Tap to attach bib, sticker, or photo</p>
                  <p className="mt-1 text-[11px] text-white/30">Saved on this device only</p>
                </>
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="sr-only"
                onChange={handleFileChange}
              />
            </label>
            {preview && (
              <button
                type="button"
                onClick={() => {
                  setPreview(null);
                  if (fileRef.current) fileRef.current.value = "";
                }}
                className="btn-ghost mt-2 w-full text-xs"
              >
                Choose different photo
              </button>
            )}
          </div>

          {uploadError && <p className="text-sm text-resolute-red/90">{uploadError}</p>}
        </TrackingForm>
      )}

      {expanded && expandedImage && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setExpandedId(null)}
        >
          <div
            className="relative max-h-[90vh] w-full max-w-md overflow-hidden rounded-2xl border border-white/10 bg-[#0a0a0a]"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setExpandedId(null)}
              className="absolute right-3 top-3 z-10 rounded-full bg-black/60 p-2 text-white/70 hover:text-white"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
            {canEdit && (
              <button
                type="button"
                onClick={() => {
                  onRemove(expanded.id);
                  setExpandedId(null);
                }}
                className="absolute left-3 top-3 z-10 rounded-full bg-black/60 p-2 text-white/70 hover:text-resolute-red"
                aria-label="Delete keepsake"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            )}
            <div className="relative aspect-[3/4] w-full bg-black">
              <Image
                src={expandedImage}
                alt={expanded.title}
                fill
                unoptimized
                className="object-contain"
              />
            </div>
            <div className="p-5">
              <p className="label-caps text-resolute-red">{typeLabel(expanded.type)}</p>
              <p className="headline mt-1 text-2xl text-white">{expanded.title}</p>
              {(expanded.meetName || expanded.date) && (
                <p className="mt-1 text-sm text-white/40">
                  {[expanded.meetName, expanded.date].filter(Boolean).join(" · ")}
                </p>
              )}
              {expanded.caption && (
                <p className="mt-3 text-sm leading-relaxed text-white/60">{expanded.caption}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

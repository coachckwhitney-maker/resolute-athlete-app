import { TrendingUp, Trophy } from "lucide-react";
import type { PersonalRecord } from "@/lib/types/athlete";

interface PRListProps {
  records: PersonalRecord[];
}

export function PRList({ records }: PRListProps) {
  return (
    <section>
      <div className="mb-5 flex items-center gap-2">
        <Trophy className="h-5 w-5 text-resolute-red" />
        <p className="label-caps">Personal Records</p>
      </div>

      <div className="space-y-2">
        {records.map((pr, i) => (
          <div
            key={pr.id}
            className={`animate-fade-up animate-stagger stagger-${Math.min(i + 1, 8)} glass rounded-xl card-interactive flex items-center justify-between px-5 py-4`}
          >
            <div>
              <p className="font-medium uppercase tracking-wider text-white/80">
                {pr.event}
              </p>
              <p className="text-xs text-white/30">{pr.date}</p>
            </div>
            <div className="text-right">
              <p className="font-display text-4xl text-resolute-red">{pr.value}</p>
              {pr.previous && (
                <p className="flex items-center justify-end gap-1 text-xs text-resolute-red/70">
                  <TrendingUp className="h-3 w-3" />
                  from {pr.previous}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

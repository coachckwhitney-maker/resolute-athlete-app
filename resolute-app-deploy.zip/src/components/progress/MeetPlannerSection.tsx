"use client";

import { useState } from "react";
import { Calendar, MapPin, Trash2 } from "lucide-react";
import { EmptyState } from "@/components/ui/EmptyState";
import {
  TrackingForm,
  TrackingInput,
  TrackingTextarea,
} from "@/components/progress/TrackingForm";
import type { MeetPlan } from "@/lib/types/athlete";

interface MeetPlannerSectionProps {
  plans: MeetPlan[];
  onAdd: (plan: Omit<MeetPlan, "id">) => void;
  onRemove: (id: string) => void;
  canEdit: boolean;
}

export function MeetPlannerSection({ plans, onAdd, onRemove, canEdit }: MeetPlannerSectionProps) {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [date, setDate] = useState("");
  const [location, setLocation] = useState("");
  const [events, setEvents] = useState("");
  const [goals, setGoals] = useState("");
  const [notes, setNotes] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !date.trim() || !events.trim()) return;
    onAdd({
      name: name.trim(),
      date,
      location: location.trim() || undefined,
      events: events.trim(),
      goals: goals.trim() || undefined,
      notes: notes.trim() || undefined,
    });
    setName("");
    setDate("");
    setLocation("");
    setEvents("");
    setGoals("");
    setNotes("");
    setShowForm(false);
  }

  return (
    <section>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <p className="label-caps text-resolute-red">Meet Planner</p>
          <p className="mt-1 text-xs text-white/40">Plan upcoming meets, events & goals</p>
        </div>
        {canEdit && !showForm && (
          <button type="button" onClick={() => setShowForm(true)} className="btn-ghost text-xs">
            Add Meet
          </button>
        )}
      </div>

      {plans.length === 0 ? (
        <EmptyState
          title="No meets planned"
          description="Add your next meet — events, goals, and notes you want to hit."
          actionLabel={canEdit ? "Plan a Meet" : undefined}
          onAction={canEdit ? () => setShowForm(true) : undefined}
        />
      ) : (
        <div className="space-y-3">
          {plans.map((plan) => (
            <div key={plan.id} className="glass rounded-xl p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="headline text-2xl text-white">{plan.name}</p>
                  <p className="mt-1 flex items-center gap-1.5 text-xs text-white/40">
                    <Calendar className="h-3.5 w-3.5" />
                    {plan.date}
                  </p>
                  {plan.location && (
                    <p className="mt-1 flex items-center gap-1.5 text-xs text-white/40">
                      <MapPin className="h-3.5 w-3.5" />
                      {plan.location}
                    </p>
                  )}
                </div>
                {canEdit && (
                  <button
                    type="button"
                    onClick={() => onRemove(plan.id)}
                    className="rounded-lg p-2 text-white/30 hover:bg-white/5 hover:text-resolute-red"
                    aria-label="Remove meet"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
              <div className="mt-4 space-y-2 text-sm">
                <p>
                  <span className="text-white/40">Events: </span>
                  <span className="text-white/80">{plan.events}</span>
                </p>
                {plan.goals && (
                  <p>
                    <span className="text-white/40">Goals: </span>
                    <span className="text-white/80">{plan.goals}</span>
                  </p>
                )}
                {plan.notes && (
                  <p className="text-white/50">{plan.notes}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {canEdit && showForm && (
        <TrackingForm
          onSubmit={handleSubmit}
          onCancel={() => setShowForm(false)}
          submitLabel="Save Meet"
          className="mt-4"
        >
          <TrackingInput value={name} onChange={setName} placeholder="Meet name" required />
          <TrackingInput value={date} onChange={setDate} placeholder="Date" type="date" required />
          <TrackingInput value={location} onChange={setLocation} placeholder="Location (optional)" />
          <TrackingInput value={events} onChange={setEvents} placeholder="Events (e.g. 100m, LJ, 4x100)" required />
          <TrackingInput value={goals} onChange={setGoals} placeholder="Goals (optional)" />
          <TrackingTextarea value={notes} onChange={setNotes} placeholder="Notes (optional)" />
        </TrackingForm>
      )}
    </section>
  );
}

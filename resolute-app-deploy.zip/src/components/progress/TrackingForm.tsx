"use client";

import { cn } from "@/lib/utils";

const inputClass =
  "w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-white/30 focus:border-resolute-red focus:outline-none";

interface TrackingFormProps {
  onSubmit: (e: React.FormEvent) => void;
  onCancel: () => void;
  submitLabel?: string;
  children: React.ReactNode;
  className?: string;
}

export function TrackingForm({
  onSubmit,
  onCancel,
  submitLabel = "Save",
  children,
  className,
}: TrackingFormProps) {
  return (
    <form
      onSubmit={onSubmit}
      className={cn(
        "space-y-3 rounded-xl border border-white/10 bg-white/[0.02] p-4",
        className
      )}
    >
      {children}
      <div className="flex gap-2">
        <button type="submit" className="btn-red flex-1">
          {submitLabel}
        </button>
        <button type="button" onClick={onCancel} className="btn-ghost flex-1">
          Cancel
        </button>
      </div>
    </form>
  );
}

export function TrackingInput({
  value,
  onChange,
  placeholder,
  type = "text",
  required,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      type={type}
      required={required}
      className={inputClass}
    />
  );
}

export function TrackingTextarea({
  value,
  onChange,
  placeholder,
  rows = 2,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  rows?: number;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
      className={cn(inputClass, "resize-none")}
    />
  );
}

export function TrackingSelect({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={inputClass}
    >
      {options.map((opt) => (
        <option key={opt.value} value={opt.value} className="bg-black">
          {opt.label}
        </option>
      ))}
    </select>
  );
}

"use client";

import { AnimatedBar } from "@/components/ui/AnimatedBar";
import type { TrendPoint } from "@/lib/utils/progressTrends";
import { maxTrendValue } from "@/lib/utils/progressTrends";

interface TrendChartProps {
  title: string;
  subtitle?: string;
  points: TrendPoint[];
  unit?: string;
  emptyMessage?: string;
}

export function TrendChart({
  title,
  subtitle,
  points,
  unit = "",
  emptyMessage = "Log entries to see your trend",
}: TrendChartProps) {
  const max = maxTrendValue(points);

  return (
    <section className="glass rounded-xl p-5">
      <div className="mb-4">
        <p className="label-caps text-resolute-red">{title}</p>
        {subtitle && <p className="mt-1 text-xs text-white/40">{subtitle}</p>}
      </div>

      {points.length === 0 ? (
        <p className="text-sm text-white/35">{emptyMessage}</p>
      ) : (
        <div className="space-y-3">
          {points.map((point, i) => (
            <div key={`${point.date}-${point.label}`}>
              <div className="mb-1 flex items-baseline justify-between text-xs">
                <span className="text-white/50">{point.label}</span>
                <span className="font-medium text-white/80">
                  {point.value}
                  {unit && <span className="text-white/35"> {unit}</span>}
                </span>
              </div>
              <AnimatedBar
                value={Math.round((point.value / max) * 100)}
                delay={i * 60}
                className="rounded-full"
              />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

import type { WellnessMetric } from "@/lib/types/athlete";

interface WellnessGridProps {
  metrics: WellnessMetric[];
}

export function WellnessGrid({ metrics }: WellnessGridProps) {
  return (
    <section className="mt-10">
      <p className="label-caps mb-4">Wellness Today</p>
      <div className="grid grid-cols-2 gap-3">
        {metrics.map((metric, i) => (
          <div
            key={metric.id}
            className={`animate-fade-up animate-stagger stagger-${Math.min(i + 1, 8)} glass rounded-xl p-5 transition-all duration-500 hover:bg-white/[0.04]`}
          >
            <p className="label-caps">{metric.label}</p>
            <p className="mt-2 font-display text-5xl leading-none text-white">
              {metric.value}
              <span className="ml-1 font-sans text-sm font-normal text-white/30">
                {metric.unit}
              </span>
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}

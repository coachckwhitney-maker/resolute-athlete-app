"use client";

import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AppShell } from "@/components/layout/AppShell";
import { PRList } from "@/components/progress/PRList";
import { WellnessGrid } from "@/components/progress/WellnessGrid";
import { MeetPlannerSection } from "@/components/progress/MeetPlannerSection";
import { InjuryTrackerSection } from "@/components/progress/InjuryTrackerSection";
import { ProgressTrendsSection } from "@/components/progress/ProgressTrendsSection";
import { KeepsakesSection } from "@/components/progress/KeepsakesSection";
import { EmptyState } from "@/components/ui/EmptyState";
import {
  TrackingForm,
  TrackingInput,
} from "@/components/progress/TrackingForm";
import { useAthleteData } from "@/context/AthleteDataProvider";
import { cn } from "@/lib/utils";

type ProgressTab = "overview" | "meets" | "injuries" | "trends" | "keepsakes";

const BASE_TABS: { id: ProgressTab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "meets", label: "Meets" },
  { id: "injuries", label: "Injuries" },
  { id: "trends", label: "Trends" },
];

export function ProgressClient() {
  const searchParams = useSearchParams();
  const {
    personalRecords,
    wellnessMetrics,
    meetPlans,
    injuries,
    trainingLogs,
    competitionResults,
    attendance,
    keepsakes,
    canSelfTrack,
    canManageKeepsakes,
    getKeepsakeImage,
    addPersonalRecord,
    addWellnessMetric,
    addMeetPlan,
    removeMeetPlan,
    addInjury,
    removeInjury,
    addTrainingLog,
    addCompetitionResult,
    removeCompetitionResult,
    addAttendance,
    addKeepsake,
    removeKeepsake,
  } = useAthleteData();

  const tabs = useMemo(
    () =>
      canManageKeepsakes
        ? [...BASE_TABS, { id: "keepsakes" as const, label: "Keepsakes" }]
        : BASE_TABS,
    [canManageKeepsakes]
  );

  const [tab, setTab] = useState<ProgressTab>("overview");
  const [showAddPr, setShowAddPr] = useState(false);
  const [showAddWellness, setShowAddWellness] = useState(false);
  const [prEvent, setPrEvent] = useState("");
  const [prValue, setPrValue] = useState("");
  const [wellnessLabel, setWellnessLabel] = useState("");
  const [wellnessValue, setWellnessValue] = useState("");
  const [wellnessUnit, setWellnessUnit] = useState("");

  useEffect(() => {
    const requested = searchParams.get("tab");
    if (requested === "keepsakes" && canManageKeepsakes) {
      setTab("keepsakes");
    } else if (
      requested === "meets" ||
      requested === "injuries" ||
      requested === "trends" ||
      requested === "overview"
    ) {
      setTab(requested);
    }
  }, [searchParams, canManageKeepsakes]);

  const today = new Date().toISOString().slice(0, 10);

  function handleAddPr(e: React.FormEvent) {
    e.preventDefault();
    if (!prEvent.trim() || !prValue.trim()) return;
    addPersonalRecord({
      event: prEvent.trim(),
      value: prValue.trim(),
      date: today,
    });
    setPrEvent("");
    setPrValue("");
    setShowAddPr(false);
  }

  function handleAddWellness(e: React.FormEvent) {
    e.preventDefault();
    if (!wellnessLabel.trim() || !wellnessValue.trim()) return;
    addWellnessMetric({
      label: wellnessLabel.trim(),
      value: Number(wellnessValue),
      unit: wellnessUnit.trim() || "",
      date: today,
    });
    setWellnessLabel("");
    setWellnessValue("");
    setWellnessUnit("");
    setShowAddWellness(false);
  }

  return (
    <AppShell>
      <header className="animate-fade-up mb-6">
        <p className="label-caps">Track Everything</p>
        <h1 className="headline text-5xl">
          Your
          <br />
          <span className="text-gradient-red">Progress</span>
        </h1>
        <p className="mt-2 text-sm text-white/40">
          Log meets, injuries, PRs, volume, wellness
          {canManageKeepsakes ? " & keepsakes" : ""} — see it all visually
        </p>
      </header>

      <nav className="mb-8 flex gap-2 overflow-x-auto pb-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "shrink-0 rounded-full px-4 py-2 text-xs font-medium uppercase tracking-wider transition-colors",
              tab === t.id
                ? "bg-resolute-red text-white"
                : "bg-white/5 text-white/50 hover:bg-white/10"
            )}
          >
            {t.label}
          </button>
        ))}
      </nav>

      {tab === "overview" && (
        <>
          <div className="mb-8 grid grid-cols-2 gap-3">
            {[
              { label: "Meets", count: meetPlans.length, target: "meets" as ProgressTab },
              { label: "Injuries", count: injuries.length, target: "injuries" as ProgressTab },
              { label: "PRs", count: personalRecords.length, target: "overview" as ProgressTab },
              { label: "Comp Results", count: competitionResults.length, target: "trends" as ProgressTab },
              ...(canManageKeepsakes
                ? [{ label: "Keepsakes", count: keepsakes.length, target: "keepsakes" as ProgressTab }]
                : []),
            ].map((card) => (
              <button
                key={card.label}
                type="button"
                onClick={() => setTab(card.target)}
                className="glass rounded-xl p-4 text-left transition-colors hover:bg-white/[0.04]"
              >
                <p className="label-caps text-white/40">{card.label}</p>
                <p className="mt-1 font-display text-4xl text-resolute-red">{card.count}</p>
              </button>
            ))}
          </div>

          {personalRecords.length === 0 ? (
            <EmptyState
              title="No PRs yet"
              description="Add personal records as you hit them — times, lifts, jumps, whatever you track."
              actionLabel={canSelfTrack ? "Add PR" : undefined}
              onAction={canSelfTrack ? () => setShowAddPr(true) : undefined}
            />
          ) : (
            <PRList records={personalRecords} />
          )}

          {canSelfTrack && showAddPr && (
            <TrackingForm onSubmit={handleAddPr} onCancel={() => setShowAddPr(false)} className="mt-4">
              <TrackingInput value={prEvent} onChange={setPrEvent} placeholder="Event (e.g. 100m)" />
              <TrackingInput value={prValue} onChange={setPrValue} placeholder="Result (e.g. 11.34)" />
            </TrackingForm>
          )}

          {canSelfTrack && personalRecords.length > 0 && !showAddPr && (
            <button type="button" onClick={() => setShowAddPr(true)} className="btn-ghost mt-4 w-full">
              Add PR
            </button>
          )}

          {wellnessMetrics.length === 0 ? (
            <EmptyState
              className="mt-10"
              title="No wellness logged"
              description="Track sleep, soreness, energy, weight — whatever helps you train smarter."
              actionLabel={canSelfTrack ? "Log Wellness" : undefined}
              onAction={canSelfTrack ? () => setShowAddWellness(true) : undefined}
            />
          ) : (
            <WellnessGrid metrics={wellnessMetrics} />
          )}

          {canSelfTrack && showAddWellness && (
            <TrackingForm onSubmit={handleAddWellness} onCancel={() => setShowAddWellness(false)} className="mt-4">
              <TrackingInput value={wellnessLabel} onChange={setWellnessLabel} placeholder="Metric (e.g. Sleep)" />
              <TrackingInput value={wellnessValue} onChange={setWellnessValue} placeholder="Value" type="number" />
              <TrackingInput value={wellnessUnit} onChange={setWellnessUnit} placeholder="Unit (e.g. hrs, /10)" />
            </TrackingForm>
          )}

          {canSelfTrack && wellnessMetrics.length > 0 && !showAddWellness && (
            <button type="button" onClick={() => setShowAddWellness(true)} className="btn-ghost mt-4 w-full">
              Log Wellness
            </button>
          )}

          <button type="button" onClick={() => setTab("trends")} className="btn-red mt-8 w-full">
            View All Trends
          </button>
        </>
      )}

      {tab === "meets" && (
        <MeetPlannerSection
          plans={meetPlans}
          onAdd={addMeetPlan}
          onRemove={removeMeetPlan}
          canEdit={canSelfTrack}
        />
      )}

      {tab === "injuries" && (
        <InjuryTrackerSection
          injuries={injuries}
          onAdd={addInjury}
          onRemove={removeInjury}
          canEdit={canSelfTrack}
        />
      )}

      {tab === "trends" && (
        <ProgressTrendsSection
          personalRecords={personalRecords}
          wellnessMetrics={wellnessMetrics}
          trainingLogs={trainingLogs}
          competitionResults={competitionResults}
          attendance={attendance}
          canEdit={canSelfTrack}
          onAddTrainingLog={addTrainingLog}
          onAddCompetitionResult={addCompetitionResult}
          onAddAttendance={addAttendance}
          onRemoveCompetitionResult={removeCompetitionResult}
        />
      )}

      {tab === "keepsakes" && canManageKeepsakes && (
        <KeepsakesSection
          keepsakes={keepsakes}
          getImage={getKeepsakeImage}
          onAdd={addKeepsake}
          onRemove={removeKeepsake}
          canEdit={canManageKeepsakes}
        />
      )}
    </AppShell>
  );
}

"use client";

interface SessionProgressBarProps {
  progress: number;
}

export function SessionProgressBar({ progress }: SessionProgressBarProps) {
  return (
    <div className="fixed left-0 right-0 top-0 z-[60] h-[3px] bg-white/5">
      <div
        className="session-progress h-full bg-gradient-to-r from-resolute-red via-[#FF2D4A] to-resolute-red shadow-[0_0_12px_rgba(227,24,55,0.8)]"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}

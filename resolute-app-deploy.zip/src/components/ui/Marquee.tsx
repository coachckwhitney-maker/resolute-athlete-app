"use client";

import { useCoachVoice } from "@/context/AppTierProvider";

export function Marquee() {
  const voice = useCoachVoice();
  const doubled = [...voice.marqueeItems, ...voice.marqueeItems];

  return (
    <div className="relative overflow-hidden border-y border-white/[0.06] bg-white/[0.02] py-3 backdrop-blur-sm">
      <div className="animate-marquee flex w-max gap-10 whitespace-nowrap">
        {doubled.map((item, i) => (
          <span
            key={`${item}-${i}`}
            className="font-accent text-xs font-bold uppercase tracking-[0.3em] text-white/30"
          >
            {item}
            <span className="mx-10 text-resolute-red">◆</span>
          </span>
        ))}
      </div>
    </div>
  );
}

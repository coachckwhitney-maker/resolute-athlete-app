"use client";

import { motion } from "framer-motion";

interface AnimatedHeadlineProps {
  lines: string[];
  className?: string;
  highlightLast?: boolean;
}

export function AnimatedHeadline({
  lines,
  className = "",
  highlightLast = true,
}: AnimatedHeadlineProps) {
  return (
    <div className={className}>
      {lines.map((line, lineIndex) => {
        const isLast = lineIndex === lines.length - 1;
        const isMiddle = lineIndex === 1 && lines.length === 3;

        return (
          <motion.h1
            key={line}
            initial={false}
            animate={{ opacity: 1, y: 0, rotateX: 0 }}
            transition={{
              duration: 0.8,
              delay: lineIndex * 0.15,
              ease: [0.16, 1, 0.3, 1],
            }}
            className={`headline block text-[clamp(3.5rem,17vw,6rem)] ${
              isLast && highlightLast
                ? "text-gradient-red"
                : isMiddle
                  ? "text-outline"
                  : "text-white"
            } ${lineIndex > 0 ? "-mt-1 sm:-mt-2" : ""}`}
          >
            {line}
          </motion.h1>
        );
      })}
    </div>
  );
}

interface FadeUpProps {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}

export function FadeUp({ children, delay = 0, className = "" }: FadeUpProps) {
  return (
    <motion.div
      initial={false}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

interface ScaleInProps {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}

export function ScaleIn({ children, delay = 0, className = "" }: ScaleInProps) {
  return (
    <motion.div
      initial={false}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, delay, ease: [0.34, 1.56, 0.64, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

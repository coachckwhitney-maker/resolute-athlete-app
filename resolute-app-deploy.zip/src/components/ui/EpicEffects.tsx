export function SpeedLines() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-[0.07]" aria-hidden>
      {Array.from({ length: 12 }).map((_, i) => (
        <div
          key={i}
          className="absolute h-px animate-speed-line bg-gradient-to-r from-transparent via-resolute-red to-transparent"
          style={{
            top: `${8 + i * 8}%`,
            left: "-100%",
            width: "200%",
            animationDelay: `${i * 0.4}s`,
            transform: `rotate(-12deg) translateY(${i * 12}px)`,
          }}
        />
      ))}
    </div>
  );
}

export function DiagonalSlash() {
  return (
    <div
      className="pointer-events-none absolute -right-1/4 top-0 h-full w-1/2 skew-x-[-12deg] bg-gradient-to-b from-resolute-red/20 via-resolute-red/5 to-transparent"
      aria-hidden
    />
  );
}

export function ScanLine() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <div className="pointer-events-none absolute left-0 h-px w-full animate-scan bg-gradient-to-r from-transparent via-resolute-red/60 to-transparent" />
    </div>
  );
}

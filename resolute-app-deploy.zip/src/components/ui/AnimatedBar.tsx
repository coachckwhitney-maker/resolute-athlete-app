"use client";

import { cn } from "@/lib/utils";

interface AnimatedBarProps {
  value: number;
  className?: string;
  barClassName?: string;
  delay?: number;
}

export function AnimatedBar({
  value,
  className,
  barClassName,
  delay = 0,
}: AnimatedBarProps) {
  return (
    <div className={cn("h-1 overflow-hidden bg-white/10", className)}>
      <div
        className={cn("h-full bg-resolute-red progress-bar-animated", barClassName)}
        style={
          {
            "--bar-width": `${value}%`,
            animationDelay: `${delay}ms`,
          } as React.CSSProperties
        }
      />
    </div>
  );
}

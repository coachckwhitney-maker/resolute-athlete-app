"use client";

import { AppTierProvider } from "@/context/AppTierProvider";
import { AthleteDataProvider } from "@/context/AthleteDataProvider";

export function AppProviders({ children }: { children: React.ReactNode }) {
  return (
    <AppTierProvider>
      <AthleteDataProvider>{children}</AthleteDataProvider>
    </AppTierProvider>
  );
}

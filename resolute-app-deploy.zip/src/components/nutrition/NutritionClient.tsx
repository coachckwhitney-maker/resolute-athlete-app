"use client";

import { useEffect, useMemo, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { TrackingInput, TrackingTextarea } from "@/components/progress/TrackingForm";
import { FeaturePaywall } from "@/components/upgrade/FeaturePaywall";
import { useAthleteData } from "@/context/AthleteDataProvider";
import type { NutritionLogEntry } from "@/lib/types/athlete";
import {
  Apple,
  Droplets,
  Drumstick,
  Leaf,
  Minus,
  Plus,
  Salad,
  Trash2,
  UtensilsCrossed,
} from "lucide-react";
import { cn } from "@/lib/utils";

const EMPTY_LOG = {
  waterGlasses: 0,
  proteinServings: 0,
  fruitServings: 0,
  vegetableServings: 0,
  preWorkoutMeal: "",
  postWorkoutMeal: "",
  calories: undefined as number | undefined,
};

function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

function formatDateLabel(date: string): string {
  const d = new Date(date + "T12:00:00");
  const today = todayKey();
  if (date === today) return "Today";
  return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

interface CounterFieldProps {
  label: string;
  hint: string;
  icon: typeof Droplets;
  value: number;
  onChange: (value: number) => void;
  unit: string;
}

function CounterField({ label, hint, icon: Icon, value, onChange, unit }: CounterFieldProps) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="mb-3 flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-resolute-red/15">
          <Icon className="h-4 w-4 text-resolute-red" />
        </div>
        <div>
          <p className="font-medium text-white/90">{label}</p>
          <p className="text-xs text-white/35">{hint}</p>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={() => onChange(Math.max(0, value - 1))}
          className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-white/60 hover:bg-white/10"
          aria-label={`Decrease ${label}`}
        >
          <Minus className="h-4 w-4" />
        </button>
        <div className="text-center">
          <p className="font-display text-4xl text-white">{value}</p>
          <p className="text-[10px] uppercase tracking-wider text-white/30">{unit}</p>
        </div>
        <button
          type="button"
          onClick={() => onChange(value + 1)}
          className="flex h-10 w-10 items-center justify-center rounded-xl bg-resolute-red/20 text-resolute-red hover:bg-resolute-red/30"
          aria-label={`Increase ${label}`}
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

export function NutritionClient() {
  const { nutritionLogs, canManageNutrition, saveNutritionLog, removeNutritionLog } =
    useAthleteData();

  const today = todayKey();
  const todayLog = nutritionLogs.find((entry) => entry.date === today);

  const [draft, setDraft] = useState(EMPTY_LOG);
  const [showCalories, setShowCalories] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (todayLog) {
      setDraft({
        waterGlasses: todayLog.waterGlasses,
        proteinServings: todayLog.proteinServings,
        fruitServings: todayLog.fruitServings,
        vegetableServings: todayLog.vegetableServings,
        preWorkoutMeal: todayLog.preWorkoutMeal,
        postWorkoutMeal: todayLog.postWorkoutMeal,
        calories: todayLog.calories,
      });
      setShowCalories(todayLog.calories != null);
    } else {
      setDraft(EMPTY_LOG);
      setShowCalories(false);
    }
  }, [todayLog]);

  const recentLogs = useMemo(
    () =>
      nutritionLogs
        .filter((entry) => entry.date !== today)
        .sort((a, b) => b.date.localeCompare(a.date))
        .slice(0, 7),
    [nutritionLogs, today]
  );

  const completionScore = useMemo(() => {
    let filled = 0;
    if (draft.waterGlasses > 0) filled += 1;
    if (draft.proteinServings > 0) filled += 1;
    if (draft.fruitServings > 0) filled += 1;
    if (draft.vegetableServings > 0) filled += 1;
    if (draft.preWorkoutMeal.trim()) filled += 1;
    if (draft.postWorkoutMeal.trim()) filled += 1;
    return filled;
  }, [draft]);

  if (!canManageNutrition) {
    return (
      <FeaturePaywall
        feature="Daily Nutrition"
        description="Track water, protein, fruits, vegetables, and pre/post-workout meals. Daily nutrition tracking is included with Resolute and coached athletes."
      />
    );
  }

  function handleSave() {
    saveNutritionLog({
      id: todayLog?.id,
      date: today,
      waterGlasses: draft.waterGlasses,
      proteinServings: draft.proteinServings,
      fruitServings: draft.fruitServings,
      vegetableServings: draft.vegetableServings,
      preWorkoutMeal: draft.preWorkoutMeal.trim(),
      postWorkoutMeal: draft.postWorkoutMeal.trim(),
      calories: showCalories && draft.calories != null ? draft.calories : undefined,
    });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2000);
  }

  return (
    <AppShell>
      <header className="animate-fade-up mb-8">
        <p className="label-caps text-resolute-red">Fuel Your Training</p>
        <h1 className="headline text-5xl">
          Daily
          <br />
          <span className="text-gradient-red">Nutrition</span>
        </h1>
        <p className="mt-2 text-sm text-white/40">
          Simple daily check-in — no calorie counting required unless you want it.
        </p>
      </header>

      <section className="mb-8">
        <div className="mb-4 flex items-end justify-between">
          <div>
            <p className="label-caps">Today</p>
            <p className="text-xs text-white/35">{formatDateLabel(today)}</p>
          </div>
          <p className="text-xs text-white/35">{completionScore}/6 logged</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <CounterField
            label="Water intake"
            hint="Glasses through the day"
            icon={Droplets}
            value={draft.waterGlasses}
            onChange={(v) => setDraft((prev) => ({ ...prev, waterGlasses: v }))}
            unit="glasses"
          />
          <CounterField
            label="Protein"
            hint="Servings — meat, eggs, shakes"
            icon={Drumstick}
            value={draft.proteinServings}
            onChange={(v) => setDraft((prev) => ({ ...prev, proteinServings: v }))}
            unit="servings"
          />
          <CounterField
            label="Fruits"
            hint="Pieces or servings"
            icon={Apple}
            value={draft.fruitServings}
            onChange={(v) => setDraft((prev) => ({ ...prev, fruitServings: v }))}
            unit="servings"
          />
          <CounterField
            label="Vegetables"
            hint="Servings with meals"
            icon={Leaf}
            value={draft.vegetableServings}
            onChange={(v) => setDraft((prev) => ({ ...prev, vegetableServings: v }))}
            unit="servings"
          />
        </div>

        <div className="mt-3 space-y-3">
          <div className="glass rounded-xl p-4">
            <div className="mb-3 flex items-center gap-2">
              <UtensilsCrossed className="h-4 w-4 text-resolute-red" />
              <p className="font-medium text-white/90">Pre-workout meal</p>
            </div>
            <TrackingTextarea
              value={draft.preWorkoutMeal}
              onChange={(v) => setDraft((prev) => ({ ...prev, preWorkoutMeal: v }))}
              placeholder="What you ate before practice (optional)"
              rows={2}
            />
          </div>

          <div className="glass rounded-xl p-4">
            <div className="mb-3 flex items-center gap-2">
              <Salad className="h-4 w-4 text-resolute-red" />
              <p className="font-medium text-white/90">Post-workout meal</p>
            </div>
            <TrackingTextarea
              value={draft.postWorkoutMeal}
              onChange={(v) => setDraft((prev) => ({ ...prev, postWorkoutMeal: v }))}
              placeholder="Recovery fuel after session (optional)"
              rows={2}
            />
          </div>
        </div>

        <div className="mt-4">
          <button
            type="button"
            onClick={() => setShowCalories((prev) => !prev)}
            className="text-xs uppercase tracking-wider text-white/40 hover:text-white/70"
          >
            {showCalories ? "− Hide optional calories" : "+ Track calories (optional)"}
          </button>
          {showCalories && (
            <div className="mt-3">
              <TrackingInput
                value={draft.calories != null ? String(draft.calories) : ""}
                onChange={(v) =>
                  setDraft((prev) => ({
                    ...prev,
                    calories: v.trim() ? Number(v) : undefined,
                  }))
                }
                placeholder="Total calories (optional)"
                type="number"
              />
            </div>
          )}
        </div>

        <button type="button" onClick={handleSave} className="btn-red mt-5 w-full">
          {saved ? "Saved ✓" : todayLog ? "Update Today" : "Save Today"}
        </button>
      </section>

      {recentLogs.length > 0 && (
        <section>
          <p className="label-caps mb-4">Recent Days</p>
          <div className="space-y-3">
            {recentLogs.map((entry) => (
              <NutritionDayCard
                key={entry.id}
                entry={entry}
                onRemove={() => removeNutritionLog(entry.id)}
              />
            ))}
          </div>
        </section>
      )}
    </AppShell>
  );
}

function NutritionDayCard({
  entry,
  onRemove,
}: {
  entry: NutritionLogEntry;
  onRemove: () => void;
}) {
  return (
    <article className="glass rounded-xl p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="font-medium text-white/85">{formatDateLabel(entry.date)}</p>
        <button
          type="button"
          onClick={onRemove}
          className="rounded-lg p-1.5 text-white/30 hover:text-resolute-red"
          aria-label="Delete nutrition log"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs text-white/50">
        <span>💧 {entry.waterGlasses} glasses</span>
        <span>🥩 {entry.proteinServings} protein</span>
        <span>🍎 {entry.fruitServings} fruit</span>
        <span>🥬 {entry.vegetableServings} veg</span>
      </div>
      {(entry.preWorkoutMeal || entry.postWorkoutMeal) && (
        <div className="mt-3 space-y-1 text-xs text-white/40">
          {entry.preWorkoutMeal && <p>Pre: {entry.preWorkoutMeal}</p>}
          {entry.postWorkoutMeal && <p>Post: {entry.postWorkoutMeal}</p>}
        </div>
      )}
      {entry.calories != null && (
        <p className={cn("mt-2 text-xs text-white/30")}>{entry.calories} cal (optional)</p>
      )}
    </article>
  );
}

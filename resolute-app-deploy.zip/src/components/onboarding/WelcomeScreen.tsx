"use client";

import { useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, ClipboardList, Crown, Sparkles, Users, Zap } from "lucide-react";
import { useAppTier } from "@/context/AppTierProvider";
import { tierLabels } from "@/lib/config/tier";
import { ResoluteLogo } from "@/components/brand/ResoluteLogo";
import { PodcastButton } from "@/components/brand/PodcastButton";
import { CoachDevelopmentLink } from "@/components/coaches/CoachDevelopmentLink";
import { Marquee } from "@/components/ui/Marquee";
import { AnimatedHeadline, FadeUp } from "@/components/ui/Motion";
import { DiagonalSlash, ScanLine, SpeedLines } from "@/components/ui/EpicEffects";

const teamChoice = {
  accent: "from-resolute-red/30 to-transparent",
  label: tierLabels.team,
};

export function WelcomeScreen() {
  const { unlockTeamWithCode } = useAppTier();
  const [code, setCode] = useState("");
  const [codeError, setCodeError] = useState(false);
  const [showCode, setShowCode] = useState(false);

  function handleTeamSubmit(e: React.FormEvent) {
    e.preventDefault();
    const ok = unlockTeamWithCode(code);
    if (!ok) {
      setCodeError(true);
      return;
    }
    setCodeError(false);
    window.location.assign("/dashboard?tier=team");
  }

  return (
    <div className="relative min-h-screen overflow-x-hidden epic-hero-bg">
      <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden" aria-hidden>
        <SpeedLines />
        <DiagonalSlash />
        <ScanLine />
        <motion.div
          initial={false}
          animate={{ opacity: 0.05, scale: 1 }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
          className="absolute -left-8 top-32 select-none"
        >
          <p className="headline text-[6rem] leading-none text-white">Resolute</p>
        </motion.div>
        <div className="logo-watermark -right-24 top-16 rotate-[12deg] opacity-[0.09]">
          <Image
            src="/logos/resolute-logo-stripe.png"
            alt=""
            width={360}
            height={360}
            priority
            className="h-[28rem] w-[28rem] object-contain"
          />
        </div>
      </div>

      <main className="relative z-50 mx-auto max-w-lg">
        <FadeUp className="flex items-center justify-between px-6 pt-8">
          <ResoluteLogo variant="primary" size="sm" priority className="h-11 w-auto" />
          <div className="flex items-center gap-2 glass-red rounded-full px-3 py-1.5">
            <Zap className="h-3 w-3 text-resolute-red" />
            <span className="font-accent text-[10px] font-bold uppercase tracking-widest text-resolute-red">
              Choose
            </span>
          </div>
        </FadeUp>

        <Marquee />

        <div className="px-6 pb-12 pt-6">
          <div className="pointer-events-none overflow-hidden text-center">
            <FadeUp delay={0.1}>
              <p className="label-caps mb-6 text-resolute-red">Resolute Track Club</p>
            </FadeUp>
            <AnimatedHeadline lines={["Choose", "Your", "Path"]} className="relative" />
          </div>

          <FadeUp delay={0.45} className="pointer-events-none mx-auto mt-6 max-w-xs text-center">
            <p className="text-sm leading-relaxed text-white/45 text-balance">
              Start free, get coached remotely, or join as a current Resolute athlete below.
            </p>
          </FadeUp>

          <div className="relative z-50 mt-10 space-y-3">
            <a
              href="/dashboard?tier=generic"
              className="group relative block w-full cursor-pointer overflow-hidden rounded-xl border border-white/15 bg-gradient-to-br from-white/[0.09] via-white/[0.04] to-transparent p-5 text-left backdrop-blur-xl transition-colors duration-300 hover:border-white/25 hover:shadow-[0_0_48px_rgba(255,255,255,0.07)] touch-manipulation"
            >
              <div className="pointer-events-none absolute inset-0 bg-card-shine opacity-35" />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-tr from-white/[0.06] via-transparent to-transparent" />
              <span className="pointer-events-none absolute -right-1 -top-3 font-display text-[5.5rem] leading-none text-white/[0.05]">
                01
              </span>

              <div className="relative flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <span className="inline-flex items-center gap-2 rounded-full border border-white/45 bg-white/20 px-3.5 py-1.5 shadow-[0_0_20px_rgba(255,255,255,0.12)] backdrop-blur-sm">
                    <Sparkles className="h-3.5 w-3.5 shrink-0 text-white/90" />
                    <span className="font-accent text-[10px] font-bold uppercase tracking-[0.2em] text-white/95">
                      Free · No signup
                    </span>
                  </span>
                  <p className="label-caps mt-3 text-white/50">{tierLabels.generic.short}</p>
                  <p className="headline mt-2 text-[clamp(1.5rem,6vw,1.85rem)] leading-tight text-white">
                    {tierLabels.generic.name}
                  </p>
                  <p className="mt-2 text-sm leading-relaxed text-white/55">
                    {tierLabels.generic.description}
                  </p>
                </div>
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white/[0.08] ring-1 ring-white/15">
                  <ClipboardList className="h-5 w-5 text-white/60" />
                </div>
              </div>

              <div className="relative mt-5 overflow-hidden rounded-xl border border-white/15 bg-white/[0.05] px-5 py-3.5 transition-colors duration-300 group-hover:border-white/25 group-hover:bg-white/[0.08]">
                <span className="flex items-center justify-center gap-2 font-display text-sm uppercase tracking-[0.12em] text-white/80 transition-colors group-hover:text-white">
                  Start free tracking
                  <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-2" />
                </span>
              </div>
            </a>

            <p className="pt-1 text-center text-[10px] font-semibold uppercase tracking-[0.3em] text-white/25">
              or get the full program
            </p>

            <a
              href="/upgrade"
              className="group relative block w-full cursor-pointer overflow-hidden rounded-xl border-2 border-resolute-red/50 bg-gradient-to-br from-resolute-red/25 via-resolute-red/10 to-black/40 p-6 text-left backdrop-blur-xl red-glow transition-colors duration-300 hover:border-resolute-red touch-manipulation"
            >
              <div className="pointer-events-none absolute inset-0 bg-card-shine opacity-40" />
              <span className="pointer-events-none absolute -right-2 -top-4 font-display text-[7rem] leading-none text-white/[0.05]">
                02
              </span>
              <span className="pointer-events-none absolute -left-4 bottom-8 font-display text-[4rem] leading-none text-resolute-red/[0.07]">
                W
              </span>

              <div className="relative flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-resolute-red/50 bg-resolute-red/20 px-2.5 py-1">
                      <Crown className="h-3 w-3 text-resolute-red" />
                      <span className="font-accent text-[9px] font-bold uppercase tracking-[0.2em] text-resolute-red">
                        Full program
                      </span>
                    </span>
                    <Sparkles className="h-3.5 w-3.5 text-resolute-red/80" />
                  </div>
                  <p className="label-caps mt-3 text-resolute-red">{tierLabels.coached.short}</p>
                  <p className="headline mt-2 text-[clamp(1.85rem,7vw,2.25rem)] leading-[0.9] text-white">
                    {tierLabels.coached.name}
                  </p>
                  <p className="mt-3 text-sm leading-relaxed text-white/65">
                    {tierLabels.coached.description}
                  </p>
                </div>
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-resolute-red/30 ring-2 ring-resolute-red/40">
                  <Zap className="h-7 w-7 text-resolute-red" />
                </div>
              </div>

              <div className="relative mt-6 overflow-hidden rounded-xl bg-resolute-red px-5 py-4 shadow-glow transition-colors duration-300 group-hover:bg-[#FF2D4A]">
                <span className="flex items-center justify-center gap-2 font-display text-base uppercase tracking-[0.12em] text-white">
                  Get coached by Coach Whitney
                  <ArrowRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-2" />
                </span>
              </div>
            </a>
          </div>

          <div className="divider-glow my-10" />

          <div className="relative z-50 space-y-4">
            <CoachDevelopmentLink variant="card" />
            <PodcastButton />

            <button
              type="button"
              onClick={() => setShowCode((open) => !open)}
              className="group relative w-full cursor-pointer overflow-hidden p-5 text-left glass-red red-glow border border-resolute-red/30 transition-colors duration-300 touch-manipulation"
            >
              <div
                className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${teamChoice.accent}`}
              />
              <div className="relative flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="label-caps text-resolute-red">{teamChoice.label.short}</p>
                  <p className="headline mt-2 text-[clamp(1.5rem,6vw,1.75rem)] leading-tight text-white">
                    {teamChoice.label.name}
                  </p>
                  <p className="mt-2 text-sm leading-relaxed text-white/55">
                    {teamChoice.label.description}
                  </p>
                </div>
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-resolute-red/20">
                  <Users className="h-5 w-5 text-resolute-red" />
                </div>
              </div>
              <div className="relative mt-4 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-resolute-red">
                <span>{showCode ? "Enter access code" : "Team access — free"}</span>
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </div>
            </button>

            <AnimatePresence>
              {showCode && (
                <motion.form
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  onSubmit={handleTeamSubmit}
                  className="relative z-50 space-y-3 overflow-hidden rounded-xl border border-resolute-red/30 bg-resolute-red/5 p-5"
                >
                  <p className="label-caps text-resolute-red">Resolute Team Access Code</p>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => {
                      setCode(e.target.value);
                      setCodeError(false);
                    }}
                    placeholder="From Coach Whitney"
                    className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-white placeholder:text-white/30 focus:border-resolute-red focus:outline-none"
                    autoComplete="off"
                  />
                  {codeError && (
                    <p className="text-sm text-resolute-red">
                      Invalid code. Ask Coach Whitney if you&apos;re on the team.
                    </p>
                  )}
                  <button type="submit" className="btn-red w-full">
                    Unlock Resolute Athlete Portal
                  </button>
                </motion.form>
              )}
            </AnimatePresence>

            <p className="text-center text-xs text-white/30">
              Current Resolute athlete? Tap above. Coach? Explore team development above.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

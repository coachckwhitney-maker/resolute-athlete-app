"use client";

import Link from "next/link";
import { ArrowRight, GraduationCap, Sparkles } from "lucide-react";
import { coachDevelopmentCard } from "@/lib/data/coachDevelopment";
import { cn } from "@/lib/utils";

interface CoachDevelopmentLinkProps {
  className?: string;
  variant?: "button" | "card";
}

export function CoachDevelopmentLink({
  className,
  variant = "button",
}: CoachDevelopmentLinkProps) {
  if (variant === "card") {
    return (
      <Link
        href="/coaches"
        className={cn(
          "group relative z-10 block overflow-hidden rounded-xl border border-resolute-red/40 bg-gradient-to-br from-resolute-red/20 via-resolute-red/10 to-transparent p-5 red-glow transition-all duration-300 hover:border-resolute-red/70 hover:shadow-glow-sm touch-manipulation",
          className
        )}
      >
        <div className="pointer-events-none absolute -right-6 -top-8 font-display text-[6rem] leading-none text-white/[0.04]">
          W
        </div>
        <div className="relative flex items-start gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-resolute-red/25 ring-1 ring-resolute-red/40">
            <GraduationCap className="h-6 w-6 text-resolute-red" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <p className="label-caps text-resolute-red">{coachDevelopmentCard.tag}</p>
              <Sparkles className="h-3 w-3 text-resolute-red/80" />
            </div>
            <p className="headline mt-2 text-[clamp(1.35rem,5vw,1.75rem)] leading-tight text-white">
              {coachDevelopmentCard.title}
            </p>
            <p className="mt-2 text-sm leading-relaxed text-white/60">
              {coachDevelopmentCard.description}
            </p>
            <span className="mt-4 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-resolute-red transition-transform group-hover:translate-x-1">
              {coachDevelopmentCard.cta}
              <ArrowRight className="h-4 w-4" />
            </span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      href="/coaches"
      className={cn(
        "btn-ghost w-full border-resolute-red/35 text-white hover:border-resolute-red hover:bg-resolute-red/10 hover:text-white",
        className
      )}
    >
      <GraduationCap className="h-4 w-4 text-resolute-red" />
      {coachDevelopmentCard.title}
    </Link>
  );
}

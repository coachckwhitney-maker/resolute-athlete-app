"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowUpRight, GraduationCap, Users } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import {
  coachCredibility,
  coachDevelopmentHeadline,
  coachDevelopmentIntro,
  coachInquiryCta,
  coachOfferings,
  coachPhilosophyQuotes,
  coachTrainingInquiryCta,
} from "@/lib/data/coachDevelopment";
import { COACH_INQUIRY_URL } from "@/lib/config/links";
import { signatureFooter } from "@/lib/data/signatureSayings";
import { cn } from "@/lib/utils";

export function CoachesPageClient() {
  return (
    <AppShell>
      <Link
        href="/"
        className="mb-6 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white/40 hover:text-white"
      >
        <ArrowLeft className="h-4 w-4" />
        Back
      </Link>

      <header className="animate-fade-up mb-8">
        <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-resolute-red/15">
          <GraduationCap className="h-6 w-6 text-resolute-red" />
        </div>
        <p className="label-caps text-resolute-red">{coachDevelopmentHeadline.tag}</p>
        <h1 className="headline mt-3 text-[clamp(2.5rem,10vw,3.75rem)] leading-none text-white">
          {coachDevelopmentHeadline.title.split(" ").slice(0, 2).join(" ")}
          <br />
          <span className="text-gradient-red">
            {coachDevelopmentHeadline.title.split(" ").slice(2).join(" ")}
          </span>
        </h1>
        <p className="mt-4 text-sm leading-relaxed text-white/45">
          {coachDevelopmentHeadline.subtitle}
        </p>
      </header>

      <div className="mb-8 grid grid-cols-3 gap-3">
        {coachCredibility.map(({ value, label }) => (
          <div key={label} className="bento p-4 text-center">
            <p className="stat-number text-3xl text-gradient-red">{value}</p>
            <p className="label-caps mt-2">{label}</p>
          </div>
        ))}
      </div>

      <blockquote className="glass-red mb-10 border-l-2 border-resolute-red p-5">
        <p className="label-caps text-resolute-red">Coach Whitney</p>
        <p className="headline mt-2 text-2xl leading-tight text-white">
          &ldquo;{coachPhilosophyQuotes[0].text}&rdquo;
        </p>
        <p className="mt-4 text-sm leading-relaxed text-white/50">{coachDevelopmentIntro}</p>
        <p className="label-caps mt-4 text-white/30">{signatureFooter}</p>
      </blockquote>

      <section className="mb-10">
        <div className="mb-5 flex items-center gap-2">
          <Users className="h-5 w-5 text-resolute-red" />
          <p className="label-caps">How Whitney Works With Coaches</p>
        </div>

        <div className="space-y-4">
          {coachOfferings.map((offering, i) => {
            const featured = "featured" in offering && offering.featured;

            return (
            <motion.article
              key={offering.id}
              initial={false}
              whileHover={{ scale: 1.01 }}
              className={cn(
                "p-5 animate-stagger",
                featured
                  ? "glass-red red-glow border border-resolute-red/30"
                  : "card-interactive",
                `stagger-${Math.min(i + 1, 8)}`
              )}
            >
              <p className="label-caps text-resolute-red">{String(i + 1).padStart(2, "0")}</p>
              {featured && (
                <p className="label-caps mt-2 text-white/45">On-site · Hands-on training</p>
              )}
              <h2 className="headline mt-2 text-2xl text-white">{offering.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-white/45">{offering.description}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {offering.topics.map((topic) => (
                  <span
                    key={topic}
                    className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white/45"
                  >
                    {topic}
                  </span>
                ))}
              </div>
              {featured && (
                <a
                  href={COACH_INQUIRY_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-red mt-5 inline-flex w-full items-center justify-center gap-2 py-3 text-xs"
                >
                  {coachTrainingInquiryCta.primary}
                  <ArrowUpRight className="h-4 w-4" />
                </a>
              )}
            </motion.article>
            );
          })}
        </div>
      </section>

      <section className="mb-10">
        <p className="label-caps mb-4">Sounds Like Whitney</p>
        <div className="space-y-3">
          {coachPhilosophyQuotes.slice(1).map((quote) => (
            <blockquote
              key={quote.tag}
              className="glass rounded-xl border-l-2 border-white/15 p-4"
            >
              <p className="label-caps text-white/35">{quote.tag}</p>
              <p className="headline mt-2 text-lg leading-tight text-white">
                &ldquo;{quote.text}&rdquo;
              </p>
            </blockquote>
          ))}
        </div>
      </section>

      <section className="space-y-4">
        <p className="label-caps text-center text-resolute-red">Two Ways to Work Together</p>

        <div className="glass-red rounded-xl p-6 text-center red-glow">
          <p className="label-caps text-resolute-red">Coach Mentorship</p>
          <p className="headline mt-3 text-2xl text-white">Team Development</p>
          <p className="mx-auto mt-3 max-w-sm text-sm text-white/50">
            {coachInquiryCta.secondary}
          </p>
          <a
            href={COACH_INQUIRY_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-red mt-6 inline-flex w-full items-center justify-center gap-2"
          >
            {coachInquiryCta.primary}
            <ArrowUpRight className="h-5 w-5" />
          </a>
        </div>

        <div className="glass rounded-xl border border-white/10 p-6 text-center">
          <p className="label-caps text-resolute-red">On-Site Training</p>
          <p className="headline mt-3 text-2xl text-white">Speed · Agility · Strength</p>
          <p className="mx-auto mt-3 max-w-sm text-sm text-white/50">
            {coachTrainingInquiryCta.secondary}
          </p>
          <a
            href={COACH_INQUIRY_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost mt-6 inline-flex w-full items-center justify-center gap-2 border-resolute-red/40 text-white hover:border-resolute-red hover:text-white"
          >
            {coachTrainingInquiryCta.primary}
            <ArrowUpRight className="h-5 w-5 text-resolute-red" />
          </a>
        </div>

        <p className="text-center text-xs text-white/30">
          Opens inquiry form · Custom packages for clubs, schools & independent coaches
        </p>
      </section>
    </AppShell>
  );
}

"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { BookOpen, Sparkles, Trash2 } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { EmptyState } from "@/components/ui/EmptyState";
import { TrackingForm, TrackingInput, TrackingTextarea } from "@/components/progress/TrackingForm";
import { useCoachVoice } from "@/context/AppTierProvider";
import { useAthleteData } from "@/context/AthleteDataProvider";
import type { SeasonSummary } from "@/lib/types/athlete";

const REFLECTION_PROMPTS: {
  key: keyof Pick<
    SeasonSummary,
    | "biggestImprovement"
    | "favoritePerformance"
    | "toughestChallenge"
    | "lessonsLearned"
    | "nextSeasonGoals"
  >;
  label: string;
  placeholder: string;
}[] = [
  {
    key: "biggestImprovement",
    label: "Biggest improvement",
    placeholder: "What changed most in your training, mindset, or performance?",
  },
  {
    key: "favoritePerformance",
    label: "Favorite performance",
    placeholder: "The race, meet, or moment you are most proud of this season.",
  },
  {
    key: "toughestChallenge",
    label: "Toughest challenge",
    placeholder: "Injury, setback, doubt, or obstacle you had to push through.",
  },
  {
    key: "lessonsLearned",
    label: "What did I learn?",
    placeholder: "What this season taught you about yourself as an athlete and person.",
  },
  {
    key: "nextSeasonGoals",
    label: "Next season goals",
    placeholder: "Where you want to go — events, times, habits, or standards.",
  },
];

function defaultSeasonLabel(): string {
  const year = new Date().getFullYear();
  const month = new Date().getMonth();
  const start = month >= 6 ? year : year - 1;
  const endShort = String(start + 1).slice(-2);
  return `${start}-${endShort}`;
}

export function SeasonSummaryClient() {
  const router = useRouter();
  const voice = useCoachVoice();
  const { seasonSummaries, canManageSeasonSummary, saveSeasonSummary, removeSeasonSummary } =
    useAthleteData();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [season, setSeason] = useState(defaultSeasonLabel());
  const [fields, setFields] = useState({
    biggestImprovement: "",
    favoritePerformance: "",
    toughestChallenge: "",
    lessonsLearned: "",
    nextSeasonGoals: "",
  });

  const latest = seasonSummaries[0];

  const completedCount = useMemo(() => {
    return REFLECTION_PROMPTS.filter(({ key }) => fields[key].trim().length > 0).length;
  }, [fields]);

  if (!voice.isTeamAthlete || !canManageSeasonSummary) {
    return (
      <AppShell>
        <EmptyState
          title="Resolute Athletes only"
          description="Season Summary is part of the Resolute Athlete portal. Enter your team access code on the welcome screen to unlock it."
          actionLabel="Back to Welcome"
          onAction={() => router.push("/welcome")}
        />
      </AppShell>
    );
  }

  function openNewForm() {
    setEditingId(null);
    setSeason(defaultSeasonLabel());
    setFields({
      biggestImprovement: "",
      favoritePerformance: "",
      toughestChallenge: "",
      lessonsLearned: "",
      nextSeasonGoals: "",
    });
    setShowForm(true);
  }

  function openEdit(summary: SeasonSummary) {
    setEditingId(summary.id);
    setSeason(summary.season);
    setFields({
      biggestImprovement: summary.biggestImprovement,
      favoritePerformance: summary.favoritePerformance,
      toughestChallenge: summary.toughestChallenge,
      lessonsLearned: summary.lessonsLearned,
      nextSeasonGoals: summary.nextSeasonGoals,
    });
    setShowForm(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!season.trim()) return;
    saveSeasonSummary({
      id: editingId ?? undefined,
      season: season.trim(),
      ...fields,
    });
    setShowForm(false);
    setEditingId(null);
  }

  return (
    <AppShell>
      <header className="animate-fade-up mb-8">
        <p className="label-caps text-resolute-red">End-of-Season</p>
        <h1 className="headline text-5xl">
          Season
          <br />
          <span className="text-gradient-red">Summary</span>
        </h1>
        <p className="mt-2 text-sm text-white/40">
          Reflect on your season — what you built, what you learned, and where you are headed next.
        </p>
      </header>

      {!showForm && (
        <div className="glass-red mb-8 flex items-start gap-3 rounded-xl p-5">
          <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-resolute-red" />
          <p className="text-sm leading-relaxed text-white/55">
            Take your time. Honest reflection is how Resolute athletes get sharper season after
            season.
          </p>
        </div>
      )}

      {showForm ? (
        <TrackingForm
          onSubmit={handleSubmit}
          onCancel={() => {
            setShowForm(false);
            setEditingId(null);
          }}
          submitLabel={editingId ? "Update Summary" : "Save Season Summary"}
        >
          <TrackingInput
            value={season}
            onChange={setSeason}
            placeholder="Season (e.g. 2025-26)"
            required
          />

          {REFLECTION_PROMPTS.map(({ key, label, placeholder }) => (
            <div key={key}>
              <label className="label-caps mb-2 block">{label}</label>
              <TrackingTextarea
                value={fields[key]}
                onChange={(v) => setFields((prev) => ({ ...prev, [key]: v }))}
                placeholder={placeholder}
                rows={3}
              />
            </div>
          ))}

          <p className="text-center text-xs text-white/30">
            {completedCount} of {REFLECTION_PROMPTS.length} questions answered
          </p>
        </TrackingForm>
      ) : seasonSummaries.length === 0 ? (
        <EmptyState
          title="No season summary yet"
          description="When the season wraps, come back and capture your biggest wins, hardest moments, and goals for next year."
          actionLabel="Start Reflection"
          onAction={openNewForm}
        />
      ) : (
        <div className="space-y-4">
          {seasonSummaries.map((summary) => (
            <article key={summary.id} className="glass rounded-xl p-5">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-resolute-red/15">
                    <BookOpen className="h-5 w-5 text-resolute-red" />
                  </div>
                  <div>
                    <p className="headline text-2xl text-white">{summary.season} Season</p>
                    <p className="text-xs text-white/35">
                      Updated {new Date(summary.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => removeSeasonSummary(summary.id)}
                  className="rounded-lg p-2 text-white/30 hover:bg-white/5 hover:text-resolute-red"
                  aria-label="Delete season summary"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-4">
                {REFLECTION_PROMPTS.map(({ key, label }) => {
                  const value = summary[key];
                  if (!value.trim()) return null;
                  return (
                    <div key={key}>
                      <p className="label-caps text-white/40">{label}</p>
                      <p className="mt-1 text-sm leading-relaxed text-white/75">{value}</p>
                    </div>
                  );
                })}
              </div>

              <button type="button" onClick={() => openEdit(summary)} className="btn-ghost mt-5 w-full">
                Edit Summary
              </button>
            </article>
          ))}

          <button type="button" onClick={openNewForm} className="btn-red w-full">
            Add Another Season
          </button>
        </div>
      )}

      {!showForm && latest && seasonSummaries.length > 0 && (
        <p className="mt-6 text-center text-xs text-white/30">
          Your latest reflection: {latest.season} season
        </p>
      )}
    </AppShell>
  );
}

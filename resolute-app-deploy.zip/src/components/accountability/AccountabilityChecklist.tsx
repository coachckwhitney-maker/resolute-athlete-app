"use client";

import { useEffect, useState } from "react";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { AnimatedBar } from "@/components/ui/AnimatedBar";
import { accountabilityCompleteLine as defaultCompleteLine } from "@/lib/data/accountabilitySayings";
import type { AccountabilityItem } from "@/lib/types/athlete";

interface AccountabilityChecklistProps {
  initialItems: AccountabilityItem[];
  completeLine?: string;
  onItemsChange?: (items: AccountabilityItem[]) => void;
}

const categoryIcons: Record<string, string> = {
  recovery: "💤",
  training: "🏃",
  life: "📚",
  mindset: "🧠",
  nutrition: "🥩",
};

export function AccountabilityChecklist({
  initialItems,
  completeLine = defaultCompleteLine,
  onItemsChange,
}: AccountabilityChecklistProps) {
  const [items, setItems] = useState(initialItems);
  const completed = items.filter((i) => i.completed).length;
  const pct = Math.round((completed / items.length) * 100);

  useEffect(() => {
    setItems(initialItems);
  }, [initialItems]);

  function toggle(id: string) {
    setItems((prev) => {
      const next = prev.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      );
      onItemsChange?.(next);
      return next;
    });
  }

  return (
    <section>
      {/* Progress header */}
      <div className="mb-6">
        <div className="flex items-end justify-between">
          <div>
            <p className="label-caps">Daily Check-In</p>
            <p className="font-display text-5xl text-resolute-red">{pct}%</p>
          </div>
          <p className="label-caps">
            {completed}/{items.length} done
          </p>
        </div>
        <AnimatedBar value={pct} className="mt-4 h-1.5" />
      </div>

      <div className="space-y-2">
        {items.map((item, i) => (
          <button
            key={item.id}
            type="button"
            onClick={() => toggle(item.id)}
            className={cn(
              "animate-fade-up animate-stagger flex w-full items-center gap-4 border p-4 text-left transition-all duration-300 active:scale-[0.98]",
              `stagger-${Math.min(i + 1, 8)}`,
              item.completed
                ? "border-resolute-red/30 bg-resolute-red/5"
                : "border-white/10 bg-resolute-900 hover:border-white/20"
            )}
          >
            <div
              className={cn(
                "flex h-8 w-8 shrink-0 items-center justify-center border-2 transition-all duration-300",
                item.completed
                  ? "border-resolute-red bg-resolute-red"
                  : "border-white/20"
              )}
            >
              {item.completed && (
                <Check className="check-animate h-4 w-4 text-white" strokeWidth={3} />
              )}
            </div>
            <span className="text-xl">{categoryIcons[item.category]}</span>
            <div className="min-w-0 flex-1">
              <span
                className={cn(
                  "block font-medium transition-all",
                  item.completed ? "text-white/40 line-through" : "text-white"
                )}
              >
                {item.label}
              </span>
              {item.coachLine && !item.completed && (
                <span className="mt-1 block font-display text-xs uppercase tracking-wide text-resolute-red/80">
                  &ldquo;{item.coachLine}&rdquo;
                </span>
              )}
            </div>
          </button>
        ))}
      </div>

      {pct === 100 && (
        <div className="animate-scale-in mt-6 border border-resolute-red bg-resolute-red/10 p-5 text-center">
          <p className="headline text-2xl text-resolute-red">All Done.</p>
          <p className="mt-1 text-sm text-white/60">&ldquo;{completeLine}&rdquo;</p>
        </div>
      )}
    </section>
  );
}

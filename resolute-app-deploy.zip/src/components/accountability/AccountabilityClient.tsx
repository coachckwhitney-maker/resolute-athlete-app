"use client";

import { useMemo, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { AccountabilityChecklist } from "@/components/accountability/AccountabilityChecklist";
import { AccountabilityLines } from "@/components/accountability/AccountabilityLines";
import { EmptyState } from "@/components/ui/EmptyState";
import { useCoachVoice } from "@/context/AppTierProvider";
import { useAthleteData } from "@/context/AthleteDataProvider";
import { getClientAccountabilityLine } from "@/lib/coach/voice";
import { signatureFooter } from "@/lib/data/signatureSayings";
import { AnimatedBar } from "@/components/ui/AnimatedBar";
import { Flame } from "lucide-react";
import type { AccountabilityItem } from "@/lib/types/athlete";

function withHabitLines(
  items: AccountabilityItem[],
  lines: Record<string, string>
): AccountabilityItem[] {
  return items.map((item) => ({
    ...item,
    coachLine: lines[item.id] ?? item.coachLine,
  }));
}

export function AccountabilityClient() {
  const voice = useCoachVoice();
  const {
    isBlankSlate,
    athlete,
    accountabilityItems: storedItems,
    setAccountabilityItems,
    addAccountabilityItem,
  } = useAthleteData();

  const items = useMemo(
    () => withHabitLines(storedItems, voice.habitCoachLines),
    [storedItems, voice.habitCoachLines]
  );

  const [showAddHabit, setShowAddHabit] = useState(false);
  const [habitLabel, setHabitLabel] = useState("");

  const completedToday = items.filter((i) => i.completed).length;
  const pct = items.length > 0 ? Math.round((completedToday / items.length) * 100) : 0;

  const dailyLine = useMemo(() => {
    if (voice.features.whitneyVoice) {
      return getClientAccountabilityLine();
    }
    return {
      text: voice.accountabilityFeatured,
      tag: "Daily Focus",
      note: undefined,
    };
  }, [voice]);

  function handleAddHabit(e: React.FormEvent) {
    e.preventDefault();
    if (!habitLabel.trim()) return;
    addAccountabilityItem(habitLabel.trim());
    setHabitLabel("");
    setShowAddHabit(false);
  }

  return (
    <AppShell>
      <header className="animate-fade-up mb-8">
        <p className="label-caps">{isBlankSlate ? "Daily Habits" : "Resolute Daily"}</p>
        <h1 className="headline text-5xl">
          Hold
          <br />
          <span className="text-gradient-red">Yourself Accountable</span>
        </h1>
        <p className="mt-2 text-sm text-white/40 text-balance">
          {isBlankSlate
            ? "Create your own daily check-ins and track consistency."
            : `“${voice.accountabilityFeatured}”`}
        </p>
      </header>

      {!isBlankSlate && voice.features.whitneyVoice && (
        <blockquote className="glass-red mb-8 border-l-2 border-resolute-red p-5">
          <p className="label-caps text-resolute-red">
            {voice.coachName} · {dailyLine.tag}
          </p>
          <p className="headline mt-2 text-2xl leading-tight text-white">
            &ldquo;{dailyLine.text}&rdquo;
          </p>
          {dailyLine.note && (
            <p className="mt-3 text-sm leading-relaxed text-white/50">{dailyLine.note}</p>
          )}
          {voice.coachFooter && (
            <p className="label-caps mt-4 text-white/30">{signatureFooter}</p>
          )}
        </blockquote>
      )}

      {items.length > 0 && (
        <div className="animate-fade-up stagger-2 animate-stagger relative mb-8 overflow-hidden bento p-6 red-glow">
          <div className="absolute -right-6 -top-6 opacity-10">
            <Flame className="h-32 w-32 text-resolute-red" />
          </div>
          <div className="relative flex items-center gap-6">
            <div>
              <p className="label-caps text-resolute-red">Current Streak</p>
              <p className="font-display text-8xl leading-none text-resolute-red">
                {athlete.streak}
              </p>
              <p className="label-caps mt-1">Days</p>
            </div>
            <div className="flex-1">
              <p className="label-caps mb-2">Today&apos;s Progress</p>
              <AnimatedBar value={pct} className="h-2" />
              <p className="mt-2 text-sm text-white/40">
                {completedToday} of {items.length} habits checked
              </p>
            </div>
          </div>
        </div>
      )}

      {items.length === 0 ? (
        <EmptyState
          title="No habits yet"
          description="Add the daily habits you want to track — sleep, training, recovery, whatever matters to you."
          actionLabel="Add Habit"
          onAction={() => setShowAddHabit(true)}
        />
      ) : (
        <AccountabilityChecklist
          initialItems={items}
          completeLine={voice.accountabilityCompleteLine}
          onItemsChange={isBlankSlate ? setAccountabilityItems : undefined}
        />
      )}

      {showAddHabit && (
        <form onSubmit={handleAddHabit} className="mt-4 space-y-3 rounded-xl border border-white/10 bg-white/[0.02] p-4">
          <label className="label-caps" htmlFor="habit-label">
            Habit
          </label>
          <input
            id="habit-label"
            value={habitLabel}
            onChange={(e) => setHabitLabel(e.target.value)}
            placeholder="e.g. Slept 8+ hours"
            className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-white/30 focus:border-resolute-red focus:outline-none"
          />
          <div className="flex gap-2">
            <button type="submit" className="btn-red flex-1">
              Save
            </button>
            <button type="button" onClick={() => setShowAddHabit(false)} className="btn-ghost flex-1">
              Cancel
            </button>
          </div>
        </form>
      )}

      {items.length > 0 && !showAddHabit && (
        <button type="button" onClick={() => setShowAddHabit(true)} className="btn-ghost mt-4 w-full">
          Add Habit
        </button>
      )}

      {voice.showWhitneyContent && <AccountabilityLines />}
    </AppShell>
  );
}

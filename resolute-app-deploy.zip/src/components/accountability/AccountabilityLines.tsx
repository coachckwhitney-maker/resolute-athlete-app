import { accountabilityLines } from "@/lib/data/accountabilitySayings";

export function AccountabilityLines() {
  return (
    <section className="mb-8">
      <p className="label-caps text-resolute-red">Hard Conversations</p>
      <p className="mt-1 text-sm text-white/40">
        What Coach Whitney says when it matters most — because she believes in you
      </p>
      <div className="mt-5 grid gap-3">
        {accountabilityLines.map((line) => (
          <div
            key={line.id}
            className="glass-red rounded-xl border-l-2 border-resolute-red p-4"
          >
            <p className="font-accent text-[10px] font-bold uppercase tracking-wider text-resolute-red">
              {line.tag}
            </p>
            <p className="headline mt-2 text-xl leading-tight text-white">
              &ldquo;{line.text}&rdquo;
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}

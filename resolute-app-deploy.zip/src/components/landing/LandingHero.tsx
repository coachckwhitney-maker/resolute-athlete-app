"use client";

import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight, Zap } from "lucide-react";
import { MeshBackground } from "@/components/ui/MeshBackground";
import { Marquee } from "@/components/ui/Marquee";
import { ResoluteLogo } from "@/components/brand/ResoluteLogo";
import { AnimatedHeadline, FadeUp, ScaleIn } from "@/components/ui/Motion";
import { SignatureQuote } from "@/components/brand/SignatureQuote";
import { PodcastButton } from "@/components/brand/PodcastButton";
import { CoachDevelopmentLink } from "@/components/coaches/CoachDevelopmentLink";
import { ChoosePathLink } from "@/components/layout/ChoosePathLink";
import { useCoachVoice } from "@/context/AppTierProvider";
import { landingFeaturedQuote } from "@/lib/data/signatureSayings";
import { DiagonalSlash, ScanLine, SpeedLines } from "@/components/ui/EpicEffects";

const features = [
  {
    num: "01",
    title: "Daily Training",
    desc: "Workouts with the why — not just reps and sets.",
    accent: "from-resolute-red/25 to-transparent",
  },
  {
    num: "02",
    title: "Athlete Blueprint",
    desc: "Track 10 dimensions of the whole athlete.",
    accent: "from-white/10 to-transparent",
  },
  {
    num: "03",
    title: "Accountability",
    desc: "Daily habits, streaks, and check-ins.",
    accent: "from-resolute-red/20 to-transparent",
  },
  {
    num: "04",
    title: "Team Culture",
    desc: "Points for leadership, attendance, and encouragement.",
    accent: "from-resolute-red/20 to-transparent",
  },
  {
    num: "05",
    title: "Whole Athlete",
    desc: "Mindset, recovery, culture — not just workouts.",
    accent: "from-white/10 to-transparent",
  },
];

export function LandingHero() {
  const voice = useCoachVoice();
  const dashboardHref = voice.isTeamAthlete
    ? "/dashboard?tier=team"
    : voice.isCoached
      ? "/dashboard?tier=coached"
      : "/dashboard?tier=generic";

  return (
    <div className="relative min-h-screen overflow-hidden epic-hero-bg">
      <MeshBackground />

      <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden" aria-hidden>
        <SpeedLines />
        <DiagonalSlash />
        <ScanLine />
        <motion.div
          initial={false}
          animate={{ opacity: 0.05, scale: 1 }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
          className="absolute -left-12 top-40 select-none"
        >
          <p className="headline text-[8rem] leading-none text-white">Resolute</p>
        </motion.div>
        <div className="logo-watermark -right-20 top-20 rotate-[15deg] opacity-[0.09]">
          <Image
            src="/logos/resolute-logo-stripe.png"
            alt=""
            width={400}
            height={400}
            aria-hidden
            className="h-[32rem] w-[32rem] object-contain"
          />
        </div>
      </div>

      <main className="relative z-50 mx-auto max-w-lg">
        <FadeUp className="flex items-center justify-between px-6 pt-8">
          <ResoluteLogo variant="primary" size="sm" href={dashboardHref} priority className="h-11 w-auto" />
          <ChoosePathLink className="font-accent text-[10px] font-bold uppercase tracking-widest text-white/35 transition-colors hover:text-resolute-red" />
        </FadeUp>
        <FadeUp className="flex justify-end px-6 -mt-4 mb-2">
          <motion.div
            initial={false}
            animate={{ boxShadow: ["0 0 0 0 rgba(227,24,55,0.4)", "0 0 0 8px rgba(227,24,55,0)"] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="flex items-center gap-2 glass-red rounded-full px-3 py-1.5"
          >
            <Zap className="h-3 w-3 text-resolute-red" />
            <span className="font-accent text-[10px] font-bold uppercase tracking-widest text-resolute-red">
              {voice.tierLabel.short}
            </span>
          </motion.div>
        </FadeUp>

        <Marquee />

        <div className="px-6 pb-28 pt-8">
          <div className="pointer-events-none text-center">
            <FadeUp delay={0.1}>
              <p className="label-caps mb-8 text-resolute-red">Resolute Track Club</p>
            </FadeUp>
            <AnimatedHeadline lines={["Train", "Like It", "Matters"]} className="relative" />
          </div>

          <FadeUp delay={0.5} className="pointer-events-none mx-auto mt-8 max-w-xs text-center">
            <p className="text-sm leading-relaxed text-white/45 text-balance">
              {voice.landingSubtitle}
            </p>
          </FadeUp>

          <FadeUp delay={0.65} className="relative z-50 mt-10 space-y-3">
            <a href={dashboardHref} className="btn-red group relative block w-full overflow-hidden">
              <span className="relative z-10 flex items-center justify-center gap-2">
                {voice.isTeamAthlete
                  ? "Open Athlete Portal"
                  : voice.isCoached
                    ? "Enter Training"
                    : "Open Tracker"}
                <ArrowRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-2" />
              </span>
            </a>
            {voice.features.blueprint && (
              <Link href="/blueprint" className="btn-ghost w-full">
                View Athlete Blueprint
              </Link>
            )}
            <CoachDevelopmentLink variant="card" />
            <PodcastButton className="mt-3" />
            {voice.features.showUpgradeToCoached && (
              <Link href="/upgrade" className="btn-ghost w-full border-resolute-red/30 text-resolute-red">
                {voice.isTeamAthlete ? "Get Remote Coaching" : "Get Coached by Coach Whitney"}
              </Link>
            )}
          </FadeUp>

          {voice.features.whitneyVoice && (
            <div className="mt-12">
              <SignatureQuote
                quote={landingFeaturedQuote.text}
                tag={landingFeaturedQuote.tag}
              />
            </div>
          )}

          <FadeUp delay={0.8} className="mt-14 grid grid-cols-2 gap-3">
            <motion.div
              whileHover={{ scale: 1.02 }}
              transition={{ type: "spring", stiffness: 400, damping: 25 }}
              className="bento col-span-2 p-6 red-glow"
            >
              <p className="label-caps text-resolute-red">
                {voice.features.whitneyVoice ? "Coach Whitney" : voice.coachName}
              </p>
              <p className="headline mt-2 text-[clamp(2rem,8vw,2.75rem)] leading-[0.95] text-white">
                {voice.coachBentoLine}
              </p>
            </motion.div>
            {(voice.features.blueprint
              ? [
                  { val: "10", label: "Blueprint Dimensions" },
                  { val: "82", label: "Avg Athlete Score" },
                ]
              : [
                  { val: "∞", label: "Workouts You Log" },
                  { val: "100%", label: "Your Data" },
                ]
            ).map(({ val, label }, i) => (
              <motion.div
                key={label}
                whileHover={{ scale: 1.03, y: -2 }}
                transition={{ type: "spring", stiffness: 400, damping: 20 }}
                className="bento p-5"
              >
                <motion.p
                  initial={false}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 1 + i * 0.15, type: "spring" }}
                  className="stat-number text-gradient-red"
                >
                  {val}
                </motion.p>
                <p className="label-caps mt-2">{label}</p>
              </motion.div>
            ))}
          </FadeUp>

          <div className="divider-glow my-12" />

          <FadeUp delay={0.95}>
            <p className="label-caps mb-5">
              {voice.features.whitneyVoice ? "Built by Whitney" : "Built Different"}
            </p>
            <div className="no-scrollbar -mx-6 flex snap-x snap-mandatory gap-4 overflow-x-auto px-6 pb-4">
              {features
                .filter((feature) => feature.title !== "Athlete Blueprint" || voice.features.blueprint)
                .map(({ num, title, desc, accent }, i) => (
                <motion.div
                  key={num}
                  initial={false}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ delay: i * 0.1, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                  whileTap={{ scale: 0.97 }}
                  className="card-interactive relative min-w-[270px] shrink-0 snap-center overflow-hidden p-6"
                >
                  <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${accent}`} />
                  <span className="relative font-display text-8xl text-white/[0.05]">{num}</span>
                  <h3 className="headline relative mt-1 text-3xl">{title}</h3>
                  <p className="relative mt-3 text-sm leading-relaxed text-white/50">{desc}</p>
                </motion.div>
              ))}
            </div>
          </FadeUp>

          <ScaleIn delay={1.1} className="mt-16 flex flex-col items-center">
            <ResoluteLogo variant="primary" size="md" />
            <p className="label-caps mt-6">www.resolutetrackclub.com</p>
          </ScaleIn>
        </div>
      </main>
    </div>
  );
}

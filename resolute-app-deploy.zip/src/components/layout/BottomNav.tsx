"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  TrendingUp,
  CheckSquare,
  Brain,
  Hexagon,
  Heart,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useCoachVoice } from "@/context/AppTierProvider";

const navItems = [
  { href: "/dashboard", label: "Today", icon: LayoutDashboard, show: () => true },
  {
    href: "/culture",
    label: "Culture",
    icon: Heart,
    show: (f: { culture: boolean }) => f.culture,
  },
  { href: "/blueprint", label: "Blueprint", icon: Hexagon, show: (f: { blueprint: boolean }) => f.blueprint },
  { href: "/progress", label: "Progress", icon: TrendingUp, show: () => true },
  { href: "/accountability", label: "Daily", icon: CheckSquare, show: () => true },
  {
    href: "/mindset",
    label: "Mindset",
    icon: Brain,
    show: (f: { mindset: boolean }) => f.mindset,
  },
];

export function BottomNav() {
  const pathname = usePathname();
  const voice = useCoachVoice();
  const items = navItems.filter((item) => item.show(voice.features));
  const activeIndex = items.findIndex(
    (item) => pathname === item.href || pathname.startsWith(`${item.href}/`)
  );

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 animate-slide-up">
      <div className="mx-auto max-w-lg px-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
        <div className="relative flex items-center justify-around rounded-2xl glass px-1 py-1.5 shadow-glass">
          <div
            className="absolute top-1.5 h-[calc(100%-12px)] rounded-xl bg-resolute-red/20 shadow-glow-sm transition-all duration-500 ease-out"
            style={{
              width: `calc(${100 / items.length}% - 4px)`,
              left: `calc(${(Math.max(activeIndex, 0) / items.length) * 100}% + 2px)`,
            }}
          />

          {items.map(({ href, label, icon: Icon }, i) => {
            const active = i === activeIndex;
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "nav-pill relative z-10 flex-1 rounded-xl py-2.5",
                  active ? "nav-pill-active" : "text-white/35"
                )}
              >
                <Icon
                  className={cn(
                    "h-5 w-5 transition-all duration-500",
                    active && "scale-110 drop-shadow-[0_0_8px_rgba(227,24,55,0.6)]"
                  )}
                />
                <span
                  className={cn(
                    "font-accent text-[9px] font-bold uppercase tracking-wider transition-all duration-300",
                    active ? "text-resolute-red" : "text-white/35"
                  )}
                >
                  {label}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

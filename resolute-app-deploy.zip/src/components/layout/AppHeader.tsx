import { ResoluteLogo } from "@/components/brand/ResoluteLogo";
import { ChoosePathLink } from "./ChoosePathLink";

export function AppHeader() {
  return (
    <header className="animate-fade-in mb-6 flex items-center justify-between gap-3">
      <ResoluteLogo variant="primary" size="xs" href="/dashboard" />
      <ChoosePathLink />
    </header>
  );
}

"use client";

import { MeshBackground } from "@/components/ui/MeshBackground";
import { AppHeader } from "./AppHeader";
import { BottomNav } from "./BottomNav";
import { TierBanner } from "@/components/tier/TierBanner";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative min-h-screen pb-28">
      <MeshBackground />
      <main className="relative mx-auto max-w-lg px-5 pt-6">
        <AppHeader />
        <TierBanner />
        {children}
      </main>
      <BottomNav />
    </div>
  );
}

import Link from "next/link";
import { Map } from "lucide-react";

interface ChoosePathLinkProps {
  className?: string;
}

export function ChoosePathLink({ className }: ChoosePathLinkProps) {
  return (
    <Link
      href="/welcome"
      className={
        className ??
        "inline-flex shrink-0 items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 font-accent text-[10px] font-bold uppercase tracking-widest text-white/50 transition-colors hover:border-resolute-red/30 hover:text-resolute-red"
      }
    >
      <Map className="h-3 w-3" aria-hidden />
      Choose Your Path
    </Link>
  );
}

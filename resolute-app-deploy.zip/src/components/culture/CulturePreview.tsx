"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight, Heart } from "lucide-react";
import { athleteCulture, teamCultureLeaderboard } from "@/lib/data/culture";
import { AnimatedBar } from "@/components/ui/AnimatedBar";

export function CulturePreview() {
  const champion = teamCultureLeaderboard[0];
  const topCategory = Object.entries(athleteCulture.breakdown).sort(
    ([, a], [, b]) => b - a
  )[0];
  const topMeta = topCategory[0].replace(/_/g, " ");

  return (
    <section className="relative mb-8">
      <div className="bento overflow-hidden p-6">
        <div className="mb-4 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Heart className="h-4 w-4 text-resolute-red" />
              <p className="label-caps text-resolute-red">Team Culture</p>
            </div>
            <p className="headline mt-2 text-3xl text-white">The Family Matters</p>
            <p className="mt-1 text-xs text-white/40">
              Push each other. Lead by example. Give back.
            </p>
          </div>
          <Link
            href="/culture"
            className="flex h-11 w-11 items-center justify-center rounded-xl bg-resolute-red text-white shadow-glow-sm transition-transform hover:scale-105 active:scale-95"
          >
            <ArrowUpRight className="h-5 w-5" />
          </Link>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <motion.div whileHover={{ scale: 1.03 }} className="glass-red rounded-xl p-3 text-center">
            <p className="stat-number text-3xl text-resolute-red">{athleteCulture.monthlyPoints}</p>
            <p className="label-caps mt-1">Your Pts</p>
          </motion.div>
          <motion.div whileHover={{ scale: 1.03 }} className="glass rounded-xl p-3 text-center">
            <p className="stat-number text-3xl text-white">#{athleteCulture.rank}</p>
            <p className="label-caps mt-1">Team Rank</p>
          </motion.div>
          <motion.div whileHover={{ scale: 1.03 }} className="glass rounded-xl p-3 text-center">
            <p className="stat-number text-3xl text-gradient-red">{champion.name}</p>
            <p className="label-caps mt-1">Culture MVP</p>
          </motion.div>
        </div>

        <div className="mt-4 glass-red rounded-xl p-4">
          <p className="label-caps">Your Strongest</p>
          <p className="headline mt-1 text-xl capitalize text-white">{topMeta}</p>
          <AnimatedBar value={Math.round((topCategory[1] / 200) * 100)} className="mt-3 h-1" />
        </div>
      </div>
    </section>
  );
}

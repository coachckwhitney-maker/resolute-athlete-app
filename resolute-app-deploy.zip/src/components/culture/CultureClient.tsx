"use client";

import { motion } from "framer-motion";
import { AppShell } from "@/components/layout/AppShell";
import { CultureLeaderboard } from "@/components/culture/CultureLeaderboard";
import { CultureBreakdown } from "@/components/culture/CultureBreakdown";
import { CultureFeed } from "@/components/culture/CultureFeed";
import { CultureStatements } from "@/components/culture/CultureStatements";
import { athleteCulture, teamCultureLeaderboard } from "@/lib/data/culture";
import { useCoachVoice } from "@/context/AppTierProvider";
import { getDailyCultureStatement } from "@/lib/data/cultureSayings";
import { signatureFooter } from "@/lib/data/signatureSayings";
import { Heart } from "lucide-react";

export function CultureClient() {
  const voice = useCoachVoice();
  const champion = teamCultureLeaderboard[0];

  const dailyCulture = voice.features.whitneyVoice
    ? getDailyCultureStatement()
    : {
        text: voice.cultureCoachMessage,
        tag: "Team Culture",
      };

  return (
    <AppShell>
      <header className="animate-fade-up mb-8">
        <div className="flex items-center gap-2">
          <Heart className="h-5 w-5 text-resolute-red" />
          <p className="label-caps text-resolute-red">Resolute Track Club</p>
        </div>
        <h1 className="headline mt-2 text-[clamp(3rem,12vw,4.5rem)] leading-none">
          <span className="text-white">Team</span>
          <br />
          <span className="text-gradient-red">Culture</span>
        </h1>
        <p className="mt-3 text-sm text-white/40 text-balance">
          {voice.features.whitneyVoice
            ? `"${dailyCulture.text}" — not just PRs. We reward the athlete who lives the culture.`
            : voice.cultureCoachMessage}
        </p>
      </header>

      <motion.div
        initial={false}
        animate={{ opacity: 1, scale: 1 }}
        className="bento mb-8 overflow-hidden p-6 red-glow"
      >
        <p className="label-caps text-resolute-red">Culture Champion</p>
        <div className="mt-3 flex items-end justify-between">
          <div>
            <p className="headline text-5xl text-white">{champion.name}</p>
            <p className="mt-1 text-sm text-white/50">{champion.highlight}</p>
          </div>
          <div className="text-right">
            <p className="stat-number text-5xl text-gradient-red">{champion.monthlyPoints}</p>
            <p className="label-caps">pts this month</p>
          </div>
        </div>
      </motion.div>

      <motion.blockquote
        initial={false}
        animate={{ opacity: 1, x: 0 }}
        className="glass-red mb-8 border-l-2 border-resolute-red p-5"
      >
        <p className="label-caps text-resolute-red">
          {voice.coachName} · {dailyCulture.tag}
        </p>
        <p className="headline mt-2 text-2xl leading-tight text-white">
          &ldquo;{dailyCulture.text}&rdquo;
        </p>
        {voice.coachFooter && (
          <p className="label-caps mt-4 text-white/30">{signatureFooter}</p>
        )}
      </motion.blockquote>

      {voice.showWhitneyContent && <CultureStatements />}

      <div className="mb-8 grid grid-cols-2 gap-3">
        <div className="bento p-5">
          <p className="stat-number text-gradient-red">{athleteCulture.monthlyPoints}</p>
          <p className="label-caps mt-1">Your Points</p>
        </div>
        <div className="bento p-5">
          <p className="stat-number text-white">
            #{athleteCulture.rank}
            <span className="text-2xl text-white/30">/{athleteCulture.teamSize}</span>
          </p>
          <p className="label-caps mt-1">Team Rank</p>
        </div>
      </div>

      <CultureLeaderboard members={teamCultureLeaderboard} />
      <CultureBreakdown profile={athleteCulture} />
      <CultureFeed entries={athleteCulture.recentEntries} />
    </AppShell>
  );
}

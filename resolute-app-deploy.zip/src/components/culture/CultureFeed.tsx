import { getCategoryMeta } from "@/lib/data/culture";
import type { CulturePointEntry } from "@/lib/types/athlete";

interface CultureFeedProps {
  entries: CulturePointEntry[];
}

export function CultureFeed({ entries }: CultureFeedProps) {
  return (
    <section className="mt-10">
      <p className="label-caps mb-4">Recent Culture Points</p>
      <div className="space-y-2">
        {entries.map((entry) => {
          const meta = getCategoryMeta(entry.category);
          return (
            <div key={entry.id} className="glass flex items-start gap-3 rounded-xl p-4">
              <span className="text-xl">{meta?.icon ?? "⭐"}</span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-medium text-white">{meta?.label}</p>
                  <span className="shrink-0 font-display text-lg text-resolute-red">
                    +{entry.points}
                  </span>
                </div>
                <p className="mt-0.5 text-xs text-white/50">{entry.note}</p>
                <p className="mt-1 text-[10px] text-white/25">{entry.date}</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

"use client";

import { motion } from "framer-motion";
import { Crown, Medal } from "lucide-react";
import { cn } from "@/lib/utils";
import type { TeamCultureMember } from "@/lib/types/athlete";

interface CultureLeaderboardProps {
  members: TeamCultureMember[];
}

function RankIcon({ rank }: { rank: number }) {
  if (rank === 1) return <Crown className="h-5 w-5 text-resolute-red" />;
  if (rank === 2) return <Medal className="h-5 w-5 text-white/60" />;
  if (rank === 3) return <Medal className="h-5 w-5 text-amber-600/80" />;
  return (
    <span className="font-display text-xl text-white/30">#{rank}</span>
  );
}

export function CultureLeaderboard({ members }: CultureLeaderboardProps) {
  return (
    <section>
      <p className="label-caps mb-4">This Month&apos;s Standings</p>
      <div className="space-y-3">
        {members.map((member, i) => (
          <motion.div
            key={member.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.08, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            whileHover={{ scale: 1.01, x: 4 }}
            className={cn(
              "glass rounded-xl p-4 transition-shadow",
              member.rank === 1 && "red-glow border-resolute-red/30",
              member.isCurrentUser && "border-resolute-red/40 bg-resolute-red/5"
            )}
          >
            <div className="flex items-center gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center">
                <RankIcon rank={member.rank} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-white">
                    {member.name}
                    {member.isCurrentUser && (
                      <span className="ml-2 text-[10px] font-bold uppercase tracking-wider text-resolute-red">
                        You
                      </span>
                    )}
                  </p>
                </div>
                <p className="text-xs text-white/40">Grade {member.grade}</p>
                {member.highlight && member.rank === 1 && (
                  <p className="mt-1 text-xs text-resolute-red/80">{member.highlight}</p>
                )}
              </div>
              <div className="text-right">
                <p className="stat-number text-3xl text-resolute-red">{member.monthlyPoints}</p>
                <p className="label-caps">pts</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

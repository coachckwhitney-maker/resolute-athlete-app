import { cultureStatements } from "@/lib/data/cultureSayings";

export function CultureStatements() {
  return (
    <section className="mb-8">
      <p className="label-caps text-resolute-red">Coach Whitney&apos;s Culture</p>
      <p className="mt-1 text-sm text-white/40">
        Unmistakably Resolute — how we treat each other and this program
      </p>
      <div className="mt-5 grid gap-3">
        {cultureStatements.map((statement) => (
          <div
            key={statement.id}
            className="glass rounded-xl border-l-2 border-resolute-red/40 p-4"
          >
            <p className="font-accent text-[10px] font-bold uppercase tracking-wider text-resolute-red">
              {statement.tag}
            </p>
            <p className="headline mt-2 text-xl leading-tight text-white">
              &ldquo;{statement.text}&rdquo;
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}

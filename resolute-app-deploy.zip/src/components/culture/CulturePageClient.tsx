"use client";

import Link from "next/link";
import { AppShell } from "@/components/layout/AppShell";
import { CultureClient } from "@/components/culture/CultureClient";
import { UpgradeCTA } from "@/components/upgrade/UpgradeComparison";
import { useCoachVoice } from "@/context/AppTierProvider";
import { Heart } from "lucide-react";

export function CulturePageClient() {
  const voice = useCoachVoice();

  if (!voice.features.culture) {
    return (
      <AppShell>
        <header className="mb-8">
          <div className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-resolute-red" />
            <p className="label-caps text-resolute-red">Team Culture</p>
          </div>
          <h1 className="headline mt-2 text-4xl text-white">Resolute Athletes Only</h1>
          <p className="mt-3 text-sm text-white/45">
            Team culture is part of the free Resolute Athlete portal or Coached Athlete subscription.
          </p>
        </header>
        <UpgradeCTA />
        <Link href="/dashboard" className="btn-ghost mt-4 block w-full text-center">
          Back to Today
        </Link>
      </AppShell>
    );
  }

  return <CultureClient />;
}

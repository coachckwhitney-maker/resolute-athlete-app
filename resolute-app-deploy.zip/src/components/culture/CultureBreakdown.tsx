"use client";

import { motion } from "framer-motion";
import { cultureCategories } from "@/lib/data/culture";
import { AnimatedBar } from "@/components/ui/AnimatedBar";
import { useCoachVoice } from "@/context/AppTierProvider";
import type { AthleteCultureProfile } from "@/lib/types/athlete";

interface CultureBreakdownProps {
  profile: AthleteCultureProfile;
}

export function CultureBreakdown({ profile }: CultureBreakdownProps) {
  const voice = useCoachVoice();
  const maxPoints = Math.max(...Object.values(profile.breakdown));

  return (
    <section className="mt-10">
      <p className="label-caps mb-2">How You Earn Points</p>
      <p className="mb-5 text-sm text-white/40">
        Culture is tracked separately from PRs and performance marks
      </p>
      <div className="space-y-3">
        {cultureCategories.map((cat, i) => {
          const pts = profile.breakdown[cat.id];
          const pct = Math.round((pts / maxPoints) * 100);
          return (
            <motion.div
              key={cat.id}
              initial={false}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className="glass rounded-xl p-4"
            >
              <div className="flex items-start gap-3">
                <span className="text-2xl">{cat.icon}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-semibold text-white">{cat.label}</p>
                    <div className="text-right shrink-0">
                      <p className="font-display text-2xl text-resolute-red">{pts}</p>
                      <p className="text-[10px] text-white/30">{cat.pointsLabel}</p>
                    </div>
                  </div>
                  <p className="mt-1 text-xs leading-relaxed text-white/40">{cat.description}</p>
                  {voice.showWhitneyContent && (
                    <p className="mt-2 font-display text-sm uppercase tracking-wide text-resolute-red/90">
                      &ldquo;{cat.coachLine}&rdquo;
                    </p>
                  )}
                  <AnimatedBar value={pct} delay={i * 60} className="mt-3 h-1" />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}

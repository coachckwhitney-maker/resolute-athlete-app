"use client";

import { Podcast } from "lucide-react";
import {
  PODCAST_COMING_SOON_LABEL,
  PODCAST_ENABLED,
  PODCAST_LABEL,
  PODCAST_URL,
} from "@/lib/config/links";
import { cn } from "@/lib/utils";

interface PodcastButtonProps {
  className?: string;
  label?: string;
}

export function PodcastButton({
  className,
  label = PODCAST_LABEL,
}: PodcastButtonProps) {
  if (!PODCAST_ENABLED) {
    return (
      <div
        className={cn(
          "flex w-full items-center justify-between gap-3 rounded-xl border border-white/20 bg-white/[0.06] px-5 py-4 backdrop-blur-sm",
          className
        )}
        aria-disabled="true"
      >
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-resolute-red/15 ring-1 ring-resolute-red/25">
            <Podcast className="h-5 w-5 text-resolute-red" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-white">Our Podcast</p>
            <p className="text-xs text-white/55">Coming soon — stay tuned</p>
          </div>
        </div>
        <span className="shrink-0 rounded-full border border-resolute-red/40 bg-resolute-red/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-resolute-red">
          Soon
        </span>
      </div>
    );
  }

  return (
    <a
      href={PODCAST_URL}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "flex w-full items-center gap-3 rounded-xl border border-white/20 bg-white/[0.06] px-5 py-4 text-white backdrop-blur-sm transition-all hover:border-resolute-red/50 hover:bg-resolute-red/10",
        className
      )}
    >
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-resolute-red/20">
        <Podcast className="h-5 w-5 text-resolute-red" />
      </div>
      <span className="text-sm font-semibold">{label}</span>
    </a>
  );
}

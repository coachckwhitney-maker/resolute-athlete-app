"use client";

import { FadeUp } from "@/components/ui/Motion";
import { useCoachVoice } from "@/context/AppTierProvider";
import { signatureFooter } from "@/lib/data/signatureSayings";

interface SignatureQuoteProps {
  quote: string;
  tag?: string;
  compact?: boolean;
}

export function SignatureQuote({ quote, tag, compact = false }: SignatureQuoteProps) {
  const voice = useCoachVoice();

  return (
    <FadeUp delay={compact ? 0 : 0.85}>
      <blockquote
        className={
          compact
            ? "glass-red rounded-xl p-5 red-glow"
            : "relative overflow-hidden bento p-6 red-glow"
        }
      >
        {!compact && voice.features.whitneyVoice && (
          <p
            className="pointer-events-none absolute -right-4 top-2 font-display text-[5rem] leading-none text-white/[0.04]"
            aria-hidden
          >
            W
          </p>
        )}
        <p className="label-caps text-resolute-red">{voice.coachName}</p>
        {tag && (
          <p className="mt-2 font-accent text-[10px] font-bold uppercase tracking-[0.25em] text-white/35">
            {tag}
          </p>
        )}
        <p
          className={`headline mt-3 leading-[1.05] text-white ${
            compact ? "text-xl" : "text-[clamp(1.5rem,5vw,2.25rem)]"
          }`}
        >
          &ldquo;{quote}&rdquo;
        </p>
        {voice.coachFooter && (
          <p className="label-caps mt-4 text-resolute-red">{signatureFooter}</p>
        )}
      </blockquote>
    </FadeUp>
  );
}

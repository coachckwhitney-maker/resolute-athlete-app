import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/utils";

const LOGOS = {
  primary: "/logos/resolute-logo-primary.png",
  white: "/logos/resolute-logo-white.png",
  stripe: "/logos/resolute-logo-stripe.png",
  square: "/logos/resolute-logo-square.jpg",
  icon: "/logos/rtc-icon.png",
} as const;

type LogoVariant = "primary" | "white" | "stripe" | "square" | "icon";

interface ResoluteLogoProps {
  variant?: LogoVariant;
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "hero";
  className?: string;
  href?: string;
  priority?: boolean;
}

const sizes = {
  xs: { width: 80, height: 32, className: "h-8 w-auto" },
  sm: { width: 120, height: 48, className: "h-10 w-auto" },
  md: { width: 180, height: 72, className: "h-14 w-auto" },
  lg: { width: 260, height: 104, className: "h-20 w-auto" },
  xl: { width: 320, height: 128, className: "h-28 w-auto" },
  hero: { width: 400, height: 160, className: "h-36 w-auto max-w-full" },
};

export function ResoluteLogo({
  variant = "primary",
  size = "md",
  className,
  href,
  priority = false,
}: ResoluteLogoProps) {
  const src = LOGOS[variant];
  const dim = sizes[size];

  const image = (
    <Image
      src={src}
      alt="Resolute Track Club"
      width={dim.width}
      height={dim.height}
      priority={priority}
      className={cn("object-contain", dim.className, className)}
    />
  );

  if (href) {
    return (
      <Link href={href} className="inline-block transition-opacity hover:opacity-90 active:scale-[0.98]">
        {image}
      </Link>
    );
  }

  return image;
}

export function ResoluteMark({ className }: { className?: string }) {
  return (
    <Image
      src={LOGOS.square}
      alt="Resolute Track Club"
      width={40}
      height={40}
      className={cn("h-10 w-10 rounded-sm object-cover", className)}
    />
  );
}

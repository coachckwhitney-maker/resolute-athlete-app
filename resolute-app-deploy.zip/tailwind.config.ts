import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        resolute: {
          black: "#050505",
          950: "#0a0a0a",
          900: "#111111",
          800: "#1a1a1a",
          700: "#262626",
          600: "#404040",
          500: "#737373",
          red: "#E31837",
          "red-bright": "#FF2D4A",
          "red-glow": "#FF0844",
          white: "#FAFAFA",
          success: "#22c55e",
          warning: "#FFB800",
          danger: "#FF453A",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "Helvetica Neue", "Arial", "sans-serif"],
        display: ["var(--font-display)", "Impact", "sans-serif"],
        accent: ["var(--font-accent)", "sans-serif"],
      },
      backgroundImage: {
        "mesh-red":
          "radial-gradient(ellipse 90% 70% at 50% -30%, rgba(227,24,55,0.25), transparent 60%), radial-gradient(ellipse 50% 50% at 100% 0%, rgba(255,8,68,0.12), transparent), radial-gradient(ellipse 40% 40% at 0% 100%, rgba(227,24,55,0.08), transparent)",
        "mesh-dark":
          "radial-gradient(ellipse 120% 80% at 50% 100%, rgba(227,24,55,0.06), transparent 50%)",
        "hero-gradient":
          "linear-gradient(180deg, rgba(227,24,55,0.08) 0%, transparent 40%, transparent 100%)",
        "card-shine":
          "linear-gradient(135deg, rgba(255,255,255,0.1) 0%, transparent 50%, rgba(255,255,255,0.03) 100%)",
        "red-shimmer":
          "linear-gradient(90deg, transparent 0%, rgba(227,24,55,0.4) 50%, transparent 100%)",
      },
      boxShadow: {
        glow: "0 0 60px rgba(227, 24, 55, 0.25), 0 0 120px rgba(227, 24, 55, 0.08)",
        "glow-sm": "0 0 30px rgba(227, 24, 55, 0.2)",
        glass: "0 8px 32px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255,255,255,0.06)",
        card: "0 4px 24px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.05)",
      },
      animation: {
        "fade-up": "fadeUp 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards",
        "fade-in": "fadeIn 0.5s ease-out forwards",
        "scale-in": "scaleIn 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) forwards",
        "slide-up": "slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards",
        "pulse-red": "pulseRed 2.5s ease-in-out infinite",
        "ring-fill": "ringFill 1.4s cubic-bezier(0.16, 1, 0.3, 1) forwards",
        "bar-fill": "barFill 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards",
        shimmer: "shimmer 3s ease-in-out infinite",
        float: "float 8s ease-in-out infinite",
        "float-delayed": "float 8s ease-in-out 2s infinite",
        "check-pop": "checkPop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) forwards",
        marquee: "marquee 28s linear infinite",
        "glow-pulse": "glowPulse 4s ease-in-out infinite",
        orbit: "orbit 20s linear infinite",
        "gradient-x": "gradientX 6s ease infinite",
        "speed-line": "speedLine 4s ease-in-out infinite",
        "scan": "scan 8s linear infinite",
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(32px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        scaleIn: {
          "0%": { opacity: "0", transform: "scale(0.9)" },
          "100%": { opacity: "1", transform: "scale(1)" },
        },
        slideUp: {
          "0%": { opacity: "0", transform: "translateY(100%)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        pulseRed: {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(227,24,55,0.5)" },
          "50%": { boxShadow: "0 0 0 12px rgba(227,24,55,0)" },
        },
        ringFill: {
          "0%": { strokeDashoffset: "283" },
          "100%": { strokeDashoffset: "var(--ring-offset)" },
        },
        barFill: {
          "0%": { width: "0%" },
          "100%": { width: "var(--bar-width)" },
        },
        shimmer: {
          "0%": { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(100%)" },
        },
        float: {
          "0%, 100%": { transform: "translate(0, 0) scale(1)" },
          "33%": { transform: "translate(10px, -20px) scale(1.05)" },
          "66%": { transform: "translate(-5px, 10px) scale(0.95)" },
        },
        checkPop: {
          "0%": { transform: "scale(0)" },
          "60%": { transform: "scale(1.25)" },
          "100%": { transform: "scale(1)" },
        },
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        glowPulse: {
          "0%, 100%": { opacity: "0.4" },
          "50%": { opacity: "0.8" },
        },
        orbit: {
          "0%": { transform: "rotate(0deg) translateX(120px) rotate(0deg)" },
          "100%": { transform: "rotate(360deg) translateX(120px) rotate(-360deg)" },
        },
        gradientX: {
          "0%, 100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
        speedLine: {
          "0%": { transform: "translateX(-30%) rotate(-12deg)", opacity: "0" },
          "50%": { opacity: "1" },
          "100%": { transform: "translateX(30%) rotate(-12deg)", opacity: "0" },
        },
        scan: {
          "0%": { top: "-2%" },
          "100%": { top: "102%" },
        },
      },
    },
  },
  plugins: [],
};

export default config;

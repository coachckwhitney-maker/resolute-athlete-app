# Resolute Track Club App

**The coach in your pocket.** Not another workout app — the operating system for athlete development.

Built on 20+ years of coaching philosophy: speed, strength, mindset, accountability, recovery, communication, and relationships.

## Brand

Uses official **Resolute Track Club** logo assets (Rieker/Riker mark) with RTC red (`#E31837`) on black — Nike-inspired, mobile-first UI.

Logo files live in `public/logos/`:
- `resolute-logo-primary.png` — full RTC mark (dark backgrounds)
- `resolute-logo-stripe.png` — diagonal stripe variant (watermarks)
- `resolute-logo-square.jpg` — app icon / favicon

## MVP Features (Phase 1)

- **Daily Training Dashboard** — workouts with the *why*, not just the what
- **Athlete Blueprint** — 10-dimension complete athlete score
- **Progress Tracking** — PRs, strength numbers, wellness metrics
- **Daily Accountability** — habit check-ins and streak system
- **Mindset Library** — five-minute lessons on confidence, failure, leadership
- **Coach Messages** — daily focus and philosophy-driven messaging

## Roadmap

| Phase | Timeline | Features |
|-------|----------|----------|
| **MVP** | Now | Dashboard, workouts, progress, accountability, mindset |
| **V2** | +3 mo | AI Coach Whitney, video upload/analysis, parent portal, meet-day mode |
| **V3** | +6 mo | Coach dashboard, team management, readiness scores, culture points |
| **Long-term** | +12 mo | Subscriptions, remote coaching, recruiting hub, multi-sport expansion |

## Getting Started

### Prerequisites

Install [Node.js](https://nodejs.org/) (v18+) and Xcode Command Line Tools (for git):

```bash
xcode-select --install
```

### Install & Run

```bash
cd ~/Projects/resolute-app
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── dashboard/          # Daily training dashboard
│   ├── blueprint/          # Athlete Blueprint profile
│   ├── progress/           # PRs and wellness
│   ├── accountability/     # Daily check-ins
│   └── mindset/            # Mindset library
├── components/             # UI components by feature
└── lib/
    ├── data/               # Mock data (replace with API)
    └── types/              # TypeScript types
```

## Tech Stack

- **Next.js 15** — React framework with App Router
- **TypeScript** — type safety
- **Tailwind CSS** — mobile-first styling
- **Lucide React** — icons

## Vision

Instead of saying *"I ran 11.3"*, athletes see *"I'm an 82/100 athlete."* The goal becomes becoming a complete athlete — not just chasing one time or mark.

---

*Resolute App — developing the whole athlete.*
